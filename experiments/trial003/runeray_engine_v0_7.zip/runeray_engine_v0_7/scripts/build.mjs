import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const order = [
  'src/core/CanonicalData.js',
  'src/core/MaterialRegistry.js',
  'src/core/ChunkedVoxelWorld.js',
  'src/core/Raycaster.js',
  'src/core/SkyEnvironment.js',
  'src/core/SpriteSystem.js',
  'src/core/EntitySystem.js',
  'src/core/InteractionSystem.js',
  'src/core/MicroVoxelBody.js',
  'src/core/MicroVoxelSystem.js',
  'src/core/Inventory.js',
  'src/core/MenuState.js',
  'src/core/DeterministicRng.js',
  'src/core/EventBus.js',
  'src/core/NavigationSystem.js',
  'src/core/AISystem.js',
  'src/core/EquipmentSystem.js',
  'src/core/CombatSystem.js',
  'src/core/TriggerSystem.js',
  'src/core/DialogueSystem.js',
  'src/core/ProceduralWorldSystem.js',
  'src/core/SaveSystem.js',
  'src/core/AsciiRenderer.js',
  'src/core/FirstPersonController.js',
  'src/core/RuneRayEngine.js',
  'src/demo/ConstructionSandbox.js',
  'src/demo/GameplayFoundationDemo.js',
  'src/demo/main.js',
];
const stripModuleSyntax = source => source.replace(/^import\s+[^;]+;\s*$/gm, '').replace(/^export\s+/gm, '');
const bundle = order.map(file => `// --- ${file} ---\n${stripModuleSyntax(fs.readFileSync(path.join(root, file), 'utf8'))}`).join('\n\n');
const sourceHtml = fs.readFileSync(path.join(root, 'src/demo/index.html'), 'utf8');
const output = sourceHtml.replace('<script type="module" src="./main.js"></script>', `<script>\n${bundle}\n</script>`);
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/runeray_engine_systems_lab.html'), output);
console.log(`Built ${output.length} bytes -> dist/runeray_engine_systems_lab.html`);
