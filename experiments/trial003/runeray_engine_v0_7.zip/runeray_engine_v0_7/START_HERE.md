# START HERE — RuneRay v0.7

1. Open `dist/runeray_engine_systems_lab.html` for the integrated gameplay lab.
2. Run `npm test` before changing core behavior.
3. Run `npm run build` after source changes.
4. Read `ARCHITECTURE.md` before adding engine-level systems.
5. Treat `reference/runeray_engine_v0_6_pre_hive_merge.html` and `reference/runeray_engine_v0_5_1_hive_branch.html` as immutable provenance/reference builds.

Keep genre-specific mechanics optional. RuneRay core should remain useful to RPG, horror, stealth, construction, detective and procedural exploration games.
