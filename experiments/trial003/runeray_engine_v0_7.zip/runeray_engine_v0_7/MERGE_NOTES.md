# Hive v0.5.1 → RuneRay v0.7 Merge Notes

Hive returned a branch based on RuneRay v0.5. The useful changes were merged beneath v0.6's gameplay layer rather than replacing it.

## Adopted from Hive

- canonical plain-data snapshot validation and stable key ordering
- deterministic lowest-free automatic IDs for sprites, entities and micro bodies
- deterministic interaction tie-breaking
- serialized controller state/tuning
- serialized materials
- serialized inventory item definitions
- serialized interaction and raycaster configuration
- serialized fractional simulation accumulator

## Preserved from v0.6

- AI + voxel navigation
- equipment + combat
- events + triggers
- branching dialogue
- deterministic procedural world hooks
- state adapters and save/restore
- high/balanced/low ASCII resolution
- construction/object systems as optional examples

## Extended during merge

Hive's branch recorded several fields but did not have v0.6's full restore system. v0.7 restores the newly recorded fields too and bumps the snapshot schema to v4 while continuing to accept v3 snapshots.
