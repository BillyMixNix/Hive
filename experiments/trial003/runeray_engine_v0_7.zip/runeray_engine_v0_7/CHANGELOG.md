# Changelog

## v0.7.0 — Hive merge

- Merged Hive v0.5.1 core data/determinism changes into v0.6 gameplay foundation.
- Added `CanonicalData` plain-data validation and stable key ordering.
- Added deterministic lowest-available auto IDs for sprites, entities and micro-voxel bodies.
- Added deterministic interaction tie-breaking.
- Expanded snapshots with materials, inventory definitions, controller state/tuning, interactions, raycaster configuration and simulation accumulator.
- Added restore support for the expanded state.
- Bumped snapshot schema to v4 while retaining v3 compatibility.
- Preserved both source branches under `reference/`.

## v0.6.0

- Added EventBus.
- Added voxel-aware grid navigation with A* routing and line-of-sight helper.
- Added generic AI agent service with patrol, wander, chase/flee foundations.
- Extended inventory item definitions for equipment/combat metadata.
- Added equipment slots and additive stat bonuses.
- Added generic combat actors, health, attacks, cooldowns, damage/death events and camera-target attacks.
- Added reusable box/sphere trigger volumes.
- Added branching dialogue trees and persistent active-conversation state.
- Added deterministic procedural generator registry with independent per-chunk RNG.
- Added snapshot extension-adapter protocol and full restore path.
- Added JSON/in-memory/local quick-save adapter.
- Added restore support to world, inventory, sprites, entities and fine-voxel bodies.
- Reworked demo into Gameplay Foundation Lab while preserving construction/object systems as optional examples.
- Added mobile dialogue and character/equipment surfaces.
