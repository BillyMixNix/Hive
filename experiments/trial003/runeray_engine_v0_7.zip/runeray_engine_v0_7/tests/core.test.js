import assert from 'node:assert/strict';
import { canonicalData } from '../src/core/CanonicalData.js';
import { MaterialRegistry } from '../src/core/MaterialRegistry.js';
import { ChunkedVoxelWorld } from '../src/core/ChunkedVoxelWorld.js';
import { Raycaster } from '../src/core/Raycaster.js';
import { MicroVoxelSystem } from '../src/core/MicroVoxelSystem.js';
import { Inventory } from '../src/core/Inventory.js';
import { SpriteSystem } from '../src/core/SpriteSystem.js';
import { EntitySystem } from '../src/core/EntitySystem.js';
import { InteractionSystem } from '../src/core/InteractionSystem.js';
import { SkyEnvironment } from '../src/core/SkyEnvironment.js';
import { MenuState } from '../src/core/MenuState.js';
import { DeterministicRng } from '../src/core/DeterministicRng.js';
import { RuneRayEngine } from '../src/core/RuneRayEngine.js';
import { NavigationSystem } from '../src/core/NavigationSystem.js';
import { EquipmentSystem } from '../src/core/EquipmentSystem.js';
import { TriggerSystem } from '../src/core/TriggerSystem.js';
import { DialogueSystem } from '../src/core/DialogueSystem.js';
import { ProceduralWorldSystem } from '../src/core/ProceduralWorldSystem.js';
import { installConstructionSandbox } from '../src/demo/ConstructionSandbox.js';

const materials = new MaterialRegistry();
const hull = materials.register('hull', { name: 'Hull' });
const world = new ChunkedVoxelWorld(16);
world.set(-1, -1, -1, hull); world.set(17, 0, 0, hull);
assert.equal(world.get(-1, -1, -1), hull, 'negative coordinates work');
assert.equal(world.get(17, 0, 0), hull, 'cross-chunk coordinates work');
assert.equal(world.chunks.size, 2, 'sparse chunks only allocate touched regions');
world.set(17, 0, 0, 0);
assert.equal(world.nonAirCount, 1, 'non-air block count is tracked');

const rayWorld = new ChunkedVoxelWorld(); rayWorld.set(4, 0, 1, hull);
const ray = new Raycaster(rayWorld, materials, 20);
const hit = ray.cast({ x: 0.5, y: 0.5, z: 1.5 }, 1, 0, 0);
assert.deepEqual([hit.x, hit.y, hit.z], [4, 0, 1]); assert.equal(hit.source, 'world');

const glass = materials.register('glass-test', { name: 'Glass Test', opacity: 0.25 });
const layeredWorld = new ChunkedVoxelWorld(); layeredWorld.set(2, 0, 1, glass); layeredWorld.set(4, 0, 1, hull);
const layeredRay = new Raycaster(layeredWorld, materials, 20);
assert.deepEqual(layeredRay.castLayers({ x: 0.5, y: 0.5, z: 1.5 }, 1, 0, 0).map(h => h.materialId), [glass, hull]);

const microWorld = new ChunkedVoxelWorld();
const microSystem = new MicroVoxelSystem(microWorld, materials, { gravity: { x: 0, y: 0, z: -4 } });
const microBody = microSystem.createBody({ id: 'test-body', voxelSize: 0.25, sizeX: 4, sizeY: 4, sizeZ: 4, x: 2, y: 0, z: 1, gravityScale: 0 });
microBody.set(0, 2, 2, hull);
const microRay = new Raycaster(microWorld, materials, 20); microRay.addProvider(microSystem);
const microHit = microRay.cast({ x: 0.5, y: 0.625, z: 1.625 }, 1, 0, 0);
assert(microHit, 'ray hits micro voxel'); assert.equal(microHit.source, 'micro'); assert.equal(microHit.body.id, 'test-body');
assert(microHit.dist > 1 && microHit.dist < 2, 'micro voxel hit distance is plausible');

const inventory = new Inventory(3); inventory.define('plate', { name: 'Plate', maxStack: 5 });
assert.equal(inventory.add('plate', 8), 8); assert.equal(inventory.count('plate'), 8); assert.equal(inventory.remove('plate', 3), 3); assert.equal(inventory.count('plate'), 5);
const sprites = new SpriteSystem(); const s = sprites.add({ x: 1, vx: 2, art: ['@'] }); sprites.update(0.5, {}); assert.equal(s.x, 2, 'sprite system updates billboard positions');
const entitySprites = new SpriteSystem(); const entities = new EntitySystem(entitySprites); let used = 0;
const testEntity = entities.add({ id:'test-npc',name:'Test NPC',x:2,y:0,z:1,height:1,sprite:{art:['@']},interactions:{primary:()=>{used++;return 'hello';}} });
assert.equal(entitySprites.list().length,1,'entity can own a billboard sprite');
const interaction = new InteractionSystem(entities,{cast:()=>null},{reach:4,aimCone:.95});
const interactionResult=interaction.interact({x:0,y:0,z:1.5,yaw:0,pitch:0},'primary',{}); assert.equal(interactionResult.ok,true); assert.equal(interactionResult.message,'hello'); assert.equal(used,1);
testEntity.x=8; assert.equal(interaction.findTarget({x:0,y:0,z:1.5,yaw:0,pitch:0}),null,'interaction respects reach');
const sky = new SkyEnvironment({ seed: 1 }); assert.equal(sky.sample(1, 0, 0), sky.sample(1, 0, 0), 'sky sampling is deterministic for a direction');
const menu = new MenuState(); let menuEvent = 0; menu.onChange(() => menuEvent++); menu.toggle(); assert.equal(menu.open, true); assert.equal(menuEvent, 1);

const fakeWorld = new ChunkedVoxelWorld();
const fakeMaterials = new MaterialRegistry();
const fakeMicro = new MicroVoxelSystem(fakeWorld, fakeMaterials, { gravity: { x: 0, y: 0, z: -4.8 } });
const fakeSprites = new SpriteSystem();
let fakeAim = null;
const fakeEngine = { materials: fakeMaterials, world: fakeWorld, inventory: new Inventory(12), microVoxels: fakeMicro, sprites: fakeSprites, entities: new EntitySystem(fakeSprites), camera: { x:0,y:0,z:0,yaw:0,pitch:0 }, queryAim: () => fakeAim };
const sandbox = installConstructionSandbox(fakeEngine);
assert(fakeEngine.world.nonAirCount > 0, 'systems demo creates world geometry');
assert(fakeEngine.sprites.list().length >= 4, 'systems demo creates entity billboard sprites');
assert.equal(fakeEngine.entities.list().length, 4, 'systems demo creates generic interactable entities');
assert.equal(fakeEngine.microVoxels.list().length, 1, 'systems demo creates a micro voxel physics body');
assert(fakeEngine.inventory.count('hull-block') > 0, 'systems demo seeds inventory');
const targetX = 5, targetY = 0, targetZ = 2;
fakeAim = { source: 'world', dist: 3, x: targetX, y: targetY, z: targetZ, nx: -1, ny: 0, nz: 0 };
fakeEngine.camera.x = -5; fakeEngine.camera.y = 0; fakeEngine.camera.z = 3;
const before = fakeEngine.world.nonAirCount, invBefore = fakeEngine.inventory.count('hull-block');
assert.equal(sandbox.place(), true); assert.equal(fakeEngine.world.nonAirCount, before + 1); assert.equal(fakeEngine.inventory.count('hull-block'), invBefore - 1, 'placement consumes inventory');
fakeAim = { source: 'world', dist: 3, x: 4, y: 0, z: 2, nx: -1, ny: 0, nz: 0 };
assert.equal(sandbox.remove(), true); assert.equal(fakeEngine.inventory.count('hull-block'), invBefore, 'recovery returns inventory');


// Deterministic infrastructure merged from v0.3.1.
const rngA = new DeterministicRng(12345), rngB = new DeterministicRng(12345);
assert.deepEqual(Array.from({ length: 8 }, () => rngA.nextUint32()), Array.from({ length: 8 }, () => rngB.nextUint32()), 'same seed produces same RNG sequence');
assert.throws(() => new ChunkedVoxelWorld(0), /positive integer/, 'invalid chunk size is rejected');
assert.throws(() => world.set(0.5, 0, 0, hull), /integer voxel coordinate/, 'fractional world coordinates are rejected');
assert.throws(() => sprites.add({ id: s.id }), /already exists/, 'duplicate sprite ids are rejected');
assert.throws(() => entities.add({ id: 'test-npc' }), /already exists/, 'duplicate entity ids are rejected');

const insideWorld = new ChunkedVoxelWorld(); insideWorld.set(0, 0, 0, hull);
const insideRay = new Raycaster(insideWorld, materials, 10);
const insideHit = insideRay.cast({ x: 0.5, y: 0.5, z: 0.5 }, 1, 0, 0);
assert.equal(insideHit?.contained, true, 'raycaster reports the containing voxel when the origin starts inside geometry');
assert.equal(insideHit?.dist, 0, 'contained hit starts at zero distance');

const headlessA = new RuneRayEngine(null, { headless: true, seed: 77, fixedStep: 1 / 60 });
const headlessB = new RuneRayEngine(null, { headless: true, seed: 77, fixedStep: 1 / 60 });
headlessA.addSystem({ update: (_dt, e) => { e.camera.x += e.random() * 0.001; } });
headlessB.addSystem({ update: (_dt, e) => { e.camera.x += e.random() * 0.001; } });
assert.equal(headlessA.advance(1 / 30), 2, 'advance converts elapsed time into fixed simulation steps');
assert.equal(headlessB.advance(1 / 60), 1); assert.equal(headlessB.advance(1 / 60), 1);
assert.equal(headlessA.tick, 2); assert.equal(headlessA.camera.x, headlessB.camera.x, 'fixed-step simulation is deterministic across frame chunking');
assert.equal(headlessA.renderer, null, 'headless engine does not create a renderer');
const snap = headlessA.serializeCoreState();
assert.equal(snap.version, 4); assert.equal(snap.seed, 77); assert.equal(snap.tick, 2); assert(Array.isArray(snap.entities), 'core snapshot includes generic entities');

assert.equal(snap.controller.moveSpeed, headlessA.controller.moveSpeed, 'snapshot captures controller tuning');
assert.equal(snap.raycaster.maxDistance, headlessA.raycaster.maxDistance, 'snapshot captures raycaster tuning');
assert.equal(snap.interactions.reach, headlessA.interactions.reach, 'snapshot captures interaction tuning');
assert(Array.isArray(snap.materials) && snap.materials[0].key === 'air', 'snapshot captures material definitions');
assert.equal(snap.simulationAccumulator, headlessA.simulationAccumulator, 'snapshot captures fractional simulation accumulator');

const canonicalA = canonicalData({ z: 1, a: { y: 2, x: 3 } });
const canonicalB = canonicalData({ a: { x: 3, y: 2 }, z: 1 });
assert.deepEqual(canonicalA, canonicalB, 'canonical snapshot data is independent of object insertion order');
assert.throws(() => canonicalData({ bad: Infinity }), /finite/, 'canonical snapshots reject non-finite numbers');
const cycle = {}; cycle.self = cycle; assert.throws(() => canonicalData(cycle), /cycles/, 'canonical snapshots reject cyclic state');

const idSprites = new SpriteSystem(); const spriteOne = idSprites.add({}); idSprites.add({}); idSprites.remove(spriteOne.id);
assert.equal(idSprites.add({}).id, 'sprite-1', 'sprite ids deterministically reuse the lowest available id');
const idEntities = new EntitySystem(); const entityOne = idEntities.add({}); idEntities.add({}); idEntities.remove(entityOne.id);
assert.equal(idEntities.add({}).id, 'entity-1', 'entity ids deterministically reuse the lowest available id');
const idMicro = new MicroVoxelSystem(new ChunkedVoxelWorld(), materials); const microOne = idMicro.createBody({}); idMicro.createBody({}); idMicro.removeBody(microOne.id);
assert.equal(idMicro.createBody({}).id, 'micro-1', 'micro body ids deterministically reuse the lowest available id');

const tieEntities = new EntitySystem(); tieEntities.add({ id:'target-b', x:2, y:0, z:1, interactions:{ primary:()=>true } }); tieEntities.add({ id:'target-a', x:2, y:0, z:1, interactions:{ primary:()=>true } });
const tieInteraction = new InteractionSystem(tieEntities, { cast:()=>null }, { reach:4, aimCone:.9 });
assert.equal(tieInteraction.findTarget({x:0,y:0,z:1.5,yaw:0,pitch:0}).entity.id, 'target-a', 'interaction ties resolve deterministically by entity id');


// v0.6 gameplay foundation preserved through the Hive merge.
const navWorld = new ChunkedVoxelWorld();
for (let x=0;x<6;x++) for(let y=0;y<4;y++) navWorld.set(x,y,0,hull);
navWorld.set(2,1,1,hull); navWorld.set(2,1,2,hull);
const nav = new NavigationSystem(navWorld, materials);
const path = nav.findPath({x:.5,y:1.5,z:1.02},{x:5.5,y:1.5,z:1.02});
assert(path.length > 5, 'navigation finds a route around blocking voxels');
assert(!path.some(p => Math.floor(p.x)===2 && Math.floor(p.y)===1), 'navigation avoids blocked cells');

const eqInv = new Inventory(6); eqInv.define('sword',{name:'Sword',maxStack:1,equipSlot:'mainHand',stats:{attack:2}}); eqInv.add('sword',1);
const equipment = new EquipmentSystem(eqInv); assert.equal(equipment.equip('sword').ok,true); assert.equal(eqInv.count('sword'),0); assert.equal(equipment.bonuses().attack,2); assert.equal(equipment.unequip('mainHand').ok,true); assert.equal(eqInv.count('sword'),1,'equipment conserves inventory items');

const trigger = new TriggerSystem(); let entered=0; trigger.add({id:'zone',min:{x:0,y:0,z:0},max:{x:1,y:1,z:2},once:true,onEnter:()=>entered++});
trigger.update(0,{camera:{x:.5,y:.5,z:1}}); trigger.update(0,{camera:{x:.5,y:.5,z:1}}); assert.equal(entered,1,'once trigger fires once');

const dialogue = new DialogueSystem(); dialogue.register('test',{nodes:{start:{text:'Hello',choices:[{text:'Next',next:'end'}]},end:{text:'Bye',choices:[]}}});
assert.equal(dialogue.start('test').ok,true); assert.equal(dialogue.current().text,'Hello'); dialogue.choose(0); assert.equal(dialogue.current().text,'Bye','dialogue advances through nodes');

const procWorldA = new ChunkedVoxelWorld(8), procWorldB = new ChunkedVoxelWorld(8); const procMatsA = new MaterialRegistry(), procMatsB = new MaterialRegistry(); const pa=procMatsA.register('rock'), pb=procMatsB.register('rock');
const gen = ({cx,cy,world,rng}) => world.set(cx*8,cy*8,0,rng.next()>.5?1:0);
const procA=new ProceduralWorldSystem(procWorldA,procMatsA,999), procB=new ProceduralWorldSystem(procWorldB,procMatsB,999); procA.register('g',gen); procB.register('g',gen); procA.ensureChunk('g',1,2,0); procA.ensureChunk('g',0,0,0); procB.ensureChunk('g',0,0,0); procB.ensureChunk('g',1,2,0); assert.deepEqual(procA.serialize(),procB.serialize(),'procedural chunk record is order-independent'); assert.deepEqual(procWorldA.serialize(),procWorldB.serialize(),'procedural output is order-independent');

const saveEngine = new RuneRayEngine(null,{headless:true,seed:44});
const floor=saveEngine.materials.register('floor'); for(let x=0;x<4;x++)for(let y=0;y<4;y++)saveEngine.world.set(x,y,0,floor);
saveEngine.inventory.define('blade',{equipSlot:'mainHand',maxStack:1,stats:{attack:1}}); saveEngine.inventory.add('blade',1); saveEngine.equipment.equip('blade');
const foe=saveEngine.entities.add({id:'foe',x:2.5,y:2.5,z:1.02}); saveEngine.combat.defineActor('player',{maxHp:10}); saveEngine.combat.defineActor(foe,{maxHp:5});
saveEngine.ai.add(foe,{mode:'wander',home:{x:2.5,y:2.5,z:1.02}}); saveEngine.triggers.add({id:'t',min:{x:0,y:0,z:0},max:{x:1,y:1,z:2}}); saveEngine.dialogue.register('d',{nodes:{start:{text:'x',choices:[]}}}); saveEngine.dialogue.start('d');
const fullSnap=saveEngine.serializeCoreState(); saveEngine.camera.x=99; saveEngine.combat.damage('foe',5); saveEngine.inventory.add('blade',1); saveEngine.restoreCoreState(fullSnap);
assert.notEqual(saveEngine.camera.x,99,'restore resets camera'); assert.equal(saveEngine.combat.get('foe').hp,5,'restore resets combat state'); assert.equal(saveEngine.equipment.get('mainHand'),'blade','restore resets equipment'); assert.equal(saveEngine.dialogue.current().text,'x','restore resets dialogue state');

assert.deepEqual(saveEngine.serializeCoreState(), fullSnap, 'full v0.7 snapshot round-trips exactly after restore');
assert.equal(saveEngine.inventory.def('blade').equipSlot, 'mainHand', 'inventory item definitions survive restore');

const legacyV06 = structuredClone(fullSnap); legacyV06.version = 3; delete legacyV06.controller; delete legacyV06.materials; delete legacyV06.interactions; delete legacyV06.raycaster; delete legacyV06.simulationAccumulator;
saveEngine.camera.x = 77; assert.equal(saveEngine.restoreCoreState(legacyV06), true, 'v0.6 schema snapshots remain loadable'); assert.notEqual(saveEngine.camera.x, 77);

console.log('RuneRay v0.7 Hive merge + gameplay foundation tests passed.');
