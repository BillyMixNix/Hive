# Optional Construction/Space Direction (RuneRay v0.7)

Working concept: a simplified first-person engineering sandbox using RuneRay's ASCII framebuffer rather than conventional textured 3D.

## v0.3 makes the architecture more credible

The engine now has distinct representations instead of pretending every object should be a one-meter static block:

- **large sparse world voxels** — terrain, stations, asteroids
- **micro voxels** — small physical props, tools, drones, components, debris
- **billboard sprites** — characters/effects/distant lightweight entities
- **inventory** — actual construction-resource ownership
- **menu framework** — build/configuration surfaces without fighting camera input
- **directional procedural sky** — space backdrop without texture payload

The systems lab already proves that large construction and a smaller detailed movable object can coexist in the same raycast view.

## Target fantasy

Start in or near a small craft. Salvage/mine material, construct blocks and components, power a craft, pilot it to procedural asteroids, repair damage and expand into larger vehicles/stations.

Keep the first actual game substantially smaller than Space Engineers.

## Representation policy

### Large ship hulls
Use future **dynamic sparse VoxelBody** grids, not dense quarter-scale micro voxels.

### Small components / loose objects
Use micro voxels when shape/destruction matters.

Examples:
- handheld drill
- loose battery pack
- small drone
- damaged machine part
- debris chunks
- detailed console

### Characters / effects
Use billboard sprites until they need true geometric volume.

This mixed-resolution approach is how we keep both simulation detail and file/runtime cost under control.

## Minimum playable progression

1. suit movement / thrust
2. inventory-backed construction
3. mining/salvage resources
4. functional block definitions
5. dynamic large-grid `VoxelBody`
6. cockpit attachment and ship piloting
7. battery/power budget
8. directional thrusters
9. deterministic asteroids
10. save edited chunks + constructed bodies

Micro-object physics can mature alongside this but should not block the first movable ship.

## Dynamic ship target

```text
WorldSpace
├── static sparse terrain / asteroids
├── VoxelBody: Starter Ship
│   ├── local sparse chunks
│   ├── position + orientation
│   ├── linear + angular velocity
│   ├── component graph
│   └── inventories
├── VoxelBody: Station
├── micro-voxel props
└── billboard entities
```

Ray rendering path:

1. test candidate large-body bounds
2. transform ray into body-local coordinates
3. run local DDA through that body's sparse chunks
4. combine those hits with static-world and micro-body hits
5. select/composite by distance
6. convert final perception into glyphs

`Raycaster.addProvider()` exists now so large moving-body ray traversal can plug into this scene model rather than replacing it.

## Procedural asteroids

Store compact identity plus modifications:

```text
seed
generator version
position
radius/type
player-edited chunk deltas
```

Untouched material is regenerated. Empty distance between bodies requires no voxel storage.

## Functional blocks

First useful set:
- armor
- glass
- light
- battery
- cockpit
- thruster
- drill
- cargo

A block definition should remain compact data: material, mass, integrity, component type/orientation, power behavior and optional inventory reference.

## ASCII as instrumentation

The display can communicate engineering state without new textures:

```text
Hull       .,:;irsXA253hMHGS#9B&@
Glass        .:|/+xX#
Powered    -+=#@
Damaged    /\\xX%#
Ore        .:*%$@
Leak       .:oO
Fire       ^*#%@
```

Sensors, damaged helmets and power states can alter glyph resolution itself.

## Scope discipline

Build in this order:

**construction → inventory/resources → functional blocks → dynamic ship → power → mining → procedural asteroids → survival → logistics**

Do not start with conveyors, rotors, pistons, programmable blocks, multiplayer or realistic structural simulation.
