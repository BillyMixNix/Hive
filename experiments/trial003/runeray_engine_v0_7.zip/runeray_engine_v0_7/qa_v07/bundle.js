
// --- src/core/CanonicalData.js ---
function canonicalData(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('snapshot data numbers must be finite');
    return value;
  }
  if (Array.isArray(value)) {
    if (seen.has(value)) throw new TypeError('snapshot data must not contain cycles');
    seen.add(value);
    const out = value.map(item => canonicalData(item, seen));
    seen.delete(value);
    return out;
  }
  if (typeof value === 'object') {
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) throw new TypeError('snapshot data must use plain objects/arrays/primitives');
    if (seen.has(value)) throw new TypeError('snapshot data must not contain cycles');
    seen.add(value);
    const out = {};
    for (const key of Object.keys(value).sort()) out[key] = canonicalData(value[key], seen);
    seen.delete(value);
    return out;
  }
  throw new TypeError(`snapshot data cannot contain ${typeof value}`);
}


// --- src/core/MaterialRegistry.js ---

class MaterialRegistry {
  constructor() {
    this.byId = [{
      id: 0, key: 'air', name: 'Air', ramp: ' ', solid: false, buildable: false,
      opacity: 0, emissive: 0, distanceBias: 0,
    }];
    this.byKey = new Map([['air', this.byId[0]]]);
  }

  register(key, spec = {}) {
    if (this.byKey.has(key)) throw new Error(`Material already registered: ${key}`);
    const id = this.byId.length;
    if (id > 255) throw new Error('RuneRay currently supports at most 255 non-air materials.');
    const opacity = Number.isFinite(spec.opacity) ? Math.max(0, Math.min(1, spec.opacity)) : 1;
    const material = {
      id,
      key,
      name: spec.name ?? key,
      ramp: spec.ramp ?? ' .,:;irsXA253hMHGS#9B&@',
      solid: spec.solid ?? true,
      buildable: spec.buildable ?? true,
      opacity,
      emissive: spec.emissive ?? 0,
      distanceBias: spec.distanceBias ?? 0,
    };
    this.byId[id] = material;
    this.byKey.set(key, material);
    return id;
  }

  get(id) { return this.byId[id] ?? this.byId[0]; }
  id(key) { return this.byKey.get(key)?.id ?? 0; }
  listBuildable() { return this.byId.filter(m => m?.buildable); }
  serialize() { return this.byId.filter(Boolean).map(material => canonicalData(material)); }
  restore(data = []) {
    if (!Array.isArray(data) || !data.length) return this;
    const byId = []; const byKey = new Map();
    for (const raw of data) {
      const material = canonicalData(raw);
      if (!Number.isInteger(material.id) || material.id < 0 || material.id > 255) throw new RangeError('saved material id must be 0..255');
      if (typeof material.key !== 'string' || !material.key.length) throw new TypeError('saved material key must be a non-empty string');
      if (byId[material.id]) throw new Error(`Duplicate saved material id: ${material.id}`);
      if (byKey.has(material.key)) throw new Error(`Duplicate saved material key: ${material.key}`);
      byId[material.id] = material; byKey.set(material.key, material);
    }
    if (!byId[0] || byId[0].key !== 'air') throw new Error('saved material registry must include air at id 0');
    this.byId = byId; this.byKey = byKey; return this;
  }
}


// --- src/core/ChunkedVoxelWorld.js ---
class ChunkedVoxelWorld {
  constructor(chunkSize = 16) {
    if (!Number.isInteger(chunkSize) || chunkSize <= 0) throw new TypeError('chunkSize must be a positive integer');
    this.chunkSize = chunkSize;
    this.chunkVolume = chunkSize ** 3;
    this.chunks = new Map();
    this.nonAirCount = 0;
  }

  _assertCoordinate(value, name) {
    if (!Number.isInteger(value)) throw new TypeError(`${name} must be an integer voxel coordinate`);
  }
  _assertCoordinates(x, y, z) {
    this._assertCoordinate(x, 'x'); this._assertCoordinate(y, 'y'); this._assertCoordinate(z, 'z');
  }
  _assertMaterialId(materialId) {
    if (!Number.isInteger(materialId) || materialId < 0 || materialId > 255) throw new RangeError('materialId must be an integer from 0 to 255');
  }
  _floorDiv(n) { return Math.floor(n / this.chunkSize); }
  _mod(n) { return ((n % this.chunkSize) + this.chunkSize) % this.chunkSize; }
  _key(cx, cy, cz) { return `${cx},${cy},${cz}`; }
  _index(lx, ly, lz) { return lx + ly * this.chunkSize + lz * this.chunkSize * this.chunkSize; }

  _locate(x, y, z) {
    this._assertCoordinates(x, y, z);
    const cx = this._floorDiv(x), cy = this._floorDiv(y), cz = this._floorDiv(z);
    return { cx, cy, cz, lx: this._mod(x), ly: this._mod(y), lz: this._mod(z), key: this._key(cx, cy, cz) };
  }

  get(x, y, z) {
    const p = this._locate(x, y, z);
    const chunk = this.chunks.get(p.key);
    return chunk ? chunk[this._index(p.lx, p.ly, p.lz)] : 0;
  }

  set(x, y, z, materialId) {
    this._assertMaterialId(materialId);
    const p = this._locate(x, y, z);
    let chunk = this.chunks.get(p.key);
    if (!chunk && materialId === 0) return false;
    if (!chunk) { chunk = new Uint8Array(this.chunkVolume); this.chunks.set(p.key, chunk); }
    const i = this._index(p.lx, p.ly, p.lz);
    const previous = chunk[i];
    if (previous === materialId) return false;
    chunk[i] = materialId;
    if (previous === 0 && materialId !== 0) this.nonAirCount++;
    if (previous !== 0 && materialId === 0) this.nonAirCount--;
    if (materialId === 0 && !chunk.some(Boolean)) this.chunks.delete(p.key);
    return true;
  }

  fillBox(x0, y0, z0, x1, y1, z1, materialId) {
    this._assertCoordinates(x0, y0, z0); this._assertCoordinates(x1, y1, z1); this._assertMaterialId(materialId);
    for (let z = z0; z <= z1; z++) for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) this.set(x, y, z, materialId);
  }

  clear() { this.chunks.clear(); this.nonAirCount = 0; }

  restore(data = {}) {
    if (data.chunkSize && data.chunkSize !== this.chunkSize) { this.chunkSize = data.chunkSize; this.chunkVolume = this.chunkSize ** 3; }
    this.clear();
    for (const [key, runs] of data.chunks ?? []) {
      const arr = new Uint8Array(this.chunkVolume); let i = 0;
      for (const [value, count] of runs) for (let n = 0; n < count && i < arr.length; n++) arr[i++] = value;
      if (arr.some(Boolean)) { this.chunks.set(key, arr); for (const v of arr) if (v) this.nonAirCount++; }
    }
    return this;
  }

  serialize() {
    const chunks = [];
    const entries = [...this.chunks.entries()].sort(([a], [b]) => {
      const aa = a.split(',').map(Number), bb = b.split(',').map(Number);
      return aa[0] - bb[0] || aa[1] - bb[1] || aa[2] - bb[2];
    });
    for (const [key, data] of entries) {
      const runs = [];
      let last = data[0], count = 1;
      for (let i = 1; i < data.length; i++) {
        if (data[i] === last && count < 65535) count++;
        else { runs.push([last, count]); last = data[i]; count = 1; }
      }
      runs.push([last, count]); chunks.push([key, runs]);
    }
    return { chunkSize: this.chunkSize, chunks };
  }
}


// --- src/core/Raycaster.js ---
class Raycaster {
  constructor(world, materials, maxDistance = 64) {
    this.world = world;
    this.materials = materials;
    this.maxDistance = maxDistance;
    this.maxSteps = 256;
    this.maxVisualLayers = 8;
    this.providers = [];
  }

  addProvider(provider) { if (provider && !this.providers.includes(provider)) this.providers.push(provider); return provider; }
  removeProvider(provider) { const i = this.providers.indexOf(provider); if (i >= 0) this.providers.splice(i, 1); }

  _walkWorld(origin, dx, dy, dz, maxDistance, onHit) {
    const length = Math.hypot(dx, dy, dz) || 1;
    dx /= length; dy /= length; dz /= length;

    let mx = Math.floor(origin.x), my = Math.floor(origin.y), mz = Math.floor(origin.z);
    const sx = dx < 0 ? -1 : 1, sy = dy < 0 ? -1 : 1, sz = dz < 0 ? -1 : 1;
    const ddx = dx === 0 ? Infinity : Math.abs(1 / dx);
    const ddy = dy === 0 ? Infinity : Math.abs(1 / dy);
    const ddz = dz === 0 ? Infinity : Math.abs(1 / dz);
    let tx = dx < 0 ? (origin.x - mx) * ddx : (mx + 1 - origin.x) * ddx;
    let ty = dy < 0 ? (origin.y - my) * ddy : (my + 1 - origin.y) * ddy;
    let tz = dz < 0 ? (origin.z - mz) * ddz : (mz + 1 - origin.z) * ddz;

    let dist = 0, axis = 0, nx = 0, ny = 0, nz = 0;

    const initialMaterialId = this.world.get(mx, my, mz);
    if (initialMaterialId !== 0) {
      const initialHit = {
        source: 'world', dist: 0, materialId: initialMaterialId, material: this.materials.get(initialMaterialId), axis: -1,
        x: mx, y: my, z: mz, nx: 0, ny: 0, nz: 0, hx: origin.x, hy: origin.y, hz: origin.z, contained: true,
      };
      if (onHit(initialHit) === false) return;
    }
    for (let step = 0; step < this.maxSteps; step++) {
      if (tx < ty && tx < tz) {
        mx += sx; dist = tx; tx += ddx; axis = 0; nx = -sx; ny = 0; nz = 0;
      } else if (ty < tz) {
        my += sy; dist = ty; ty += ddy; axis = 1; nx = 0; ny = -sy; nz = 0;
      } else {
        mz += sz; dist = tz; tz += ddz; axis = 2; nx = 0; ny = 0; nz = -sz;
      }
      if (dist > maxDistance) return;
      const materialId = this.world.get(mx, my, mz);
      if (materialId === 0) continue;
      const hit = {
        source: 'world', dist, materialId, material: this.materials.get(materialId), axis,
        x: mx, y: my, z: mz, nx, ny, nz,
        hx: origin.x + dx * dist, hy: origin.y + dy * dist, hz: origin.z + dz * dist,
      };
      if (onHit(hit) === false) return;
    }
  }

  _worldLayers(origin, dx, dy, dz, maxDistance, maxLayers) {
    const hits = [];
    this._walkWorld(origin, dx, dy, dz, maxDistance, hit => {
      hits.push(hit);
      if (hit.material.opacity >= 0.999 || hits.length >= maxLayers) return false;
      return true;
    });
    return hits;
  }

  cast(origin, dx, dy, dz, maxDistance = this.maxDistance) {
    return this.castLayers(origin, dx, dy, dz, maxDistance, this.maxVisualLayers)[0] ?? null;
  }

  castLayers(origin, dx, dy, dz, maxDistance = this.maxDistance, maxLayers = this.maxVisualLayers) {
    const hits = this._worldLayers(origin, dx, dy, dz, maxDistance, maxLayers);
    for (const provider of this.providers) {
      const extra = provider.castLayers?.(origin, dx, dy, dz, maxDistance, maxLayers);
      if (extra?.length) hits.push(...extra);
    }
    hits.sort((a, b) => a.dist - b.dist);
    const visible = [];
    for (const hit of hits) {
      visible.push(hit);
      if (hit.material.opacity >= 0.999 || visible.length >= maxLayers) break;
    }
    return visible;
  }
}


// --- src/core/SkyEnvironment.js ---
class SkyEnvironment {
  constructor(options = {}) {
    this.seed = options.seed ?? 1337;
    this.starDensity = options.starDensity ?? 0.07;
    this.bandStrength = options.bandStrength ?? 0.42;
    this.bandNormal = this._normalize(options.bandNormal ?? { x: 0.28, y: -0.18, z: 0.94 });
    const celestials = options.celestials ?? [
      { direction: { x: 0.82, y: -0.30, z: 0.49 }, radius: 0.12, glyphs: ' .oO0@' },
      { direction: { x: 0.92, y: 0.28, z: 0.28 }, radius: 0.055, glyphs: ' .+*#@' },
    ];
    this.celestials = celestials.map(body => ({ ...body, direction: this._normalize(body.direction ?? { x: 1, y: 0, z: 0 }) }));
  }

  _normalize(v) {
    const n = Math.hypot(v.x, v.y, v.z) || 1;
    return { x: v.x / n, y: v.y / n, z: v.z / n };
  }

  _hash(a, b, c = 0) {
    let h = Math.imul((a | 0) ^ this.seed, 374761393) ^ Math.imul((b | 0) + 17, 668265263) ^ Math.imul((c | 0) + 31, 2246822519);
    h ^= h >>> 13; h = Math.imul(h, 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967295;
  }

  sample(dx, dy, dz) {
    const n = Math.hypot(dx, dy, dz) || 1;
    dx /= n; dy /= n; dz /= n;

    for (const body of this.celestials) {
      const dot = dx * body.direction.x + dy * body.direction.y + dz * body.direction.z;
      const angle = Math.acos(Math.max(-1, Math.min(1, dot)));
      if (angle < body.radius) {
        const edge = angle / body.radius;
        const ramp = body.glyphs || ' .oO@';
        const idx = Math.max(0, Math.min(ramp.length - 1, Math.floor((1 - edge) * (ramp.length - 1))));
        return ramp[idx] || ' ';
      }
    }

    const az = Math.atan2(dy, dx);
    const el = Math.asin(Math.max(-1, Math.min(1, dz)));
    const qx = Math.floor((az + Math.PI) * 46);
    const qy = Math.floor((el + Math.PI / 2) * 58);
    const star = this._hash(qx, qy);
    if (star < this.starDensity * 0.12) return '*';
    if (star < this.starDensity * 0.34) return '+';
    if (star < this.starDensity) return '.';

    const bandDistance = Math.abs(dx * this.bandNormal.x + dy * this.bandNormal.y + dz * this.bandNormal.z);
    const band = Math.max(0, 1 - bandDistance / 0.24) * this.bandStrength;
    if (band > 0) {
      const dust = this._hash(qx, qy, 91);
      if (dust < band * 0.12) return ':';
      if (dust < band * 0.34) return ',';
      if (dust < band * 0.62) return '.';
    }
    return ' ';
  }
}


// --- src/core/SpriteSystem.js ---
class SpriteSystem {
  constructor() { this.sprites = new Map(); }

  _allocateId() { let n = 1; while (this.sprites.has(`sprite-${n}`)) n++; return `sprite-${n}`; }

  add(spec = {}) {
    const id = spec.id ?? this._allocateId();
    if (typeof id !== 'string' || !id.length) throw new TypeError('sprite id must be a non-empty string');
    if (this.sprites.has(id)) throw new Error(`Sprite already exists: ${id}`);
    const sprite = {
      id, x: spec.x ?? 0, y: spec.y ?? 0, z: spec.z ?? 0,
      width: Math.max(0.05, spec.width ?? 0.8), height: Math.max(0.05, spec.height ?? 1.2),
      art: Array.isArray(spec.art) ? spec.art.slice() : [String(spec.art ?? '@')], visible: spec.visible ?? true,
      vx: spec.vx ?? 0, vy: spec.vy ?? 0, vz: spec.vz ?? 0, update: spec.update ?? null, tag: spec.tag ?? null,
    };
    this.sprites.set(id, sprite); return sprite;
  }

  get(id) { return this.sprites.get(id) ?? null; }
  remove(id) { return this.sprites.delete(typeof id === 'string' ? id : id?.id); }
  clear() { this.sprites.clear(); }
  list() { return [...this.sprites.values()].filter(s => s.visible); }
  serialize() {
    return [...this.sprites.values()].sort((a, b) => a.id.localeCompare(b.id)).map(sprite => ({
      id: sprite.id, x: sprite.x, y: sprite.y, z: sprite.z, width: sprite.width, height: sprite.height,
      art: sprite.art.slice(), visible: sprite.visible, vx: sprite.vx, vy: sprite.vy, vz: sprite.vz, tag: sprite.tag,
    }));
  }
  restore(data = []) {
    const seen = new Set();
    for (const snap of data) {
      let sprite = this.sprites.get(snap.id);
      if (!sprite) sprite = this.add(snap);
      else Object.assign(sprite, snap, { art: (snap.art ?? sprite.art).slice(), update: sprite.update });
      seen.add(snap.id);
    }
    for (const id of [...this.sprites.keys()]) if (!seen.has(id) && !id.startsWith('entity-sprite:')) this.sprites.delete(id);
    return this;
  }
  update(dt, engine) {
    for (const sprite of this.sprites.values()) {
      sprite.x += sprite.vx * dt; sprite.y += sprite.vy * dt; sprite.z += sprite.vz * dt;
      sprite.update?.(dt, sprite, engine);
    }
  }
}


// --- src/core/EntitySystem.js ---

class EntitySystem {
  constructor(spriteSystem = null) { this.spriteSystem = spriteSystem; this.entities = new Map(); }
  _allocateId() { let n = 1; while (this.entities.has(`entity-${n}`)) n++; return `entity-${n}`; }
  add(spec = {}) {
    const id = spec.id ?? this._allocateId();
    if (typeof id !== 'string' || !id.length) throw new TypeError('entity id must be a non-empty string');
    if (this.entities.has(id)) throw new Error(`Entity already exists: ${id}`);
    const entity = { id, type: spec.type ?? 'entity', name: spec.name ?? id, x: spec.x ?? 0, y: spec.y ?? 0, z: spec.z ?? 0,
      radius: Math.max(0.02, spec.radius ?? 0.35), height: Math.max(0.02, spec.height ?? 1), visible: spec.visible ?? true,
      enabled: spec.enabled ?? true, state: { ...(spec.state ?? {}) }, tags: new Set(spec.tags ?? []), interactions: { ...(spec.interactions ?? {}) },
      update: spec.update ?? null, spriteId: null };
    if (spec.sprite && this.spriteSystem) {
      const sprite = this.spriteSystem.add({ id: spec.sprite.id ?? `entity-sprite:${id}`, x: entity.x, y: entity.y,
        z: spec.sprite.z ?? (entity.z + entity.height * 0.5), width: spec.sprite.width ?? Math.max(0.3, entity.radius * 2),
        height: spec.sprite.height ?? entity.height, art: spec.sprite.art ?? ['@'], visible: entity.visible, tag: spec.sprite.tag ?? 'entity' });
      entity.spriteId = sprite.id;
    }
    this.entities.set(id, entity); return entity;
  }
  get(id) { return this.entities.get(typeof id === 'string' ? id : id?.id) ?? null; }
  remove(id) { const e = this.get(id); if (!e) return false; if (e.spriteId && this.spriteSystem) this.spriteSystem.remove(e.spriteId); return this.entities.delete(e.id); }
  clear() { if (this.spriteSystem) for (const e of this.entities.values()) if (e.spriteId) this.spriteSystem.remove(e.spriteId); this.entities.clear(); }
  list() { return [...this.entities.values()]; }
  findByTag(tag) { return this.list().filter(e => e.tags.has(tag)); }
  restore(data = []) {
    const seen = new Set();
    for (const snap of data) {
      let e = this.entities.get(snap.id);
      if (!e) e = this.add({ ...snap, tags: snap.tags ?? [], state: snap.state ?? {} });
      const interactions = e.interactions, update = e.update, spriteId = e.spriteId;
      Object.assign(e, snap, { state:{...(snap.state??{})}, tags:new Set(snap.tags??[]), interactions, update, spriteId: snap.spriteId ?? spriteId });
      seen.add(e.id);
    }
    for (const e of this.entities.values()) if (!seen.has(e.id)) { e.enabled = false; e.visible = false; }
    return this;
  }
  serialize() {
    return [...this.entities.values()].sort((a,b)=>a.id.localeCompare(b.id)).map(e => ({
      id:e.id, type:e.type, name:e.name, x:e.x, y:e.y, z:e.z, radius:e.radius, height:e.height,
      visible:e.visible, enabled:e.enabled, state:canonicalData(e.state), tags:[...e.tags].sort(), spriteId:e.spriteId,
    }));
  }
  update(dt, engine) { for (const e of this.entities.values()) { if (e.enabled) e.update?.(dt, e, engine); if (!e.spriteId || !this.spriteSystem) continue;
      const s = this.spriteSystem.get(e.spriteId); if (!s) continue; s.x = e.x; s.y = e.y; s.z = e.z + e.height * 0.5; s.visible = e.visible && e.enabled; } }
}


// --- src/core/InteractionSystem.js ---
class InteractionSystem {
  constructor(entities, raycaster, options = {}) { this.entities = entities; this.raycaster = raycaster; this.reach = options.reach ?? 3.25; this.aimCone = options.aimCone ?? 0.965; this.target = null; }
  actionsFor(entity) { if (!entity?.enabled) return []; return Object.keys(entity.interactions ?? {}).filter(k => typeof entity.interactions[k] === 'function'); }
  findTarget(camera) {
    const cp = Math.cos(camera.pitch), sp = Math.sin(camera.pitch), fx = Math.cos(camera.yaw) * cp, fy = Math.sin(camera.yaw) * cp, fz = sp;
    let best = null, bestScore = -Infinity;
    for (const entity of this.entities.list()) {
      if (!entity.enabled || !this.actionsFor(entity).length) continue;
      const vx = entity.x - camera.x, vy = entity.y - camera.y, vz = entity.z + entity.height * 0.5 - camera.z, dist = Math.hypot(vx, vy, vz);
      if (dist < 0.03 || dist > this.reach + entity.radius) continue;
      const inv = 1 / dist, dx = vx * inv, dy = vy * inv, dz = vz * inv, dot = dx * fx + dy * fy + dz * fz;
      const assist = Math.min(0.08, entity.radius / Math.max(0.5, dist) * 0.45); if (dot < this.aimCone - assist) continue;
      const obstruction = this.raycaster.cast(camera, dx, dy, dz); if (obstruction && obstruction.dist < dist - Math.max(0.08, entity.radius * 0.55)) continue;
      const score = dot * 4 - dist * 0.16 + assist; if (score > bestScore || (score === bestScore && (!best || entity.id.localeCompare(best.entity.id) < 0))) { bestScore = score; best = { entity, dist, dot }; }
    }
    this.target = best; return best;
  }
  interact(camera, action = 'primary', engine = null) {
    const target = this.findTarget(camera); if (!target) return { ok: false, reason: 'Nothing to interact with' };
    const actions = this.actionsFor(target.entity), chosen = target.entity.interactions[action] ? action : actions[0], handler = target.entity.interactions[chosen];
    if (!handler) return { ok: false, reason: 'No available interaction', target: target.entity };
    const result = handler({ entity: target.entity, action: chosen, engine, interaction: this, distance: target.dist });
    if (result === false) return { ok: false, reason: 'Interaction blocked', target: target.entity, action: chosen };
    if (typeof result === 'string') return { ok: true, message: result, target: target.entity, action: chosen };
    return { ok: true, ...(result ?? {}), target: target.entity, action: chosen };
  }
}


// --- src/core/MicroVoxelBody.js ---
class MicroVoxelBody {
  constructor(spec = {}) {
    if (typeof spec.id !== 'string' || !spec.id.length) throw new TypeError('MicroVoxelBody requires a non-empty deterministic id');
    this.id = spec.id;
    this.voxelSize = Math.max(0.05, Number(spec.voxelSize ?? 0.25));
    this.sizeX = this._size(spec.sizeX ?? 4, 'sizeX'); this.sizeY = this._size(spec.sizeY ?? 4, 'sizeY'); this.sizeZ = this._size(spec.sizeZ ?? 4, 'sizeZ');
    this.data = new Uint8Array(this.sizeX * this.sizeY * this.sizeZ);
    this.x = spec.x ?? 0; this.y = spec.y ?? 0; this.z = spec.z ?? 0;
    this.vx = spec.vx ?? 0; this.vy = spec.vy ?? 0; this.vz = spec.vz ?? 0;
    this.dynamic = spec.dynamic ?? true; this.gravityScale = spec.gravityScale ?? 0;
    this.restitution = Math.max(0, Math.min(1, spec.restitution ?? 0.2)); this.tag = spec.tag ?? null;
  }
  _size(value, name) { if (!Number.isInteger(value) || value < 1) throw new TypeError(`${name} must be a positive integer`); return value; }
  _index(x, y, z) { return x + y * this.sizeX + z * this.sizeX * this.sizeY; }
  inBounds(x, y, z) { return Number.isInteger(x) && Number.isInteger(y) && Number.isInteger(z) && x >= 0 && y >= 0 && z >= 0 && x < this.sizeX && y < this.sizeY && z < this.sizeZ; }
  get(x, y, z) { return this.inBounds(x, y, z) ? this.data[this._index(x, y, z)] : 0; }
  set(x, y, z, materialId) {
    if (!this.inBounds(x, y, z)) return false;
    if (!Number.isInteger(materialId) || materialId < 0 || materialId > 255) throw new RangeError('materialId must be an integer from 0 to 255');
    const i = this._index(x, y, z); if (this.data[i] === materialId) return false; this.data[i] = materialId; return true;
  }
  fillBox(x0, y0, z0, x1, y1, z1, materialId) { for (let z=z0;z<=z1;z++) for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++) this.set(x,y,z,materialId); }
  boundsAt(x=this.x,y=this.y,z=this.z) { return { minX:x,minY:y,minZ:z,maxX:x+this.sizeX*this.voxelSize,maxY:y+this.sizeY*this.voxelSize,maxZ:z+this.sizeZ*this.voxelSize }; }
  serialize() { return { id:this.id, voxelSize:this.voxelSize, size:[this.sizeX,this.sizeY,this.sizeZ], position:[this.x,this.y,this.z], velocity:[this.vx,this.vy,this.vz], dynamic:this.dynamic, gravityScale:this.gravityScale, restitution:this.restitution, tag:this.tag, data:Array.from(this.data) }; }
}


// --- src/core/MicroVoxelSystem.js ---

class MicroVoxelSystem {
  constructor(world, materials, options = {}) {
    this.world = world;
    this.materials = materials;
    this.bodies = new Map();
    this.gravity = options.gravity ?? { x: 0, y: 0, z: 0 };
    this.maxLayersPerBody = 8;
  }

  _allocateId() { let n = 1; while (this.bodies.has(`micro-${n}`)) n++; return `micro-${n}`; }

  createBody(spec = {}) {
    const id = spec.id ?? this._allocateId();
    if (typeof id !== 'string' || !id.length) throw new TypeError('micro body id must be a non-empty string');
    if (this.bodies.has(id)) throw new Error(`Micro voxel body already exists: ${id}`);
    const body = new MicroVoxelBody({ ...spec, id });
    this.bodies.set(body.id, body);
    return body;
  }
  removeBody(id) { return this.bodies.delete(typeof id === 'string' ? id : id?.id); }
  get(id) { return this.bodies.get(id) ?? null; }
  list() { return [...this.bodies.values()]; }
  serialize() { return { gravity: { ...this.gravity }, bodies: [...this.bodies.values()].sort((a,b)=>a.id.localeCompare(b.id)).map(body=>body.serialize()) }; }

  restore(data = {}) {
    if (data.gravity) this.gravity = { ...data.gravity };
    const seen = new Set();
    for (const snap of data.bodies ?? []) {
      let body = this.bodies.get(snap.id);
      if (!body) body = this.createBody({ id:snap.id, voxelSize:snap.voxelSize, sizeX:snap.size?.[0]??4, sizeY:snap.size?.[1]??4, sizeZ:snap.size?.[2]??4 });
      body.x=snap.position?.[0]??body.x; body.y=snap.position?.[1]??body.y; body.z=snap.position?.[2]??body.z;
      body.vx=snap.velocity?.[0]??0; body.vy=snap.velocity?.[1]??0; body.vz=snap.velocity?.[2]??0; body.dynamic=snap.dynamic??body.dynamic; body.gravityScale=snap.gravityScale??body.gravityScale; body.restitution=snap.restitution??body.restitution; body.tag=snap.tag??body.tag;
      if (Array.isArray(snap.data) && snap.data.length === body.data.length) body.data.set(snap.data); seen.add(body.id);
    }
    for (const id of [...this.bodies.keys()]) if (!seen.has(id)) this.bodies.delete(id);
    return this;
  }

  _slab(origin, dir, min, max) {
    if (Math.abs(dir) < 1e-9) return origin >= min && origin <= max ? [-Infinity, Infinity] : [Infinity, -Infinity];
    const a = (min - origin) / dir, b = (max - origin) / dir;
    return a < b ? [a, b] : [b, a];
  }

  _castBody(body, origin, dx, dy, dz, maxDistance) {
    const len = Math.hypot(dx, dy, dz) || 1; dx /= len; dy /= len; dz /= len;
    const b = body.boundsAt();
    const sx = this._slab(origin.x, dx, b.minX, b.maxX), sy = this._slab(origin.y, dy, b.minY, b.maxY), sz = this._slab(origin.z, dz, b.minZ, b.maxZ);
    let tEnter = Math.max(0, sx[0], sy[0], sz[0]);
    const tExit = Math.min(maxDistance, sx[1], sy[1], sz[1]);
    if (!(tEnter <= tExit)) return [];

    const eps = 1e-6, s = body.voxelSize;
    let px = origin.x + dx * (tEnter + eps), py = origin.y + dy * (tEnter + eps), pz = origin.z + dz * (tEnter + eps);
    let ix = Math.floor((px - body.x) / s), iy = Math.floor((py - body.y) / s), iz = Math.floor((pz - body.z) / s);
    ix = Math.max(0, Math.min(body.sizeX - 1, ix)); iy = Math.max(0, Math.min(body.sizeY - 1, iy)); iz = Math.max(0, Math.min(body.sizeZ - 1, iz));
    const stepx = dx < 0 ? -1 : 1, stepy = dy < 0 ? -1 : 1, stepz = dz < 0 ? -1 : 1;
    const ddx = dx === 0 ? Infinity : s / Math.abs(dx), ddy = dy === 0 ? Infinity : s / Math.abs(dy), ddz = dz === 0 ? Infinity : s / Math.abs(dz);
    const nextX = () => body.x + (stepx > 0 ? ix + 1 : ix) * s;
    const nextY = () => body.y + (stepy > 0 ? iy + 1 : iy) * s;
    const nextZ = () => body.z + (stepz > 0 ? iz + 1 : iz) * s;
    let tx = dx === 0 ? Infinity : tEnter + (nextX() - px) / dx;
    let ty = dy === 0 ? Infinity : tEnter + (nextY() - py) / dy;
    let tz = dz === 0 ? Infinity : tEnter + (nextZ() - pz) / dz;
    let t = tEnter, axis = -1, nx = -Math.sign(dx), ny = 0, nz = 0;
    const hits = [];

    for (let step = 0; step < 256 && t <= tExit; step++) {
      const materialId = body.get(ix, iy, iz);
      if (materialId) {
        const material = this.materials.get(materialId);
        hits.push({
          source: 'micro', body, dist: Math.max(0, t), materialId, material, axis,
          x: body.x + ix * s, y: body.y + iy * s, z: body.z + iz * s,
          cellX: ix, cellY: iy, cellZ: iz, nx, ny, nz,
          hx: origin.x + dx * Math.max(0, t), hy: origin.y + dy * Math.max(0, t), hz: origin.z + dz * Math.max(0, t),
        });
        if (material.opacity >= 0.999 || hits.length >= this.maxLayersPerBody) break;
      }
      if (tx < ty && tx < tz) {
        t = tx; tx += ddx; ix += stepx; axis = 0; nx = -stepx; ny = 0; nz = 0;
      } else if (ty < tz) {
        t = ty; ty += ddy; iy += stepy; axis = 1; nx = 0; ny = -stepy; nz = 0;
      } else {
        t = tz; tz += ddz; iz += stepz; axis = 2; nx = 0; ny = 0; nz = -stepz;
      }
      if (!body.inBounds(ix, iy, iz)) break;
    }
    return hits;
  }

  castLayers(origin, dx, dy, dz, maxDistance = 64) {
    const hits = [];
    for (const body of this.bodies.values()) hits.push(...this._castBody(body, origin, dx, dy, dz, maxDistance));
    return hits.sort((a, b) => a.dist - b.dist);
  }

  _collidesWorld(body, x, y, z) {
    const s = body.voxelSize;
    const eps = 1e-5;
    for (let iz = 0; iz < body.sizeZ; iz++) for (let iy = 0; iy < body.sizeY; iy++) for (let ix = 0; ix < body.sizeX; ix++) {
      const bodyMaterial = this.materials.get(body.get(ix, iy, iz));
      if (!bodyMaterial.solid) continue;
      const minX = x + ix * s + eps, maxX = x + (ix + 1) * s - eps;
      const minY = y + iy * s + eps, maxY = y + (iy + 1) * s - eps;
      const minZ = z + iz * s + eps, maxZ = z + (iz + 1) * s - eps;
      for (const wx of [minX, maxX]) for (const wy of [minY, maxY]) for (const wz of [minZ, maxZ]) {
        const worldMaterial = this.materials.get(this.world.get(Math.floor(wx), Math.floor(wy), Math.floor(wz)));
        if (worldMaterial.solid) return true;
      }
    }
    return false;
  }

  update(dt) {
    for (const body of this.bodies.values()) {
      if (!body.dynamic) continue;
      body.vx += this.gravity.x * body.gravityScale * dt;
      body.vy += this.gravity.y * body.gravityScale * dt;
      body.vz += this.gravity.z * body.gravityScale * dt;
      const axes = [
        ['x', 'vx'], ['y', 'vy'], ['z', 'vz'],
      ];
      for (const [posKey, velKey] of axes) {
        const next = body[posKey] + body[velKey] * dt;
        const x = posKey === 'x' ? next : body.x, y = posKey === 'y' ? next : body.y, z = posKey === 'z' ? next : body.z;
        if (this._collidesWorld(body, x, y, z)) body[velKey] *= -body.restitution;
        else body[posKey] = next;
      }
      if (Math.abs(body.vx) < 0.002) body.vx = 0;
      if (Math.abs(body.vy) < 0.002) body.vy = 0;
      if (Math.abs(body.vz) < 0.002) body.vz = 0;
    }
  }
}


// --- src/core/Inventory.js ---

class Inventory {
  constructor(slotCount = 12) {
    this.slotCount = Math.max(1, slotCount | 0);
    this.slots = Array.from({ length: this.slotCount }, () => null);
    this.itemDefs = new Map();
  }

  define(id, spec = {}) {
    const def = { id, name: spec.name ?? id, glyph: spec.glyph ?? '?', maxStack: Math.max(1, spec.maxStack ?? 99), data: spec.data ?? null, equipSlot: spec.equipSlot ?? null, stats: { ...(spec.stats ?? {}) }, damage: spec.damage ?? null, range: spec.range ?? null, cooldown: spec.cooldown ?? null };
    this.itemDefs.set(id, def); return def;
  }
  def(id) { return this.itemDefs.get(id) ?? { id, name: id, glyph: '?', maxStack: 99 }; }
  count(id) { return this.slots.reduce((n, s) => n + (s?.id === id ? s.count : 0), 0); }
  add(id, count = 1) {
    let remain = Math.max(0, count | 0), def = this.def(id);
    for (const slot of this.slots) if (slot?.id === id && slot.count < def.maxStack && remain) {
      const add = Math.min(remain, def.maxStack - slot.count); slot.count += add; remain -= add;
    }
    for (let i = 0; i < this.slots.length && remain; i++) if (!this.slots[i]) {
      const add = Math.min(remain, def.maxStack); this.slots[i] = { id, count: add }; remain -= add;
    }
    return count - remain;
  }
  remove(id, count = 1) {
    let need = Math.max(0, count | 0), removed = 0;
    for (let i = this.slots.length - 1; i >= 0 && need; i--) {
      const slot = this.slots[i]; if (!slot || slot.id !== id) continue;
      const take = Math.min(need, slot.count); slot.count -= take; need -= take; removed += take;
      if (slot.count <= 0) this.slots[i] = null;
    }
    return removed;
  }
  has(id, count = 1) { return this.count(id) >= count; }
  serialize() {
    const definitions = [...this.itemDefs.values()].sort((a, b) => String(a.id).localeCompare(String(b.id))).map(def => canonicalData(def));
    return { slotCount: this.slotCount, definitions, slots: this.slots.map(s => s ? canonicalData(s) : null) };
  }
  restore(data = {}) {
    const count = Math.max(1, data.slotCount ?? this.slotCount);
    if (Array.isArray(data.definitions)) {
      this.itemDefs.clear();
      for (const raw of data.definitions) {
        const def = canonicalData(raw);
        if (def?.id == null) throw new TypeError('saved item definition requires an id');
        this.itemDefs.set(def.id, def);
      }
    }
    this.slotCount = count; this.slots = Array.from({ length: count }, (_, i) => data.slots?.[i] ? canonicalData(data.slots[i]) : null);
    return this;
  }
}



// --- src/core/MenuState.js ---
class MenuState {
  constructor() { this.open = false; this.tab = 'inventory'; this.listeners = new Set(); }
  setOpen(open) { this.open = !!open; this._emit(); }
  toggle() { this.setOpen(!this.open); }
  setTab(tab) { this.tab = tab; this._emit(); }
  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  _emit() { for (const fn of this.listeners) fn(this); }
}


// --- src/core/DeterministicRng.js ---
class DeterministicRng {
  constructor(seed = 1) {
    const normalized = Number(seed) >>> 0;
    this.seed = normalized || 1;
    this.state = this.seed;
  }

  nextUint32() {
    let x = this.state >>> 0;
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    this.state = x >>> 0;
    return this.state;
  }

  next() { return this.nextUint32() / 4294967296; }
  serialize() { return { seed: this.seed, state: this.state }; }
}


// --- src/core/EventBus.js ---
class EventBus {
  constructor() { this.listeners = new Map(); }
  on(type, fn) {
    if (typeof fn !== 'function') throw new TypeError('event listener must be a function');
    const set = this.listeners.get(type) ?? new Set(); set.add(fn); this.listeners.set(type, set);
    return () => this.off(type, fn);
  }
  once(type, fn) { let off = null; off = this.on(type, payload => { off?.(); fn(payload); }); return off; }
  off(type, fn) { const set = this.listeners.get(type); if (!set) return false; const removed = set.delete(fn); if (!set.size) this.listeners.delete(type); return removed; }
  emit(type, payload = {}) { for (const fn of [...(this.listeners.get(type) ?? [])]) fn(payload); }
  clear(type = null) { if (type == null) this.listeners.clear(); else this.listeners.delete(type); }
}


// --- src/core/NavigationSystem.js ---
class NavigationSystem {
  constructor(world, materials, options = {}) {
    this.world = world; this.materials = materials;
    this.maxNodes = Math.max(32, options.maxNodes ?? 900);
    this.defaultHeightCells = Math.max(1, options.heightCells ?? 2);
  }
  _solid(x, y, z) { return this.materials.get(this.world.get(x, y, z)).solid; }
  isWalkable(x, y, z, heightCells = this.defaultHeightCells) {
    if (!Number.isInteger(x) || !Number.isInteger(y) || !Number.isInteger(z)) return false;
    if (!this._solid(x, y, z - 1)) return false;
    for (let h = 0; h < heightCells; h++) if (this._solid(x, y, z + h)) return false;
    return true;
  }
  nearestWalkable(x, y, z, radius = 2) {
    const sx = Math.floor(x), sy = Math.floor(y), sz = Math.floor(z);
    for (let r = 0; r <= radius; r++) for (let dz = -1; dz <= 1; dz++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r && r !== 0) continue;
      const nx = sx + dx, ny = sy + dy, nz = sz + dz;
      if (this.isWalkable(nx, ny, nz)) return { x: nx, y: ny, z: nz };
    }
    return null;
  }
  _neighbors(node, allowVertical = true) {
    const out = [];
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const x = node.x + dx, y = node.y + dy;
      const zs = allowVertical ? [node.z, node.z + 1, node.z - 1] : [node.z];
      for (const z of zs) { if (this.isWalkable(x, y, z)) { out.push({ x, y, z }); break; } }
    }
    return out;
  }
  findPath(start, goal, options = {}) {
    const a = this.nearestWalkable(start.x, start.y, start.z, options.snapRadius ?? 2);
    const b = this.nearestWalkable(goal.x, goal.y, goal.z, options.snapRadius ?? 2);
    if (!a || !b) return [];
    const key = n => `${n.x},${n.y},${n.z}`;
    const heuristic = n => Math.abs(n.x - b.x) + Math.abs(n.y - b.y) + Math.abs(n.z - b.z) * 1.25;
    const startKey = key(a), goalKey = key(b), open = [{ ...a, g: 0, f: heuristic(a) }];
    const best = new Map([[startKey, 0]]), came = new Map(); let visited = 0;
    while (open.length && visited++ < (options.maxNodes ?? this.maxNodes)) {
      open.sort((p, q) => p.f - q.f || p.g - q.g || p.z - q.z || p.y - q.y || p.x - q.x);
      const cur = open.shift(), ck = key(cur);
      if (ck === goalKey) {
        const path = [{ x: cur.x + 0.5, y: cur.y + 0.5, z: cur.z + 0.02 }]; let k = ck;
        while (came.has(k)) { const prev = came.get(k); path.push({ x: prev.node.x + 0.5, y: prev.node.y + 0.5, z: prev.node.z + 0.02 }); k = prev.key; }
        path.reverse(); return path;
      }
      for (const n of this._neighbors(cur, options.allowVertical ?? true)) {
        const nk = key(n), step = 1 + Math.abs(n.z - cur.z) * 0.35, g = cur.g + step;
        if (g >= (best.get(nk) ?? Infinity)) continue;
        best.set(nk, g); came.set(nk, { key: ck, node: cur }); open.push({ ...n, g, f: g + heuristic(n) });
      }
    }
    return [];
  }
  lineOfSight(a, b, raycaster, padding = 0.18) {
    const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, dist = Math.hypot(dx, dy, dz);
    if (dist < 1e-6) return true;
    const hit = raycaster.cast(a, dx, dy, dz, dist);
    return !hit || hit.dist >= dist - padding;
  }
}


// --- src/core/AISystem.js ---
class AISystem {
  constructor(entities, navigation, raycaster, events, options = {}) {
    this.entities = entities; this.navigation = navigation; this.raycaster = raycaster; this.events = events;
    this.agents = new Map(); this.defaultRepath = options.repathInterval ?? 0.65;
  }
  add(entityOrId, spec = {}) {
    const entity = this.entities.get(entityOrId); if (!entity) throw new Error('AI agent requires an existing entity');
    const agent = {
      entityId: entity.id, mode: spec.mode ?? 'idle', state: spec.state ?? 'idle', speed: Math.max(0, spec.speed ?? 1.25),
      vision: Math.max(0, spec.vision ?? 7), stopDistance: Math.max(0.05, spec.stopDistance ?? 0.75),
      repathInterval: Math.max(0.05, spec.repathInterval ?? this.defaultRepath), repathTimer: 0,
      target: spec.target ?? null, patrol: (spec.patrol ?? []).map(p => ({ ...p })), patrolIndex: spec.patrolIndex ?? 0,
      wanderRadius: Math.max(1, spec.wanderRadius ?? 4), home: spec.home ? { ...spec.home } : { x: entity.x, y: entity.y, z: entity.z },
      path: [], pathIndex: 0, enabled: spec.enabled ?? true, data: { ...(spec.data ?? {}) },
    };
    this.agents.set(entity.id, agent); return agent;
  }
  get(entityOrId) { return this.agents.get(typeof entityOrId === 'string' ? entityOrId : entityOrId?.id) ?? null; }
  remove(entityOrId) { return this.agents.delete(typeof entityOrId === 'string' ? entityOrId : entityOrId?.id); }
  _targetPosition(agent, engine) {
    if (agent.mode === 'chase' || agent.mode === 'flee') {
      if (agent.target === 'player' || agent.target == null) return engine.camera;
      return this.entities.get(agent.target) ?? null;
    }
    if (agent.mode === 'patrol' && agent.patrol.length) return agent.patrol[agent.patrolIndex % agent.patrol.length];
    if (agent.mode === 'wander') {
      if (!agent.data.wanderGoal) {
        const angle = engine.random() * Math.PI * 2, radius = (0.35 + engine.random() * 0.65) * agent.wanderRadius;
        agent.data.wanderGoal = { x: agent.home.x + Math.cos(angle) * radius, y: agent.home.y + Math.sin(angle) * radius, z: agent.home.z };
      }
      return agent.data.wanderGoal;
    }
    return null;
  }
  _repath(agent, entity, target, engine) {
    if (!target) { agent.path = []; return; }
    let goal = target;
    if (agent.mode === 'flee') {
      const dx = entity.x - target.x, dy = entity.y - target.y, len = Math.hypot(dx, dy) || 1;
      goal = { x: entity.x + dx / len * agent.vision, y: entity.y + dy / len * agent.vision, z: entity.z };
    }
    agent.path = this.navigation.findPath(entity, goal, { maxNodes: 700 }); agent.pathIndex = Math.min(1, Math.max(0, agent.path.length - 1));
    agent.repathTimer = agent.repathInterval;
    this.events?.emit('ai:path', { agent, entity, path: agent.path, engine });
  }
  _move(agent, entity, dt) {
    const p = agent.path[agent.pathIndex]; if (!p) return false;
    const dx = p.x - entity.x, dy = p.y - entity.y, dz = p.z - entity.z, dist = Math.hypot(dx, dy, dz);
    if (dist < 0.12) { agent.pathIndex++; return true; }
    const step = Math.min(dist, agent.speed * dt); entity.x += dx / dist * step; entity.y += dy / dist * step; entity.z += dz / dist * step; return true;
  }
  update(dt, engine) {
    for (const agent of this.agents.values()) {
      const entity = this.entities.get(agent.entityId); if (!agent.enabled || !entity?.enabled) continue;
      let target = this._targetPosition(agent, engine);
      if ((agent.mode === 'chase' || agent.mode === 'flee') && target) {
        const dist = Math.hypot(entity.x - target.x, entity.y - target.y, (entity.z + entity.height * .5) - target.z);
        const seen = dist <= agent.vision && this.navigation.lineOfSight({ x: entity.x, y: entity.y, z: entity.z + entity.height * .5 }, target, this.raycaster, entity.radius);
        agent.state = seen ? agent.mode : 'search';
        if (!seen && agent.mode === 'chase' && !agent.path.length) continue;
      } else agent.state = agent.mode;
      agent.repathTimer -= dt;
      if (agent.repathTimer <= 0 || agent.pathIndex >= agent.path.length) this._repath(agent, entity, target, engine);
      const moved = this._move(agent, entity, dt);
      if (!moved && agent.mode === 'patrol' && agent.patrol.length) { agent.patrolIndex = (agent.patrolIndex + 1) % agent.patrol.length; agent.repathTimer = 0; }
      if (!moved && agent.mode === 'wander') { agent.data.wanderGoal = null; agent.repathTimer = 0; }
      if (target && agent.mode === 'patrol' && Math.hypot(entity.x-target.x, entity.y-target.y, entity.z-target.z) <= agent.stopDistance) { agent.patrolIndex = (agent.patrolIndex + 1) % agent.patrol.length; agent.repathTimer = 0; }
    }
  }
  serialize() { return [...this.agents.values()].sort((a,b)=>a.entityId.localeCompare(b.entityId)).map(a => ({ ...a, home:{...a.home}, patrol:a.patrol.map(p=>({...p})), path:a.path.map(p=>({...p})), data:{...a.data} })); }
  restore(data = []) { for (const snap of data) { const a = this.agents.get(snap.entityId); if (!a) continue; Object.assign(a, snap, { home:{...snap.home}, patrol:(snap.patrol??[]).map(p=>({...p})), path:(snap.path??[]).map(p=>({...p})), data:{...(snap.data??{})} }); } }
}


// --- src/core/EquipmentSystem.js ---
class EquipmentSystem {
  constructor(inventory, events = null, slots = ['mainHand','offHand','body','utility']) { this.inventory = inventory; this.events = events; this.slots = new Map(slots.map(s => [s, null])); }
  equip(itemId, slot = null) {
    const def = this.inventory.def(itemId), target = slot ?? def.equipSlot;
    if (!target || !this.slots.has(target)) return { ok:false, reason:'Item cannot be equipped there' };
    if (!this.inventory.has(itemId,1)) return { ok:false, reason:'Item not in inventory' };
    const previous = this.slots.get(target); if (previous) this.inventory.add(previous,1);
    this.inventory.remove(itemId,1); this.slots.set(target,itemId); this.events?.emit('equipment:changed',{slot:target,itemId,previous}); return {ok:true,slot:target,itemId,previous};
  }
  unequip(slot) { if (!this.slots.has(slot)) return {ok:false,reason:'Unknown slot'}; const itemId=this.slots.get(slot); if(!itemId)return{ok:false,reason:'Slot is empty'}; this.slots.set(slot,null); this.inventory.add(itemId,1); this.events?.emit('equipment:changed',{slot,itemId:null,previous:itemId}); return{ok:true,itemId}; }
  get(slot) { return this.slots.get(slot) ?? null; }
  bonuses() { const out={}; for(const itemId of this.slots.values()){if(!itemId)continue; const stats=this.inventory.def(itemId).stats??{}; for(const [k,v] of Object.entries(stats)) out[k]=(out[k]??0)+(Number(v)||0);} return out; }
  serialize(){return Object.fromEntries([...this.slots.entries()].sort(([a],[b])=>a.localeCompare(b)));}
  restore(data={}){for(const slot of this.slots.keys())this.slots.set(slot,data[slot]??null);}
}


// --- src/core/CombatSystem.js ---
class CombatSystem {
  constructor(entities, equipment, events = null) { this.entities=entities; this.equipment=equipment; this.events=events; this.actors=new Map(); this.cooldowns=new Map(); }
  defineActor(idOrEntity, stats={}) { const id=typeof idOrEntity==='string'?idOrEntity:idOrEntity?.id; if(!id)throw new TypeError('combat actor requires id'); const maxHp=Math.max(1,stats.maxHp??stats.hp??10); const actor={id,maxHp,hp:Math.max(0,Math.min(maxHp,stats.hp??maxHp)),attack:Math.max(0,stats.attack??1),defense:Math.max(0,stats.defense??0),alive:stats.alive??true,faction:stats.faction??'neutral',data:{...(stats.data??{})}}; this.actors.set(id,actor); return actor; }
  get(idOrEntity){return this.actors.get(typeof idOrEntity==='string'?idOrEntity:idOrEntity?.id)??null;}
  position(id,engine){if(id==='player')return engine.camera; return this.entities.get(id)??null;}
  damage(targetId,amount,sourceId=null,meta={}){const target=this.get(targetId);if(!target||!target.alive)return{ok:false,reason:'Invalid target'}; const applied=Math.max(0,Number(amount)||0); target.hp=Math.max(0,target.hp-applied); if(target.hp<=0){target.alive=false; const e=this.entities.get(target.id); if(e){e.state.dead=true;e.enabled=false;e.visible=false;} this.events?.emit('combat:death',{target,sourceId,meta});} this.events?.emit('combat:damage',{target,sourceId,amount:applied,meta}); return{ok:true,amount:applied,hp:target.hp,dead:!target.alive};}
  heal(targetId,amount){const target=this.get(targetId);if(!target)return{ok:false}; const before=target.hp;target.hp=Math.min(target.maxHp,target.hp+Math.max(0,amount));if(target.hp>0)target.alive=true;return{ok:true,amount:target.hp-before,hp:target.hp};}
  attack(attackerId,targetId,engine,options={}){const a=this.get(attackerId),t=this.get(targetId);if(!a?.alive||!t?.alive)return{ok:false,reason:'Actor unavailable'}; const ap=this.position(attackerId,engine),tp=this.position(targetId,engine);if(!ap||!tp)return{ok:false,reason:'No actor position'}; const itemId=attackerId==='player'?this.equipment?.get('mainHand'):null, weapon=itemId?engine.inventory.def(itemId):null; const range=options.range??weapon?.range??1.7, dist=Math.hypot(ap.x-tp.x,ap.y-tp.y,(ap.z??0)-(tp.z??0));if(dist>range)return{ok:false,reason:'Out of range'}; const cooldown=weapon?.cooldown??options.cooldown??0.45, ready=this.cooldowns.get(attackerId)??0;if(engine.simulationTime<ready)return{ok:false,reason:'Recovering'}; this.cooldowns.set(attackerId,engine.simulationTime+cooldown); const bonus=attackerId==='player'?(this.equipment?.bonuses().attack??0):0; const raw=(options.damage??weapon?.damage??a.attack)+bonus, dealt=Math.max(0,raw-t.defense); const result=this.damage(targetId,dealt,attackerId,{weapon:itemId}); this.events?.emit('combat:attack',{attacker:a,target:t,result,weapon:itemId}); return result.ok?{...result,ok:true,targetId,damage:dealt}:{...result};}
  attackFromCamera(engine,options={}){let best=null,bestDot=.985; const cp=Math.cos(engine.camera.pitch),sp=Math.sin(engine.camera.pitch),fx=Math.cos(engine.camera.yaw)*cp,fy=Math.sin(engine.camera.yaw)*cp,fz=sp; for(const actor of this.actors.values()){if(actor.id==='player'||!actor.alive)continue;const e=this.entities.get(actor.id);if(!e?.enabled)continue;const vx=e.x-engine.camera.x,vy=e.y-engine.camera.y,vz=e.z+e.height*.5-engine.camera.z,dist=Math.hypot(vx,vy,vz);if(!dist)continue;const dot=(vx*fx+vy*fy+vz*fz)/dist;if(dot>bestDot){const hit=engine.raycaster.cast(engine.camera,vx,vy,vz,dist);if(!hit||hit.dist>=dist-e.radius){best={actor,e,dist};bestDot=dot;}}} if(!best)return{ok:false,reason:'No combat target'};return this.attack('player',best.actor.id,engine,options);}
  update(_dt,engine){const player=this.get('player');if(player&&!player.alive){engine.controller.enabled=false;}}
  serialize(){return{actors:[...this.actors.values()].sort((a,b)=>a.id.localeCompare(b.id)).map(a=>({...a,data:{...a.data}})),cooldowns:[...this.cooldowns.entries()].sort(([a],[b])=>a.localeCompare(b))};}
  restore(data={}){for(const snap of data.actors??[]){const a=this.actors.get(snap.id);if(a)Object.assign(a,snap,{data:{...(snap.data??{})}});else this.actors.set(snap.id,{...snap,data:{...(snap.data??{})}});}this.cooldowns=new Map(data.cooldowns??[]);}
}


// --- src/core/TriggerSystem.js ---
class TriggerSystem {
  constructor(events=null){this.events=events;this.triggers=new Map();}
  add(spec={}){if(!spec.id)throw new TypeError('trigger id required');if(this.triggers.has(spec.id))throw new Error(`Trigger already exists: ${spec.id}`);const t={id:spec.id,shape:spec.shape??'box',min:spec.min?{...spec.min}:null,max:spec.max?{...spec.max}:null,center:spec.center?{...spec.center}:null,radius:spec.radius??1,once:spec.once??false,enabled:spec.enabled??true,fired:spec.fired??false,inside:false,onEnter:spec.onEnter??null,onExit:spec.onExit??null,onStay:spec.onStay??null,data:{...(spec.data??{})}};this.triggers.set(t.id,t);return t;}
  contains(t,p){if(t.shape==='sphere'){const c=t.center??{x:0,y:0,z:0};return Math.hypot(p.x-c.x,p.y-c.y,p.z-c.z)<=t.radius;}const a=t.min??{x:0,y:0,z:0},b=t.max??a;return p.x>=a.x&&p.x<=b.x&&p.y>=a.y&&p.y<=b.y&&p.z>=a.z&&p.z<=b.z;}
  update(_dt,engine){for(const t of this.triggers.values()){if(!t.enabled||(t.once&&t.fired))continue;const now=this.contains(t,engine.camera);if(now&&!t.inside){t.inside=true;t.fired=true;t.onEnter?.({trigger:t,engine});this.events?.emit('trigger:enter',{trigger:t,engine});}else if(!now&&t.inside){t.inside=false;t.onExit?.({trigger:t,engine});this.events?.emit('trigger:exit',{trigger:t,engine});}else if(now)t.onStay?.({trigger:t,engine});}}
  serialize(){return[...this.triggers.values()].sort((a,b)=>a.id.localeCompare(b.id)).map(t=>({id:t.id,enabled:t.enabled,fired:t.fired,inside:t.inside,data:{...t.data}}));}
  restore(data=[]){for(const s of data){const t=this.triggers.get(s.id);if(t)Object.assign(t,{enabled:s.enabled,fired:s.fired,inside:s.inside,data:{...(s.data??{})}});}}
}


// --- src/core/DialogueSystem.js ---
class DialogueSystem {
  constructor(events=null){this.events=events;this.trees=new Map();this.active=null;}
  register(id,spec={}){if(this.trees.has(id))throw new Error(`Dialogue already registered: ${id}`);const tree={id,start:spec.start??'start',nodes:{...(spec.nodes??{})}};this.trees.set(id,tree);return tree;}
  start(id,context={}){const tree=this.trees.get(id);if(!tree)return{ok:false,reason:'Unknown dialogue'};this.active={id,nodeId:tree.start,speakerId:context.speakerId??null,context:{...(context.data??{})}};this.events?.emit('dialogue:start',{active:this.active});return{ok:true,current:this.current()};}
  current(){if(!this.active)return null;const tree=this.trees.get(this.active.id),node=tree?.nodes?.[this.active.nodeId];if(!node)return null;const choices=(node.choices??[]).filter(c=>!c.condition||c.condition(this.active.context)).map((c,i)=>({index:i,text:c.text??`Choice ${i+1}`}));return{id:this.active.id,nodeId:this.active.nodeId,speakerId:this.active.speakerId,text:typeof node.text==='function'?node.text(this.active.context):node.text??'',choices,end:node.end??false};}
  choose(index,engine=null){const cur=this.current();if(!cur)return{ok:false,reason:'No active dialogue'};const tree=this.trees.get(this.active.id),node=tree.nodes[this.active.nodeId],choices=(node.choices??[]).filter(c=>!c.condition||c.condition(this.active.context)),choice=choices[index];if(!choice)return{ok:false,reason:'Invalid choice'};choice.action?.({engine,dialogue:this,context:this.active.context});if(choice.next)this.active.nodeId=choice.next;else if(choice.end||node.end)this.close();this.events?.emit('dialogue:choice',{choice,index,active:this.active});return{ok:true,current:this.current()};}
  close(){const prior=this.active;this.active=null;this.events?.emit('dialogue:end',{prior});}
  serialize(){return this.active?{...this.active,context:{...this.active.context}}:null;}
  restore(data){this.active=data?{...data,context:{...(data.context??{})}}:null;}
}


// --- src/core/ProceduralWorldSystem.js ---

class ProceduralWorldSystem {
  constructor(world, materials, seed=1, events=null){this.world=world;this.materials=materials;this.seed=Number(seed)>>>0||1;this.events=events;this.generators=new Map();this.generated=new Set();}
  register(id,generator){if(typeof generator!=='function'&&typeof generator?.generateChunk!=='function')throw new TypeError('generator must be a function or object with generateChunk');this.generators.set(id,generator);return generator;}
  _hash(id,cx,cy,cz){let h=this.seed^2166136261;for(const ch of String(id))h=Math.imul(h^ch.charCodeAt(0),16777619);for(const n of[cx,cy,cz]){h=Math.imul(h^(n|0),2246822519);h^=h>>>13;}return h>>>0||1;}
  ensureChunk(id,cx,cy,cz,engine=null){const key=`${id}:${cx},${cy},${cz}`;if(this.generated.has(key))return false;const generator=this.generators.get(id);if(!generator)throw new Error(`Unknown generator: ${id}`);const rng=new DeterministicRng(this._hash(id,cx,cy,cz));const ctx={id,cx,cy,cz,chunkSize:this.world.chunkSize,world:this.world,materials:this.materials,rng,engine,seed:rng.seed};if(typeof generator==='function')generator(ctx);else generator.generateChunk(ctx);this.generated.add(key);this.events?.emit('world:chunkGenerated',{id,cx,cy,cz,key});return true;}
  ensureAround(id,position,radius=1,engine=null){const s=this.world.chunkSize,cx=Math.floor(position.x/s),cy=Math.floor(position.y/s),cz=Math.floor(position.z/s);let count=0;for(let z=cz-radius;z<=cz+radius;z++)for(let y=cy-radius;y<=cy+radius;y++)for(let x=cx-radius;x<=cx+radius;x++)if(this.ensureChunk(id,x,y,z,engine))count++;return count;}
  serialize(){return{seed:this.seed,generated:[...this.generated].sort()};}
  restore(data={}){this.seed=Number(data.seed??this.seed)>>>0||1;this.generated=new Set(data.generated??[]);}
}


// --- src/core/SaveSystem.js ---
class SaveSystem {
  constructor(engine, options={}){this.engine=engine;this.prefix=options.prefix??'runeray:';this.memory=new Map();}
  capture(){return this.engine.serializeCoreState();}
  restore(snapshot){return this.engine.restoreCoreState(snapshot);}
  toJson(space=0){return JSON.stringify(this.capture(),null,space);}
  fromJson(text){const data=JSON.parse(text);this.restore(data);return data;}
  saveSlot(name='quick'){const data=this.toJson();this.memory.set(name,data);try{globalThis.localStorage?.setItem?.(`${this.prefix}${name}`,data);}catch{}return data.length;}
  loadSlot(name='quick'){let data=this.memory.get(name)??null;try{data=globalThis.localStorage?.getItem?.(`${this.prefix}${name}`)??data;}catch{}if(!data)return{ok:false,reason:'No save in slot'};this.fromJson(data);return{ok:true};}
}


// --- src/core/AsciiRenderer.js ---
class AsciiRenderer {
  constructor(canvas, raycaster, options = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.raycaster = raycaster;
    this.sky = options.sky ?? null;
    this.fov = options.fov ?? 78;
    this.resolutionPreset = options.resolutionPreset ?? 'high';
    this.maxColsOverride = options.maxCols ?? null;
    this.maxRowsOverride = options.maxRows ?? null;
    this.targetFps = options.targetFps ?? 24;
    this.foreground = options.foreground ?? '#a9f6c8';
    this.background = options.background ?? '#020504';
    this.centerHit = null;
    this.centerSprite = null;
    this.lastFrame = [];
    this.cols = 60; this.rows = 40; this.width = 1; this.height = 1;
    this.fontSize = 10; this.charW = 6; this.lineH = 10.5; this.drawX = 0;
    this.resize();
  }

  _profile() {
    const profiles = {
      low: { mobileFont: 10.0, desktopFont: 12.5, maxCols: 104, maxRows: 76 },
      balanced: { mobileFont: 8.4, desktopFont: 10.5, maxCols: 142, maxRows: 104 },
      high: { mobileFont: 7.0, desktopFont: 8.8, maxCols: 184, maxRows: 132 },
    };
    return profiles[this.resolutionPreset] ?? profiles.high;
  }
  setResolutionPreset(name) { if (!['low','balanced','high'].includes(name)) return false; this.resolutionPreset = name; this.resize(); return true; }
  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.75); this.width = innerWidth; this.height = innerHeight;
    this.canvas.width = Math.round(this.width * dpr); this.canvas.height = Math.round(this.height * dpr); this.canvas.style.width = `${this.width}px`; this.canvas.style.height = `${this.height}px`;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0); const profile = this._profile(); this.fontSize = this.width < 500 ? profile.mobileFont : profile.desktopFont;
    this.ctx.font = `700 ${this.fontSize}px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`; this.charW = Math.max(3.1, this.ctx.measureText('@').width); this.lineH = this.fontSize * 1.02;
    const maxCols = this.maxColsOverride ?? profile.maxCols, maxRows = this.maxRowsOverride ?? profile.maxRows;
    this.cols = Math.max(40, Math.min(maxCols, Math.floor(this.width / this.charW))); this.rows = Math.max(30, Math.min(maxRows, Math.floor(this.height / this.lineH))); this.drawX = (this.width - this.cols * this.charW) / 2;
  }

  _skyGlyph(dx, dy, dz) {
    return this.sky?.sample?.(dx, dy, dz) ?? ' ';
  }

  _glyph(hit, camera) {
    const ramp = hit.material.ramp || ' .,:;irsXA253hMHGS#9B&@';
    let light = 1 - hit.dist / this.raycaster.maxDistance;
    if (hit.axis === 1) light *= 0.86;
    if (hit.axis === 2) light *= hit.hz > camera.z ? 0.72 : 0.60;
    light += hit.material.emissive || 0;
    const grain = (Math.sin(hit.hx * 4.7) + Math.sin(hit.hy * 5.3) + Math.sin(hit.hz * 6.1)) * 0.035;
    light = Math.max(0, Math.min(1, light + grain + (hit.material.distanceBias || 0)));
    return ramp[Math.floor(light * (ramp.length - 1))] || ' ';
  }

  _noise01(row, col, hit, layer) {
    let h = Math.imul(row + 17, 374761393) ^ Math.imul(col + 31, 668265263);
    h ^= Math.imul((hit.cellX ?? hit.x ?? 0) + 101, 2246822519) ^ Math.imul((hit.cellY ?? hit.y ?? 0) + 211, 3266489917);
    h ^= Math.imul((hit.cellZ ?? hit.z ?? 0) + 307, 668265263) ^ Math.imul(layer + 1, 374761393);
    h ^= h >>> 13; h = Math.imul(h, 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967295;
  }

  _glyphLayers(hits, row, col, camera, skyGlyph) {
    if (!hits.length) return skyGlyph;
    const last = hits[hits.length - 1];
    const lastIsOpaque = last.material.opacity >= 0.999;
    let glyph = lastIsOpaque ? this._glyph(last, camera) : skyGlyph;
    let start = lastIsOpaque ? hits.length - 2 : hits.length - 1;
    for (let i = start; i >= 0; i--) {
      const hit = hits[i], opacity = Math.max(0, Math.min(1, hit.material.opacity ?? 1));
      if (opacity <= 0) continue;
      if (opacity >= 0.999 || this._noise01(row, col, hit, i) < opacity) glyph = this._glyph(hit, camera);
    }
    return glyph;
  }

  _overlaySprites(frame, opaqueDepth, layersBuffer, camera, sprites, basis) {
    if (!sprites?.length) return;
    const { tanH, tanV, fx, fy, fz, rx, ry, rz, ux, uy, uz } = basis;
    const spriteDepth = new Float64Array(this.rows * this.cols); spriteDepth.fill(Infinity);
    const centerR = Math.floor(this.rows / 2), centerC = Math.floor(this.cols / 2);

    for (const sprite of sprites) {
      if (!sprite?.visible) continue;
      const vx = sprite.x - camera.x, vy = sprite.y - camera.y, vz = sprite.z - camera.z;
      const depth = vx * fx + vy * fy + vz * fz;
      if (depth <= 0.05 || depth > this.raycaster.maxDistance) continue;
      const side = vx * rx + vy * ry + vz * rz;
      const vertical = vx * ux + vy * uy + vz * uz;
      const nx = side / (depth * tanH), ny = vertical / (depth * tanV);
      const targetW = Math.max(1, sprite.width * this.cols / (2 * depth * tanH));
      const targetH = Math.max(1, sprite.height * this.rows / (2 * depth * tanV));
      const centerCFloat = (nx + 1) * this.cols * 0.5 - 0.5;
      const centerRFloat = (1 - ny) * this.rows * 0.5 - 0.5;
      const c0 = Math.max(0, Math.floor(centerCFloat - targetW * 0.5));
      const c1 = Math.min(this.cols - 1, Math.ceil(centerCFloat + targetW * 0.5));
      const r0 = Math.max(0, Math.floor(centerRFloat - targetH * 0.5));
      const r1 = Math.min(this.rows - 1, Math.ceil(centerRFloat + targetH * 0.5));
      if (c0 > c1 || r0 > r1) continue;
      const art = sprite.art.map(line => [...line]);
      const artH = art.length, artW = Math.max(1, ...art.map(line => line.length));

      for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
        const u = targetW <= 1 ? 0.5 : (c - (centerCFloat - targetW * 0.5)) / targetW;
        const v = targetH <= 1 ? 0.5 : (r - (centerRFloat - targetH * 0.5)) / targetH;
        const ac = Math.max(0, Math.min(artW - 1, Math.floor(u * artW)));
        const ar = Math.max(0, Math.min(artH - 1, Math.floor(v * artH)));
        const ch = art[ar]?.[ac] ?? ' ';
        if (ch === ' ') continue;
        const idx = r * this.cols + c;
        if (depth >= opaqueDepth[idx] || depth >= spriteDepth[idx]) continue;

        let glyph = ch;
        const layers = layersBuffer[idx] ?? [];
        for (let i = layers.length - 1; i >= 0; i--) {
          const hit = layers[i];
          if (hit.dist >= depth || hit.material.opacity >= 0.999) continue;
          const opacity = Math.max(0, Math.min(1, hit.material.opacity ?? 1));
          if (opacity > 0 && this._noise01(r, c, hit, i) < opacity) glyph = this._glyph(hit, camera);
        }
        frame[r][c] = glyph;
        spriteDepth[idx] = depth;
        if (r === centerR && c === centerC && (!this.centerSprite || depth < this.centerSprite.dist)) this.centerSprite = { sprite, dist: depth };
      }
    }
  }

  render(camera, sprites = []) {
    const tanH = Math.tan(this.fov * Math.PI / 360);
    const tanV = Math.min(1.35, tanH * (this.height / Math.max(1, this.width)));
    const cp = Math.cos(camera.pitch), sp = Math.sin(camera.pitch);
    const fx = Math.cos(camera.yaw) * cp, fy = Math.sin(camera.yaw) * cp, fz = sp;
    const rx = -Math.sin(camera.yaw), ry = Math.cos(camera.yaw), rz = 0;
    const ux = -Math.cos(camera.yaw) * sp, uy = -Math.sin(camera.yaw) * sp, uz = cp;
    const basis = { tanH, tanV, fx, fy, fz, rx, ry, rz, ux, uy, uz };
    const frame = Array.from({ length: this.rows }, () => Array(this.cols).fill(' '));
    const opaqueDepth = new Float64Array(this.rows * this.cols); opaqueDepth.fill(Infinity);
    const layersBuffer = new Array(this.rows * this.cols);
    const centerR = Math.floor(this.rows / 2), centerC = Math.floor(this.cols / 2);
    this.centerHit = null; this.centerSprite = null;

    for (let r = 0; r < this.rows; r++) {
      const ny = 1 - ((r + 0.5) / this.rows) * 2;
      for (let c = 0; c < this.cols; c++) {
        const nx = ((c + 0.5) / this.cols) * 2 - 1;
        const dx = fx + rx * nx * tanH + ux * ny * tanV;
        const dy = fy + ry * nx * tanH + uy * ny * tanV;
        const dz = fz + rz * nx * tanH + uz * ny * tanV;
        const hits = this.raycaster.castLayers(camera, dx, dy, dz);
        const idx = r * this.cols + c; layersBuffer[idx] = hits;
        const opaque = hits.find(hit => hit.material.opacity >= 0.999);
        if (opaque) opaqueDepth[idx] = opaque.dist;
        if (r === centerR && c === centerC) this.centerHit = hits[0] ?? null;
        frame[r][c] = this._glyphLayers(hits, r, c, camera, this._skyGlyph(dx, dy, dz));
      }
    }

    this._overlaySprites(frame, opaqueDepth, layersBuffer, camera, sprites, basis);
    this.lastFrame = frame.map(row => row.join(''));
    const ctx = this.ctx;
    ctx.fillStyle = this.background; ctx.fillRect(0, 0, this.width, this.height);
    ctx.font = `700 ${this.fontSize}px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`;
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.shadowBlur = 6; ctx.shadowColor = '#4dff9b35'; ctx.fillStyle = this.foreground;
    for (let r = 0; r < this.rows; r++) ctx.fillText(this.lastFrame[r], this.drawX, r * this.lineH);
    ctx.shadowBlur = 9; ctx.shadowColor = '#d8ffe980'; ctx.fillStyle = '#effff6';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('+', this.width / 2, this.height / 2);
    ctx.shadowBlur = 0;
  }
}


// --- src/core/FirstPersonController.js ---
class FirstPersonController {
  constructor(world, materials, camera) {
    this.world = world; this.materials = materials; this.camera = camera;
    this.moveSpeed = 4.2; this.turnSpeed = 1.65; this.lookSpeed = 1.05;
    this.radius = 0.22;
    this.enabled = true;
    this.keys = new Set();
    this.move = { forward: false, back: false, left: false, right: false, up: false, down: false };
    this.look = { left: false, right: false, up: false, down: false };
  }

  clearInput() {
    this.keys.clear();
    for (const k of Object.keys(this.move)) this.move[k] = false;
    for (const k of Object.keys(this.look)) this.look[k] = false;
  }

  solidAt(x, y, z) { return this.materials.get(this.world.get(Math.floor(x), Math.floor(y), Math.floor(z))).solid; }
  canOccupy(x, y, z) {
    const r = this.radius;
    for (const ox of [-r, r]) for (const oy of [-r, r]) for (const oz of [-r, r]) if (this.solidAt(x + ox, y + oy, z + oz)) return false;
    return true;
  }
  tryMove(dx, dy, dz) {
    const c = this.camera;
    if (this.canOccupy(c.x + dx, c.y, c.z)) c.x += dx;
    if (this.canOccupy(c.x, c.y + dy, c.z)) c.y += dy;
    if (this.canOccupy(c.x, c.y, c.z + dz)) c.z += dz;
  }

  serialize() {
    return {
      moveSpeed: this.moveSpeed, turnSpeed: this.turnSpeed, lookSpeed: this.lookSpeed, radius: this.radius, enabled: this.enabled,
      keys: [...this.keys].sort(), move: { ...this.move }, look: { ...this.look },
    };
  }

  restore(data = {}) {
    if (Number.isFinite(data.moveSpeed)) this.moveSpeed = data.moveSpeed;
    if (Number.isFinite(data.turnSpeed)) this.turnSpeed = data.turnSpeed;
    if (Number.isFinite(data.lookSpeed)) this.lookSpeed = data.lookSpeed;
    if (Number.isFinite(data.radius)) this.radius = Math.max(0, data.radius);
    this.enabled = data.enabled ?? this.enabled;
    this.keys = new Set(Array.isArray(data.keys) ? data.keys.map(String) : []);
    this.move = { ...this.move, ...(data.move ?? {}) };
    this.look = { ...this.look, ...(data.look ?? {}) };
    return this;
  }

  update(dt) {
    if (!this.enabled) return;
    let f = (this.move.forward || this.keys.has('w') ? 1 : 0) - (this.move.back || this.keys.has('s') ? 1 : 0);
    let s = (this.move.right || this.keys.has('d') ? 1 : 0) - (this.move.left || this.keys.has('a') ? 1 : 0);
    let u = (this.move.up || this.keys.has(' ') ? 1 : 0) - (this.move.down || this.keys.has('shift') ? 1 : 0);
    if (f || s || u) {
      const length = Math.hypot(f, s, u) || 1; f /= length; s /= length; u /= length;
      const fx = Math.cos(this.camera.yaw), fy = Math.sin(this.camera.yaw), rx = -fy, ry = fx;
      this.tryMove((fx * f + rx * s) * this.moveSpeed * dt, (fy * f + ry * s) * this.moveSpeed * dt, u * this.moveSpeed * dt);
    }
    const turn = (this.look.right || this.keys.has('arrowright') ? 1 : 0) - (this.look.left || this.keys.has('arrowleft') ? 1 : 0);
    const look = (this.look.up || this.keys.has('arrowup') ? 1 : 0) - (this.look.down || this.keys.has('arrowdown') ? 1 : 0);
    this.camera.yaw += turn * this.turnSpeed * dt;
    this.camera.pitch = Math.max(-1.35, Math.min(1.35, this.camera.pitch + look * this.lookSpeed * dt));
  }
}


// --- src/core/RuneRayEngine.js ---























class RuneRayEngine {
  constructor(canvas, options = {}) {
    this.seed = Number(options.seed ?? options.sky?.seed ?? 1) >>> 0 || 1;
    this.rng = new DeterministicRng(this.seed);
    this.events = new EventBus();
    this.materials = new MaterialRegistry();
    this.world = new ChunkedVoxelWorld(options.chunkSize ?? 16);
    this.camera = { x: 0.5, y: 0.5, z: 1.5, yaw: 0, pitch: 0 };
    this.sky = options.sky instanceof SkyEnvironment ? options.sky : new SkyEnvironment({ ...(options.sky ?? {}), seed: options.sky?.seed ?? this.seed });
    this.raycaster = new Raycaster(this.world, this.materials, options.maxDistance ?? 64);
    this.sprites = new SpriteSystem();
    this.entities = new EntitySystem(this.sprites);
    this.interactions = new InteractionSystem(this.entities, this.raycaster, options.interactions ?? {});
    this.microVoxels = new MicroVoxelSystem(this.world, this.materials, options.microPhysics ?? {});
    this.raycaster.addProvider(this.microVoxels);
    this.renderer = options.headless || !canvas ? null : new AsciiRenderer(canvas, this.raycaster, { ...(options.renderer ?? {}), sky: this.sky });
    this.controller = new FirstPersonController(this.world, this.materials, this.camera);
    this.inventory = new Inventory(options.inventorySlots ?? 12);
    this.menu = new MenuState();
    this.menu.onChange(state => { this.controller.enabled = !state.open && (this.combat?.get('player')?.alive ?? true); if (state.open) this.controller.clearInput(); });

    // Genre-neutral gameplay foundation.
    this.navigation = new NavigationSystem(this.world, this.materials, options.navigation ?? {});
    this.ai = new AISystem(this.entities, this.navigation, this.raycaster, this.events, options.ai ?? {});
    this.equipment = new EquipmentSystem(this.inventory, this.events, options.equipmentSlots ?? undefined);
    this.combat = new CombatSystem(this.entities, this.equipment, this.events);
    this.triggers = new TriggerSystem(this.events);
    this.dialogue = new DialogueSystem(this.events);
    this.procedural = new ProceduralWorldSystem(this.world, this.materials, this.seed, this.events);
    this.save = new SaveSystem(this, options.save ?? {});
    this.events.on('dialogue:start', () => { this.controller.enabled = false; this.controller.clearInput(); });
    this.events.on('dialogue:end', () => { this.controller.enabled = !this.menu.open && (this.combat.get('player')?.alive ?? true); });

    this.systems = [];
    this.stateAdapters = new Map();
    this.registerStateAdapter('ai', this.ai);
    this.registerStateAdapter('equipment', this.equipment);
    this.registerStateAdapter('combat', this.combat);
    this.registerStateAdapter('triggers', this.triggers);
    this.registerStateAdapter('dialogue', this.dialogue);
    this.registerStateAdapter('procedural', this.procedural);
    this.running = false;

    this.fixedStep = options.fixedStep ?? 1 / 60;
    if (!(this.fixedStep > 0) || !Number.isFinite(this.fixedStep)) throw new TypeError('fixedStep must be a positive finite number');
    this.simulationAccumulator = 0; this.simulationTime = 0; this.tick = 0;
    this.last = typeof performance !== 'undefined' ? performance.now() : 0;
    this.renderAccumulator = 0; this.renderInterval = 1 / (options.renderFps ?? 24);
  }

  addSystem(system) { this.systems.push(system); return system; }
  registerStateAdapter(key, adapter) { this.stateAdapters.set(key, adapter); return adapter; }
  random() { return this.rng.next(); }

  update(dt = this.fixedStep) {
    const nextTick = this.tick + 1; this.simulationTime = nextTick * this.fixedStep;
    this.controller.update(dt);
    this.microVoxels.update(dt, this);
    this.ai.update(dt, this);
    this.entities.update(dt, this);
    this.sprites.update(dt, this);
    this.interactions.findTarget(this.camera);
    this.combat.update(dt, this);
    this.triggers.update(dt, this);
    for (const s of this.systems) s.update?.(dt, this);
    this.tick = nextTick;
  }

  advance(elapsedSeconds) {
    if (!Number.isFinite(elapsedSeconds) || elapsedSeconds < 0) throw new TypeError('elapsedSeconds must be a finite non-negative number');
    this.simulationAccumulator += elapsedSeconds; let steps = 0; const eps = this.fixedStep * 1e-9;
    while (this.simulationAccumulator + eps >= this.fixedStep) { this.update(this.fixedStep); this.simulationAccumulator -= this.fixedStep; if (Math.abs(this.simulationAccumulator) < eps) this.simulationAccumulator = 0; steps++; }
    return steps;
  }

  queryAim(maxDistance = this.raycaster.maxDistance) {
    const cp = Math.cos(this.camera.pitch), sp = Math.sin(this.camera.pitch);
    return this.raycaster.cast(this.camera, Math.cos(this.camera.yaw) * cp, Math.sin(this.camera.yaw) * cp, sp, maxDistance);
  }

  interact(action = 'primary') { return this.interactions.interact(this.camera, action, this); }

  serializeCoreState() {
    const extensions = {};
    for (const [key, adapter] of [...this.stateAdapters.entries()].sort(([a],[b]) => a.localeCompare(b))) {
      if (adapter.serialize) extensions[key] = canonicalData(adapter.serialize());
    }
    return canonicalData({
      version: 4,
      seed: this.seed,
      rng: this.rng.serialize(),
      tick: this.tick,
      fixedStep: this.fixedStep,
      simulationTime: this.simulationTime,
      simulationAccumulator: this.simulationAccumulator,
      camera: { ...this.camera },
      controller: this.controller.serialize(),
      materials: this.materials.serialize(),
      world: this.world.serialize(),
      microVoxels: this.microVoxels.serialize(),
      sprites: this.sprites.serialize(),
      entities: this.entities.serialize(),
      inventory: this.inventory.serialize(),
      interactions: { reach: this.interactions.reach, aimCone: this.interactions.aimCone },
      raycaster: { maxDistance: this.raycaster.maxDistance, maxSteps: this.raycaster.maxSteps, maxVisualLayers: this.raycaster.maxVisualLayers },
      menu: { open: this.menu.open, tab: this.menu.tab },
      renderer: this.renderer ? { resolutionPreset: this.renderer.resolutionPreset } : null,
      extensions,
    });
  }

  restoreCoreState(snapshot = {}) {
    if (!snapshot || typeof snapshot !== 'object') throw new TypeError('snapshot must be an object');
    if ((snapshot.version ?? 0) > 4) throw new Error(`Unsupported RuneRay snapshot version ${snapshot.version}`);
    const state = canonicalData(snapshot);
    this.seed = Number(state.seed ?? this.seed) >>> 0 || 1;
    if (state.rng) { this.rng.seed = Number(state.rng.seed ?? this.seed) >>> 0 || 1; this.rng.state = Number(state.rng.state ?? this.rng.seed) >>> 0 || this.rng.seed; }
    this.fixedStep = state.fixedStep ?? this.fixedStep;
    this.tick = state.tick ?? 0;
    this.simulationTime = state.simulationTime ?? this.tick * this.fixedStep;
    this.simulationAccumulator = Number.isFinite(state.simulationAccumulator) ? Math.max(0, state.simulationAccumulator) : 0;

    if (state.materials) this.materials.restore(state.materials);
    if (state.world) this.world.restore(state.world);
    if (state.inventory) this.inventory.restore(state.inventory);
    if (state.microVoxels) this.microVoxels.restore(state.microVoxels);
    if (state.sprites) this.sprites.restore(state.sprites);
    if (state.entities) this.entities.restore(state.entities);
    if (state.camera) Object.assign(this.camera, state.camera);
    if (state.controller) this.controller.restore(state.controller);
    if (state.interactions) {
      if (Number.isFinite(state.interactions.reach)) this.interactions.reach = Math.max(0, state.interactions.reach);
      if (Number.isFinite(state.interactions.aimCone)) this.interactions.aimCone = Math.max(-1, Math.min(1, state.interactions.aimCone));
    }
    if (state.raycaster) {
      if (Number.isFinite(state.raycaster.maxDistance)) this.raycaster.maxDistance = Math.max(0, state.raycaster.maxDistance);
      if (Number.isInteger(state.raycaster.maxSteps) && state.raycaster.maxSteps > 0) this.raycaster.maxSteps = state.raycaster.maxSteps;
      if (Number.isInteger(state.raycaster.maxVisualLayers) && state.raycaster.maxVisualLayers > 0) this.raycaster.maxVisualLayers = state.raycaster.maxVisualLayers;
    }
    if (state.menu) { this.menu.tab = state.menu.tab ?? this.menu.tab; this.menu.setOpen(!!state.menu.open); }
    if (state.renderer?.resolutionPreset && this.renderer) this.renderer.setResolutionPreset(state.renderer.resolutionPreset);
    for (const [key, data] of Object.entries(state.extensions ?? {})) this.stateAdapters.get(key)?.restore?.(data);

    const snapshotEnabled = state.controller?.enabled ?? true;
    this.controller.enabled = !!snapshotEnabled && !this.menu.open && !this.dialogue.active && (this.combat.get('player')?.alive ?? true);
    if (!this.controller.enabled) this.controller.clearInput();
    this.interactions.findTarget(this.camera);
    this.events.emit('save:restored', { snapshot: state, engine: this });
    return true;
  }

  render() { if (!this.renderer) return; this.renderer.render(this.camera, this.sprites.list()); for (const s of this.systems) s.render?.(this); }

  start() {
    if (this.running) return;
    if (typeof requestAnimationFrame === 'undefined' || typeof performance === 'undefined') throw new Error('RuneRayEngine.start() requires browser animation timing APIs');
    this.running = true; this.last = performance.now();
    const frame = now => { if (!this.running) return; const dt = Math.max(0, (now - this.last) / 1000); this.last = now; this.advance(dt); this.renderAccumulator += dt; if (this.renderAccumulator >= this.renderInterval) { this.renderAccumulator %= this.renderInterval; this.render(); } requestAnimationFrame(frame); };
    requestAnimationFrame(frame);
  }
  stop() { this.running = false; }
}


// --- src/demo/ConstructionSandbox.js ---
function installConstructionSandbox(engine) {
  const hull = engine.materials.register('hull', { name: 'Hull', ramp: ' .,:;irsXA253hMHGS#9B&@' });
  const glass = engine.materials.register('glass', { name: 'Glass', ramp: '  .:|/\\+xX#', opacity: 0.24 });
  const deck = engine.materials.register('deck', { name: 'Deck', ramp: '   ..__--==++**##%%@' });
  const lamp = engine.materials.register('lamp', { name: 'Light', ramp: ' .:|IHM#@', emissive: 0.35 });
  const microHull = engine.materials.register('micro-hull', { name: 'Micro Hull', ramp: ' .,:+xXH#@', buildable: false });
  const microGlass = engine.materials.register('micro-glass', { name: 'Micro Glass', ramp: '  .:|+x#', opacity: 0.2, buildable: false });

  const inv = engine.inventory;
  const defs = [
    ['hull-block', 'Hull Block', '#', 48], ['glass-block', 'Glass Block', '◇', 24],
    ['deck-block', 'Deck Block', '=', 32], ['lamp-block', 'Light Block', '*', 12],
    ['micro-hull', 'Micro Hull Bit', 'h', 96], ['micro-glass', 'Micro Glass Bit', 'g', 48],
    ['repair-kit', 'Repair Kit', '+', 3], ['ore-sample', 'Ore Sample', 'o', 7],
  ];
  for (const [id, name, glyph] of defs) inv.define(id, { name, glyph, maxStack: 99 });
  for (const [id, , , count] of defs) inv.add(id, count);

  const materialItems = new Map([[hull, 'hull-block'], [glass, 'glass-block'], [deck, 'deck-block'], [lamp, 'lamp-block']]);
  const microItems = new Map([[microHull, 'micro-hull'], [microGlass, 'micro-glass']]);

  engine.world.fillBox(-7, -7, 0, 7, 7, 0, deck);
  engine.world.fillBox(5, -3, 1, 11, 3, 1, hull);
  for (let x = 5; x <= 11; x++) for (let z = 2; z <= 5; z++) {
    engine.world.set(x, -3, z, hull); engine.world.set(x, 3, z, hull);
  }
  for (let y = -3; y <= 3; y++) for (let z = 2; z <= 5; z++) {
    engine.world.set(11, y, z, hull);
    if (y === 0 && z < 4) continue;
    const isWindow = z === 3 && Math.abs(y) === 1;
    engine.world.set(5, y, z, isWindow ? glass : hull);
  }
  for (let x = 5; x <= 11; x++) for (let y = -3; y <= 3; y++) engine.world.set(x, y, 6, hull);
  engine.world.set(9, 0, 2, lamp);

  const microBody = engine.microVoxels.createBody({
    id: 'builder-object', voxelSize: 0.25, sizeX: 4, sizeY: 4, sizeZ: 4,
    x: 0.75, y: -0.5, z: 1.02, dynamic: true, gravityScale: 0, restitution: 0.25, tag: 'builder-demo',
  });
  for (let x = 0; x < 4; x++) for (let y = 0; y < 4; y++) microBody.set(x, y, 0, microHull);
  for (let z = 1; z < 4; z++) {
    microBody.set(0, 0, z, microHull); microBody.set(3, 0, z, microHull);
    microBody.set(0, 3, z, microHull); microBody.set(3, 3, z, microHull);
  }
  microBody.set(1, 0, 2, microGlass); microBody.set(2, 0, 2, microGlass);

  const guide = engine.entities.add({ id:'guide',type:'npc',name:'RuneRay Guide',x:1.8,y:1.45,z:1.02,radius:.45,height:1.55,tags:['actor','demo'], sprite:{width:1.05,height:1.45,art:[' /A\\ ','<OO>','[==]',' /\\ ']}, interactions:{primary:()=> 'Guide: Higher detail makes small actors and props much easier to read.'}, update:(_dt,e,runtime)=>{e.z=1.02+Math.sin(runtime.simulationTime*1.7)*.08;} });
  const pickup = engine.entities.add({ id:'sample-pickup',type:'pickup',name:'Rune Fragment',x:-1.15,y:1.35,z:1.05,radius:.22,height:.45,tags:['item','demo'], sprite:{width:.42,height:.55,art:[' /\\ ','<*>',' \\/ ']},state:{collected:false},interactions:{primary:({entity})=>{if(entity.state.collected)return 'The fragment is already collected.';entity.state.collected=true;entity.visible=false;entity.enabled=false;inv.add('ore-sample',1);return 'Picked up Rune Fragment (+1 sample).';}} });
  const chest = engine.entities.add({ id:'test-chest',type:'container',name:'Test Chest',x:-.2,y:-2,z:1.02,radius:.45,height:.72,tags:['container','demo'], sprite:{width:.95,height:.72,art:['+---+','|===|','+---+']},state:{opened:false},interactions:{primary:({entity})=>{if(entity.state.opened)return 'The chest is empty.';entity.state.opened=true;inv.add('repair-kit',1);inv.add('glass-block',2);return 'Opened Test Chest: +1 repair kit, +2 glass.';}} });
  const beacon = engine.entities.add({ id:'beacon',type:'switch',name:'Beacon Switch',x:8.2,y:-1.6,z:2.8,radius:.3,height:.8,tags:['switch','demo'],sprite:{width:.55,height:.8,art:[' * ','<+>',' | ']},state:{on:true},interactions:{primary:({entity})=>{entity.state.on=!entity.state.on;engine.world.set(9,0,2,entity.state.on?lamp:hull);return `Beacon ${entity.state.on?'ON':'OFF'}.`;}} });


  engine.camera.x = -4.5; engine.camera.y = 0.5; engine.camera.z = 2.2; engine.camera.yaw = 0;

  const buildables = [hull, glass, deck, lamp];
  const microBuildables = [microHull, microGlass];
  let selectedIndex = 0, microSelectedIndex = 0, microLayer = 2, lastError = '';
  const fail = msg => { lastError = msg; return false; };
  const ok = () => { lastError = ''; return true; };

  return {
    materials: { hull, glass, deck, lamp, microHull, microGlass },
    microBody,
    entities: { guide, pickup, chest, beacon },
    get selected() { return buildables[selectedIndex]; },
    get microSelected() { return microBuildables[microSelectedIndex]; },
    get microLayer() { return microLayer; },
    get lastError() { return lastError; },
    cycle() { selectedIndex = (selectedIndex + 1) % buildables.length; lastError = ''; },
    cycleMicro() { microSelectedIndex = (microSelectedIndex + 1) % microBuildables.length; lastError = ''; },
    setMicroLayer(value) { microLayer = Math.max(0, Math.min(microBody.sizeZ - 1, value | 0)); },
    remove() {
      const hit = engine.queryAim(7);
      if (!hit || hit.dist > 7) return fail('No world block in range');
      if (hit.source !== 'world') return fail('Use Micro Builder for small voxels');
      const id = engine.world.get(hit.x, hit.y, hit.z), itemId = materialItems.get(id);
      engine.world.set(hit.x, hit.y, hit.z, 0); if (itemId) inv.add(itemId, 1); return ok();
    },
    place() {
      const hit = engine.queryAim(7);
      if (!hit || hit.dist > 7) return fail('No world face in range');
      if (hit.source !== 'world') return fail('Aim at a large world block');
      const x = hit.x + hit.nx, y = hit.y + hit.ny, z = hit.z + hit.nz;
      if (engine.world.get(x, y, z) !== 0) return fail('That cell is occupied');
      const c = engine.camera;
      if (Math.abs(c.x - (x + .5)) < .75 && Math.abs(c.y - (y + .5)) < .75 && Math.abs(c.z - (z + .5)) < .9) return fail('Cannot build inside yourself');
      const materialId = buildables[selectedIndex], itemId = materialItems.get(materialId);
      if (!inv.has(itemId, 1)) return fail(`Out of ${inv.def(itemId).name}`);
      inv.remove(itemId, 1); engine.world.set(x, y, z, materialId); return ok();
    },
    toggleMicro(x, y) {
      const existing = microBody.get(x, y, microLayer);
      if (existing) {
        const itemId = microItems.get(existing); if (itemId) inv.add(itemId, 1);
        microBody.set(x, y, microLayer, 0); return ok();
      }
      const materialId = microBuildables[microSelectedIndex], itemId = microItems.get(materialId);
      if (!inv.has(itemId, 1)) return fail(`Out of ${inv.def(itemId).name}`);
      inv.remove(itemId, 1); microBody.set(x, y, microLayer, materialId); return ok();
    },
    dropMicro() {
      microBody.x = 0.75; microBody.y = -0.5; microBody.z = 5.2;
      microBody.vx = 0.35; microBody.vy = 0.08; microBody.vz = 0;
      microBody.gravityScale = 1; return ok();
    },
    recallMicro() {
      microBody.x = 0.75; microBody.y = -0.5; microBody.z = 1.02;
      microBody.vx = microBody.vy = microBody.vz = 0; microBody.gravityScale = 0; return ok();
    },
    materialName() { return engine.materials.get(buildables[selectedIndex]).name; },
    microMaterialName() { return engine.materials.get(microBuildables[microSelectedIndex]).name; },
    itemForSelected() { return materialItems.get(buildables[selectedIndex]); },
    microItemForSelected() { return microItems.get(microBuildables[microSelectedIndex]); },
  };
}


// --- src/demo/GameplayFoundationDemo.js ---
function installGameplayFoundationDemo(engine, sandbox) {
  const inv = engine.inventory;
  inv.define('training-blade', { name:'Training Blade', glyph:'/', maxStack:1, equipSlot:'mainHand', damage:3, range:2.0, cooldown:0.38, stats:{ attack:1 } });
  inv.define('traveler-coat', { name:'Traveler Coat', glyph:'T', maxStack:1, equipSlot:'body', stats:{ defense:1 } });
  inv.define('healing-tonic', { name:'Healing Tonic', glyph:'!', maxStack:9 });
  if (!inv.has('training-blade')) inv.add('training-blade',1);
  if (!inv.has('traveler-coat')) inv.add('traveler-coat',1);
  if (!inv.has('healing-tonic')) inv.add('healing-tonic',2);

  engine.combat.defineActor('player', { maxHp:18, attack:2, defense:0, faction:'player' });

  const walker = engine.entities.add({ id:'pathfinder', type:'npc', name:'Pathfinder', x:-2.5, y:-2.5, z:1.02, radius:.35, height:1.45,
    tags:['actor','ai','demo'], sprite:{width:.85,height:1.35,art:[' /P\\ ',' [|] ',' / \\ ']}, state:{role:'patrol'} });
  engine.ai.add(walker, { mode:'patrol', speed:1.0, patrol:[{x:-2.5,y:-2.5,z:1.02},{x:2.5,y:-2.5,z:1.02},{x:2.5,y:2.5,z:1.02},{x:-2.5,y:2.5,z:1.02}] });

  const crawler = engine.entities.add({ id:'crawler', type:'creature', name:'Training Crawler', x:3.3, y:2.2, z:1.02, radius:.42, height:.75,
    tags:['actor','hostile','demo'], sprite:{width:1.0,height:.7,art:[' .oo. ','<####>',' /  \\ ']}, state:{dead:false} });
  engine.ai.add(crawler, { mode:'wander', speed:.7, wanderRadius:2.4, home:{x:3,y:2,z:1.02} });
  engine.combat.defineActor(crawler, { maxHp:8, attack:1, defense:0, faction:'hostile' });

  engine.dialogue.register('guide-intro', { start:'start', nodes:{
    start:{ text:'The Guide taps the floor with one boot. "RuneRay can now support inhabitants, combat, dialogue, triggers, procedural regions, and persistent state."', choices:[
      { text:'What changed for NPCs?', next:'ai' }, { text:'Tell me about saves.', next:'save' }, { text:'Good. Let me explore.', end:true }
    ]},
    ai:{ text:'"Navigation reads the voxel world directly. AI decides why an actor moves; the pathfinder only decides how to get there."', choices:[{text:'Back.',next:'start'}]},
    save:{ text:'"The engine snapshots deterministic simulation state plus registered gameplay systems. Game code supplies behavior; saves preserve mutable state."', choices:[{text:'Back.',next:'start'}]}
  }});
  sandbox.entities.guide.interactions.primary = ({entity}) => { engine.dialogue.start('guide-intro',{speakerId:entity.id}); return {message:'Conversation started'}; };

  engine.triggers.add({ id:'station-threshold', min:{x:4.7,y:-1.2,z:1}, max:{x:6.2,y:1.2,z:4.5}, once:true,
    onEnter:({trigger})=>{ trigger.data.message='Entered station threshold'; engine.events.emit('demo:message',{message:'TRIGGER: entered the station threshold'}); } });

  // Generator interface proof: a deterministic little marker ruin in a distant chunk.
  engine.procedural.register('marker-ruins', ({cx,cy,cz,chunkSize,world,materials,rng}) => {
    if (cz !== 0 || Math.abs(cx) > 2 || Math.abs(cy) > 2) return;
    const deck = materials.id('deck'), hull = materials.id('hull'); if (!deck || !hull) return;
    const ox=cx*chunkSize, oy=cy*chunkSize;
    if (rng.next() < .42) return;
    const px=ox+3+Math.floor(rng.next()*8), py=oy+3+Math.floor(rng.next()*8);
    for(let x=px-2;x<=px+2;x++)for(let y=py-2;y<=py+2;y++)world.set(x,y,0,deck);
    const h=2+Math.floor(rng.next()*3); for(let z=1;z<=h;z++)world.set(px,py,z,hull);
  });
  engine.procedural.ensureChunk('marker-ruins', -1, 1, 0, engine);

  engine.events.on('combat:death', ({target}) => { if(target.id==='crawler') engine.events.emit('demo:message',{message:'COMBAT: crawler disabled'}); });

  return {
    walker, crawler,
    equipBlade(){ return engine.equipment.get('mainHand')==='training-blade' ? engine.equipment.unequip('mainHand') : engine.equipment.equip('training-blade','mainHand'); },
    equipCoat(){ return engine.equipment.get('body')==='traveler-coat' ? engine.equipment.unequip('body') : engine.equipment.equip('traveler-coat','body'); },
    useTonic(){ if(!inv.has('healing-tonic'))return{ok:false,reason:'No tonic'}; const player=engine.combat.get('player'); if(player.hp>=player.maxHp)return{ok:false,reason:'Already at full health'}; inv.remove('healing-tonic',1); return engine.combat.heal('player',5); },
    attack(){ return engine.combat.attackFromCamera(engine); },
  };
}


// --- src/demo/main.js ---



const $=s=>document.querySelector(s), canvas=$('#game');
const engine=new RuneRayEngine(canvas,{chunkSize:16,maxDistance:78,renderFps:24,inventorySlots:16,seed:7421,sky:{seed:7421,starDensity:.11,bandStrength:.5},microPhysics:{gravity:{x:0,y:0,z:-4.8}},interactions:{reach:3.4,aimCone:.962},renderer:{fov:78,resolutionPreset:'high'}});
const sandbox=installConstructionSandbox(engine), gameplay=installGameplayFoundationDemo(engine,sandbox);
const status=$('#status'),materialBtn=$('#material'),interactBtn=$('#interact'),toast=$('#toast'),menuOverlay=$('#menuOverlay'),inventoryGrid=$('#inventoryGrid'),microGrid=$('#microGrid'),microLayerLabel=$('#microLayerLabel'),microMaterialBtn=$('#microMaterial'),microCounts=$('#microCounts'),engineStats=$('#engineStats'),characterPanel=$('#characterPanel'),worldPanel=$('#worldPanel'),saveInfo=$('#saveInfo'),dialogueOverlay=$('#dialogueOverlay'),dialogueText=$('#dialogueText'),dialogueChoices=$('#dialogueChoices');
let toastTimer=0,frames=0,fps=0,fpsTime=performance.now();
function say(msg){toast.textContent=msg;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),1200)}
engine.events.on('demo:message',({message})=>say(message));
function countMicro(){let n=0;for(const v of sandbox.microBody.data)if(v)n++;return n}
function updateStatus(){const c=engine.camera,target=engine.interactions.target?.entity??null,player=engine.combat.get('player'),crawler=engine.combat.get('crawler');materialBtn.innerHTML=`MAT<br>${sandbox.materialName().toUpperCase()}`;interactBtn.innerHTML=target?`E<br>${target.name.toUpperCase().slice(0,11)}`:'E<br>USE';status.innerHTML=`POS ${c.x.toFixed(1)},${c.y.toFixed(1)},${c.z.toFixed(1)} · ${fps} FPS · ${engine.renderer.cols}×${engine.renderer.rows} ${engine.renderer.resolutionPreset.toUpperCase()}<br>HP ${player?.hp??'-'}/${player?.maxHp??'-'} · CRAWLER ${crawler?.alive?`${crawler.hp}/${crawler.maxHp}`:'DOWN'} · AI ${engine.ai.agents.size} · TICK ${engine.tick}<br>${target?`TARGET ${target.name} · `:''}BUILD ${sandbox.materialName()} ×${engine.inventory.count(sandbox.itemForSelected())}`}
function renderInventory(){inventoryGrid.innerHTML='';engine.inventory.slots.forEach((slot,i)=>{const el=document.createElement('div');el.className='slot';if(!slot)el.innerHTML='<span class="slotGlyph">·</span><span>Empty</span><b>—</b>';else{const d=engine.inventory.def(slot.id);el.innerHTML=`<span class="slotGlyph">${d.glyph}</span><span>${d.name}</span><b>${slot.count}</b>`}el.setAttribute('aria-label',slot?`${engine.inventory.def(slot.id).name}, ${slot.count}`:`Empty slot ${i+1}`);inventoryGrid.appendChild(el)})}
function renderCharacter(){const p=engine.combat.get('player'),bonus=engine.equipment.bonuses();characterPanel.innerHTML=`<div><b>HEALTH</b><span>${p.hp} / ${p.maxHp}</span></div><div><b>MAIN HAND</b><span>${engine.equipment.get('mainHand')?engine.inventory.def(engine.equipment.get('mainHand')).name:'Empty'}</span></div><div><b>BODY</b><span>${engine.equipment.get('body')?engine.inventory.def(engine.equipment.get('body')).name:'Empty'}</span></div><div><b>BONUSES</b><span>Attack +${bonus.attack??0} · Defense +${bonus.defense??0}</span></div>`}
function renderMicro(){const b=sandbox.microBody,l=sandbox.microLayer;microLayerLabel.textContent=`LAYER ${l+1}/${b.sizeZ}`;microMaterialBtn.textContent=`MATERIAL: ${sandbox.microMaterialName().toUpperCase()}`;microCounts.textContent=`${countMicro()} fine voxels · ${(b.sizeX*b.voxelSize).toFixed(2)}³-ish object scale`;microGrid.innerHTML='';for(let y=b.sizeY-1;y>=0;y--)for(let x=0;x<b.sizeX;x++){const id=b.get(x,y,l),bt=document.createElement('button');bt.type='button';bt.className=`microCell ${id?'filled':''}`;bt.textContent=id===sandbox.materials.microHull?'H':id===sandbox.materials.microGlass?'G':'·';bt.addEventListener('click',()=>{if(!sandbox.toggleMicro(x,y))say(sandbox.lastError);renderMicro();renderInventory()});microGrid.appendChild(bt)}}
function renderWorld(){const path=engine.ai.get('pathfinder'),crawler=engine.ai.get('crawler'),trig=engine.triggers.triggers.get('station-threshold');worldPanel.innerHTML=`<div><b>NAVIGATION / AI</b><span>Pathfinder: ${path?.state??'—'} · route nodes ${Math.max(0,(path?.path?.length??0)-(path?.pathIndex??0))}<br>Crawler: ${crawler?.state??'—'} · deterministic wander</span></div><div><b>TRIGGER</b><span>Station threshold fired: ${trig?.fired?'yes':'no'}</span></div><div><b>PROCEDURAL WORLD</b><span>${engine.procedural.generated.size} deterministic chunk records · generator registry ${engine.procedural.generators.size}</span></div>`}
function renderEngine(){document.querySelectorAll('[data-resolution]').forEach(b=>b.classList.toggle('active',b.dataset.resolution===engine.renderer.resolutionPreset));engineStats.innerHTML=`<div><b>FRAMEBUFFER</b><span>${engine.renderer.cols}×${engine.renderer.rows} glyph pixels</span></div><div><b>FIXED SIM</b><span>${(1/engine.fixedStep).toFixed(0)} Hz · seed ${engine.seed} · snapshot v${engine.serializeCoreState().version}</span></div><div><b>GAMEPLAY SYSTEMS</b><span>navigation · AI · equipment · combat · triggers · dialogue · procedural world · save/restore</span></div><div><b>CORE CONTENT</b><span>${engine.entities.list().length} entities · ${engine.world.nonAirCount} voxels · ${engine.sprites.list().length} sprites · ${countMicro()} fine voxels</span></div>`}
function renderDialogue(){const cur=engine.dialogue.current();dialogueOverlay.classList.toggle('open',!!cur);dialogueOverlay.setAttribute('aria-hidden',cur?'false':'true');if(!cur)return;dialogueText.textContent=cur.text;dialogueChoices.innerHTML='';for(const ch of cur.choices){const b=document.createElement('button');b.type='button';b.textContent=ch.text;b.addEventListener('click',()=>{engine.dialogue.choose(ch.index,engine);renderDialogue()});dialogueChoices.appendChild(b)}if(!cur.choices.length){const b=document.createElement('button');b.type='button';b.textContent='CLOSE';b.addEventListener('click',()=>{engine.dialogue.close();renderDialogue()});dialogueChoices.appendChild(b)}}
engine.events.on('dialogue:start',renderDialogue);engine.events.on('dialogue:choice',renderDialogue);engine.events.on('dialogue:end',renderDialogue);
function renderMenu(){menuOverlay.classList.toggle('open',engine.menu.open);menuOverlay.setAttribute('aria-hidden',engine.menu.open?'false':'true');document.querySelectorAll('.tabBtn').forEach(b=>b.classList.toggle('active',b.dataset.tab===engine.menu.tab));document.querySelectorAll('.tabPage').forEach(p=>p.classList.toggle('active',p.id===`tab-${engine.menu.tab}`));if(!engine.menu.open)return;renderInventory();renderCharacter();renderMicro();renderWorld();renderEngine()}
engine.menu.onChange(renderMenu);
function perform(fn,success){if(engine.menu.open||engine.dialogue.active)return;const r=fn();if(r===false||r?.ok===false)say(r?.reason||sandbox.lastError||'Blocked');else say(r?.message||success);renderInventory();renderCharacter();updateStatus()}
$('#interact').addEventListener('click',()=>perform(()=>engine.interact(),'Used'));$('#attack').addEventListener('click',()=>perform(()=>gameplay.attack(),'Attack'));$('#place').addEventListener('click',()=>perform(()=>sandbox.place(),`Placed ${sandbox.materialName()}`));$('#remove').addEventListener('click',()=>perform(()=>sandbox.remove(),'Block recovered'));materialBtn.addEventListener('click',()=>{sandbox.cycle();updateStatus();say(sandbox.materialName())});$('#menu').addEventListener('click',()=>engine.menu.toggle());$('#closeMenu').addEventListener('click',()=>engine.menu.setOpen(false));menuOverlay.addEventListener('pointerdown',e=>{if(e.target===menuOverlay)engine.menu.setOpen(false)});document.querySelectorAll('.tabBtn').forEach(b=>b.addEventListener('click',()=>engine.menu.setTab(b.dataset.tab)));document.querySelectorAll('[data-resolution]').forEach(b=>b.addEventListener('click',()=>{engine.renderer.setResolutionPreset(b.dataset.resolution);renderEngine();updateStatus()}));
$('#equipBlade').addEventListener('click',()=>{const r=gameplay.equipBlade();say(r.reason||'Blade equipment changed');renderInventory();renderCharacter()});$('#equipCoat').addEventListener('click',()=>{const r=gameplay.equipCoat();say(r.reason||'Coat equipment changed');renderInventory();renderCharacter()});$('#useTonic').addEventListener('click',()=>{const r=gameplay.useTonic();say(r.reason||`Healed ${r.amount??0}`);renderInventory();renderCharacter();updateStatus()});
$('#layerDown').addEventListener('click',()=>{sandbox.setMicroLayer(sandbox.microLayer-1);renderMicro()});$('#layerUp').addEventListener('click',()=>{sandbox.setMicroLayer(sandbox.microLayer+1);renderMicro()});microMaterialBtn.addEventListener('click',()=>{sandbox.cycleMicro();renderMicro()});$('#dropMicro').addEventListener('click',()=>{sandbox.dropMicro();engine.menu.setOpen(false);say('Object dropped')});$('#recallMicro').addEventListener('click',()=>{sandbox.recallMicro();renderMicro();say('Object recalled')});
$('#quickSave').addEventListener('click',()=>{const bytes=engine.save.saveSlot('quick');saveInfo.textContent=`Quick save: ${bytes} JSON bytes · tick ${engine.tick}`;say('Quick saved')});$('#quickLoad').addEventListener('click',()=>{const r=engine.save.loadSlot('quick');say(r.ok?'Quick loaded':r.reason);renderMenu();renderDialogue();updateStatus()});$('#closeDialogue').addEventListener('click',()=>{engine.dialogue.close();renderDialogue()});
function bindHold(sel,obj,key){const el=$(sel),down=e=>{e.preventDefault();if(engine.menu.open||engine.dialogue.active)return;obj[key]=true;el.classList.add('held');el.setPointerCapture?.(e.pointerId)},up=e=>{obj[key]=false;el.classList.remove('held');try{el.releasePointerCapture?.(e.pointerId)}catch{}};el.addEventListener('pointerdown',down);for(const ev of['pointerup','pointercancel','lostpointercapture'])el.addEventListener(ev,up)}for(const[id,key]of[['#mf','forward'],['#mb','back'],['#ml','left'],['#mr','right']])bindHold(id,engine.controller.move,key);for(const[id,key]of[['#lu','up'],['#ld','down'],['#ll','left'],['#lr','right']])bindHold(id,engine.controller.look,key);bindHold('#up',engine.controller.move,'up');bindHold('#down',engine.controller.move,'down');
const lookDrag=$('#lookDrag');let dragId=null,lastX=0,lastY=0;lookDrag.addEventListener('pointerdown',e=>{if(engine.menu.open||engine.dialogue.active)return;dragId=e.pointerId;lastX=e.clientX;lastY=e.clientY;lookDrag.setPointerCapture?.(e.pointerId)});lookDrag.addEventListener('pointermove',e=>{if(e.pointerId!==dragId||engine.menu.open||engine.dialogue.active)return;const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;engine.camera.yaw+=dx*.0065;engine.camera.pitch=Math.max(-1.35,Math.min(1.35,engine.camera.pitch-dy*.0058))});for(const ev of['pointerup','pointercancel'])lookDrag.addEventListener(ev,e=>{if(e.pointerId===dragId)dragId=null});
window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k==='escape'||k==='i'){e.preventDefault();if(engine.dialogue.active){engine.dialogue.close();renderDialogue()}else engine.menu.toggle();return}if(engine.menu.open||engine.dialogue.active)return;if(k==='e'){e.preventDefault();perform(()=>engine.interact(),'Used');return}if(k==='f'){e.preventDefault();perform(()=>gameplay.attack(),'Attack');return}if(['w','a','s','d',' ','shift','arrowleft','arrowright','arrowup','arrowdown'].includes(k)){e.preventDefault();engine.controller.keys.add(k)}});window.addEventListener('keyup',e=>engine.controller.keys.delete(e.key.toLowerCase()));window.addEventListener('blur',()=>engine.controller.clearInput());window.addEventListener('resize',()=>engine.renderer.resize());
engine.addSystem({update:()=>{frames++;const now=performance.now();if(now-fpsTime>700){fps=Math.round(frames*1000/(now-fpsTime));frames=0;fpsTime=now;updateStatus();if(engine.menu.open){renderWorld();renderCharacter()}}}});
renderMenu();renderDialogue();updateStatus();engine.start();

