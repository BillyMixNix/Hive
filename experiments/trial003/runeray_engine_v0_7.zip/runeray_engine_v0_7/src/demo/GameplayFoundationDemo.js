export function installGameplayFoundationDemo(engine, sandbox) {
  const inv = engine.inventory;
  inv.define('training-blade', { name:'Training Blade', glyph:'/', maxStack:1, equipSlot:'mainHand', damage:3, range:2.0, cooldown:0.38, stats:{ attack:1 } });
  inv.define('traveler-coat', { name:'Traveler Coat', glyph:'T', maxStack:1, equipSlot:'body', stats:{ defense:1 } });
  inv.define('healing-tonic', { name:'Healing Tonic', glyph:'!', maxStack:9 });
  if (!inv.has('training-blade')) inv.add('training-blade',1);
  if (!inv.has('traveler-coat')) inv.add('traveler-coat',1);
  if (!inv.has('healing-tonic')) inv.add('healing-tonic',2);

  engine.combat.defineActor('player', { maxHp:18, attack:2, defense:0, faction:'player' });

  const walker = engine.entities.add({ id:'pathfinder', type:'npc', name:'Pathfinder', x:-2.5, y:-2.5, z:1.02, radius:.35, height:1.45,
    tags:['actor','ai','demo'], sprite:{width:.85,height:1.35,art:[' /P\\ ',' [|] ',' / \\ ']}, state:{role:'patrol'} });
  engine.ai.add(walker, { mode:'patrol', speed:1.0, patrol:[{x:-2.5,y:-2.5,z:1.02},{x:2.5,y:-2.5,z:1.02},{x:2.5,y:2.5,z:1.02},{x:-2.5,y:2.5,z:1.02}] });

  const crawler = engine.entities.add({ id:'crawler', type:'creature', name:'Training Crawler', x:3.3, y:2.2, z:1.02, radius:.42, height:.75,
    tags:['actor','hostile','demo'], sprite:{width:1.0,height:.7,art:[' .oo. ','<####>',' /  \\ ']}, state:{dead:false} });
  engine.ai.add(crawler, { mode:'wander', speed:.7, wanderRadius:2.4, home:{x:3,y:2,z:1.02} });
  engine.combat.defineActor(crawler, { maxHp:8, attack:1, defense:0, faction:'hostile' });

  engine.dialogue.register('guide-intro', { start:'start', nodes:{
    start:{ text:'The Guide taps the floor with one boot. "RuneRay can now support inhabitants, combat, dialogue, triggers, procedural regions, and persistent state."', choices:[
      { text:'What changed for NPCs?', next:'ai' }, { text:'Tell me about saves.', next:'save' }, { text:'Good. Let me explore.', end:true }
    ]},
    ai:{ text:'"Navigation reads the voxel world directly. AI decides why an actor moves; the pathfinder only decides how to get there."', choices:[{text:'Back.',next:'start'}]},
    save:{ text:'"The engine snapshots deterministic simulation state plus registered gameplay systems. Game code supplies behavior; saves preserve mutable state."', choices:[{text:'Back.',next:'start'}]}
  }});
  sandbox.entities.guide.interactions.primary = ({entity}) => { engine.dialogue.start('guide-intro',{speakerId:entity.id}); return {message:'Conversation started'}; };

  engine.triggers.add({ id:'station-threshold', min:{x:4.7,y:-1.2,z:1}, max:{x:6.2,y:1.2,z:4.5}, once:true,
    onEnter:({trigger})=>{ trigger.data.message='Entered station threshold'; engine.events.emit('demo:message',{message:'TRIGGER: entered the station threshold'}); } });

  // Generator interface proof: a deterministic little marker ruin in a distant chunk.
  engine.procedural.register('marker-ruins', ({cx,cy,cz,chunkSize,world,materials,rng}) => {
    if (cz !== 0 || Math.abs(cx) > 2 || Math.abs(cy) > 2) return;
    const deck = materials.id('deck'), hull = materials.id('hull'); if (!deck || !hull) return;
    const ox=cx*chunkSize, oy=cy*chunkSize;
    if (rng.next() < .42) return;
    const px=ox+3+Math.floor(rng.next()*8), py=oy+3+Math.floor(rng.next()*8);
    for(let x=px-2;x<=px+2;x++)for(let y=py-2;y<=py+2;y++)world.set(x,y,0,deck);
    const h=2+Math.floor(rng.next()*3); for(let z=1;z<=h;z++)world.set(px,py,z,hull);
  });
  engine.procedural.ensureChunk('marker-ruins', -1, 1, 0, engine);

  engine.events.on('combat:death', ({target}) => { if(target.id==='crawler') engine.events.emit('demo:message',{message:'COMBAT: crawler disabled'}); });

  return {
    walker, crawler,
    equipBlade(){ return engine.equipment.get('mainHand')==='training-blade' ? engine.equipment.unequip('mainHand') : engine.equipment.equip('training-blade','mainHand'); },
    equipCoat(){ return engine.equipment.get('body')==='traveler-coat' ? engine.equipment.unequip('body') : engine.equipment.equip('traveler-coat','body'); },
    useTonic(){ if(!inv.has('healing-tonic'))return{ok:false,reason:'No tonic'}; const player=engine.combat.get('player'); if(player.hp>=player.maxHp)return{ok:false,reason:'Already at full health'}; inv.remove('healing-tonic',1); return engine.combat.heal('player',5); },
    attack(){ return engine.combat.attackFromCamera(engine); },
  };
}
