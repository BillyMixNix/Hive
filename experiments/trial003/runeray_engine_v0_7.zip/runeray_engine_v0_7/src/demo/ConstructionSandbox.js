export function installConstructionSandbox(engine) {
  const hull = engine.materials.register('hull', { name: 'Hull', ramp: ' .,:;irsXA253hMHGS#9B&@' });
  const glass = engine.materials.register('glass', { name: 'Glass', ramp: '  .:|/\\+xX#', opacity: 0.24 });
  const deck = engine.materials.register('deck', { name: 'Deck', ramp: '   ..__--==++**##%%@' });
  const lamp = engine.materials.register('lamp', { name: 'Light', ramp: ' .:|IHM#@', emissive: 0.35 });
  const microHull = engine.materials.register('micro-hull', { name: 'Micro Hull', ramp: ' .,:+xXH#@', buildable: false });
  const microGlass = engine.materials.register('micro-glass', { name: 'Micro Glass', ramp: '  .:|+x#', opacity: 0.2, buildable: false });

  const inv = engine.inventory;
  const defs = [
    ['hull-block', 'Hull Block', '#', 48], ['glass-block', 'Glass Block', '◇', 24],
    ['deck-block', 'Deck Block', '=', 32], ['lamp-block', 'Light Block', '*', 12],
    ['micro-hull', 'Micro Hull Bit', 'h', 96], ['micro-glass', 'Micro Glass Bit', 'g', 48],
    ['repair-kit', 'Repair Kit', '+', 3], ['ore-sample', 'Ore Sample', 'o', 7],
  ];
  for (const [id, name, glyph] of defs) inv.define(id, { name, glyph, maxStack: 99 });
  for (const [id, , , count] of defs) inv.add(id, count);

  const materialItems = new Map([[hull, 'hull-block'], [glass, 'glass-block'], [deck, 'deck-block'], [lamp, 'lamp-block']]);
  const microItems = new Map([[microHull, 'micro-hull'], [microGlass, 'micro-glass']]);

  engine.world.fillBox(-7, -7, 0, 7, 7, 0, deck);
  engine.world.fillBox(5, -3, 1, 11, 3, 1, hull);
  for (let x = 5; x <= 11; x++) for (let z = 2; z <= 5; z++) {
    engine.world.set(x, -3, z, hull); engine.world.set(x, 3, z, hull);
  }
  for (let y = -3; y <= 3; y++) for (let z = 2; z <= 5; z++) {
    engine.world.set(11, y, z, hull);
    if (y === 0 && z < 4) continue;
    const isWindow = z === 3 && Math.abs(y) === 1;
    engine.world.set(5, y, z, isWindow ? glass : hull);
  }
  for (let x = 5; x <= 11; x++) for (let y = -3; y <= 3; y++) engine.world.set(x, y, 6, hull);
  engine.world.set(9, 0, 2, lamp);

  const microBody = engine.microVoxels.createBody({
    id: 'builder-object', voxelSize: 0.25, sizeX: 4, sizeY: 4, sizeZ: 4,
    x: 0.75, y: -0.5, z: 1.02, dynamic: true, gravityScale: 0, restitution: 0.25, tag: 'builder-demo',
  });
  for (let x = 0; x < 4; x++) for (let y = 0; y < 4; y++) microBody.set(x, y, 0, microHull);
  for (let z = 1; z < 4; z++) {
    microBody.set(0, 0, z, microHull); microBody.set(3, 0, z, microHull);
    microBody.set(0, 3, z, microHull); microBody.set(3, 3, z, microHull);
  }
  microBody.set(1, 0, 2, microGlass); microBody.set(2, 0, 2, microGlass);

  const guide = engine.entities.add({ id:'guide',type:'npc',name:'RuneRay Guide',x:1.8,y:1.45,z:1.02,radius:.45,height:1.55,tags:['actor','demo'], sprite:{width:1.05,height:1.45,art:[' /A\\ ','<OO>','[==]',' /\\ ']}, interactions:{primary:()=> 'Guide: Higher detail makes small actors and props much easier to read.'}, update:(_dt,e,runtime)=>{e.z=1.02+Math.sin(runtime.simulationTime*1.7)*.08;} });
  const pickup = engine.entities.add({ id:'sample-pickup',type:'pickup',name:'Rune Fragment',x:-1.15,y:1.35,z:1.05,radius:.22,height:.45,tags:['item','demo'], sprite:{width:.42,height:.55,art:[' /\\ ','<*>',' \\/ ']},state:{collected:false},interactions:{primary:({entity})=>{if(entity.state.collected)return 'The fragment is already collected.';entity.state.collected=true;entity.visible=false;entity.enabled=false;inv.add('ore-sample',1);return 'Picked up Rune Fragment (+1 sample).';}} });
  const chest = engine.entities.add({ id:'test-chest',type:'container',name:'Test Chest',x:-.2,y:-2,z:1.02,radius:.45,height:.72,tags:['container','demo'], sprite:{width:.95,height:.72,art:['+---+','|===|','+---+']},state:{opened:false},interactions:{primary:({entity})=>{if(entity.state.opened)return 'The chest is empty.';entity.state.opened=true;inv.add('repair-kit',1);inv.add('glass-block',2);return 'Opened Test Chest: +1 repair kit, +2 glass.';}} });
  const beacon = engine.entities.add({ id:'beacon',type:'switch',name:'Beacon Switch',x:8.2,y:-1.6,z:2.8,radius:.3,height:.8,tags:['switch','demo'],sprite:{width:.55,height:.8,art:[' * ','<+>',' | ']},state:{on:true},interactions:{primary:({entity})=>{entity.state.on=!entity.state.on;engine.world.set(9,0,2,entity.state.on?lamp:hull);return `Beacon ${entity.state.on?'ON':'OFF'}.`;}} });


  engine.camera.x = -4.5; engine.camera.y = 0.5; engine.camera.z = 2.2; engine.camera.yaw = 0;

  const buildables = [hull, glass, deck, lamp];
  const microBuildables = [microHull, microGlass];
  let selectedIndex = 0, microSelectedIndex = 0, microLayer = 2, lastError = '';
  const fail = msg => { lastError = msg; return false; };
  const ok = () => { lastError = ''; return true; };

  return {
    materials: { hull, glass, deck, lamp, microHull, microGlass },
    microBody,
    entities: { guide, pickup, chest, beacon },
    get selected() { return buildables[selectedIndex]; },
    get microSelected() { return microBuildables[microSelectedIndex]; },
    get microLayer() { return microLayer; },
    get lastError() { return lastError; },
    cycle() { selectedIndex = (selectedIndex + 1) % buildables.length; lastError = ''; },
    cycleMicro() { microSelectedIndex = (microSelectedIndex + 1) % microBuildables.length; lastError = ''; },
    setMicroLayer(value) { microLayer = Math.max(0, Math.min(microBody.sizeZ - 1, value | 0)); },
    remove() {
      const hit = engine.queryAim(7);
      if (!hit || hit.dist > 7) return fail('No world block in range');
      if (hit.source !== 'world') return fail('Use Micro Builder for small voxels');
      const id = engine.world.get(hit.x, hit.y, hit.z), itemId = materialItems.get(id);
      engine.world.set(hit.x, hit.y, hit.z, 0); if (itemId) inv.add(itemId, 1); return ok();
    },
    place() {
      const hit = engine.queryAim(7);
      if (!hit || hit.dist > 7) return fail('No world face in range');
      if (hit.source !== 'world') return fail('Aim at a large world block');
      const x = hit.x + hit.nx, y = hit.y + hit.ny, z = hit.z + hit.nz;
      if (engine.world.get(x, y, z) !== 0) return fail('That cell is occupied');
      const c = engine.camera;
      if (Math.abs(c.x - (x + .5)) < .75 && Math.abs(c.y - (y + .5)) < .75 && Math.abs(c.z - (z + .5)) < .9) return fail('Cannot build inside yourself');
      const materialId = buildables[selectedIndex], itemId = materialItems.get(materialId);
      if (!inv.has(itemId, 1)) return fail(`Out of ${inv.def(itemId).name}`);
      inv.remove(itemId, 1); engine.world.set(x, y, z, materialId); return ok();
    },
    toggleMicro(x, y) {
      const existing = microBody.get(x, y, microLayer);
      if (existing) {
        const itemId = microItems.get(existing); if (itemId) inv.add(itemId, 1);
        microBody.set(x, y, microLayer, 0); return ok();
      }
      const materialId = microBuildables[microSelectedIndex], itemId = microItems.get(materialId);
      if (!inv.has(itemId, 1)) return fail(`Out of ${inv.def(itemId).name}`);
      inv.remove(itemId, 1); microBody.set(x, y, microLayer, materialId); return ok();
    },
    dropMicro() {
      microBody.x = 0.75; microBody.y = -0.5; microBody.z = 5.2;
      microBody.vx = 0.35; microBody.vy = 0.08; microBody.vz = 0;
      microBody.gravityScale = 1; return ok();
    },
    recallMicro() {
      microBody.x = 0.75; microBody.y = -0.5; microBody.z = 1.02;
      microBody.vx = microBody.vy = microBody.vz = 0; microBody.gravityScale = 0; return ok();
    },
    materialName() { return engine.materials.get(buildables[selectedIndex]).name; },
    microMaterialName() { return engine.materials.get(microBuildables[microSelectedIndex]).name; },
    itemForSelected() { return materialItems.get(buildables[selectedIndex]); },
    microItemForSelected() { return microItems.get(microBuildables[microSelectedIndex]); },
  };
}
