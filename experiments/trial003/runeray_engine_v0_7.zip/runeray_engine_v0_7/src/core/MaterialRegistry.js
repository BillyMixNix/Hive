import { canonicalData } from './CanonicalData.js';
export class MaterialRegistry {
  constructor() {
    this.byId = [{
      id: 0, key: 'air', name: 'Air', ramp: ' ', solid: false, buildable: false,
      opacity: 0, emissive: 0, distanceBias: 0,
    }];
    this.byKey = new Map([['air', this.byId[0]]]);
  }

  register(key, spec = {}) {
    if (this.byKey.has(key)) throw new Error(`Material already registered: ${key}`);
    const id = this.byId.length;
    if (id > 255) throw new Error('RuneRay currently supports at most 255 non-air materials.');
    const opacity = Number.isFinite(spec.opacity) ? Math.max(0, Math.min(1, spec.opacity)) : 1;
    const material = {
      id,
      key,
      name: spec.name ?? key,
      ramp: spec.ramp ?? ' .,:;irsXA253hMHGS#9B&@',
      solid: spec.solid ?? true,
      buildable: spec.buildable ?? true,
      opacity,
      emissive: spec.emissive ?? 0,
      distanceBias: spec.distanceBias ?? 0,
    };
    this.byId[id] = material;
    this.byKey.set(key, material);
    return id;
  }

  get(id) { return this.byId[id] ?? this.byId[0]; }
  id(key) { return this.byKey.get(key)?.id ?? 0; }
  listBuildable() { return this.byId.filter(m => m?.buildable); }
  serialize() { return this.byId.filter(Boolean).map(material => canonicalData(material)); }
  restore(data = []) {
    if (!Array.isArray(data) || !data.length) return this;
    const byId = []; const byKey = new Map();
    for (const raw of data) {
      const material = canonicalData(raw);
      if (!Number.isInteger(material.id) || material.id < 0 || material.id > 255) throw new RangeError('saved material id must be 0..255');
      if (typeof material.key !== 'string' || !material.key.length) throw new TypeError('saved material key must be a non-empty string');
      if (byId[material.id]) throw new Error(`Duplicate saved material id: ${material.id}`);
      if (byKey.has(material.key)) throw new Error(`Duplicate saved material key: ${material.key}`);
      byId[material.id] = material; byKey.set(material.key, material);
    }
    if (!byId[0] || byId[0].key !== 'air') throw new Error('saved material registry must include air at id 0');
    this.byId = byId; this.byKey = byKey; return this;
  }
}
