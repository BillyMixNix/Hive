import { MicroVoxelBody } from './MicroVoxelBody.js';

export class MicroVoxelSystem {
  constructor(world, materials, options = {}) {
    this.world = world;
    this.materials = materials;
    this.bodies = new Map();
    this.gravity = options.gravity ?? { x: 0, y: 0, z: 0 };
    this.maxLayersPerBody = 8;
  }

  _allocateId() { let n = 1; while (this.bodies.has(`micro-${n}`)) n++; return `micro-${n}`; }

  createBody(spec = {}) {
    const id = spec.id ?? this._allocateId();
    if (typeof id !== 'string' || !id.length) throw new TypeError('micro body id must be a non-empty string');
    if (this.bodies.has(id)) throw new Error(`Micro voxel body already exists: ${id}`);
    const body = new MicroVoxelBody({ ...spec, id });
    this.bodies.set(body.id, body);
    return body;
  }
  removeBody(id) { return this.bodies.delete(typeof id === 'string' ? id : id?.id); }
  get(id) { return this.bodies.get(id) ?? null; }
  list() { return [...this.bodies.values()]; }
  serialize() { return { gravity: { ...this.gravity }, bodies: [...this.bodies.values()].sort((a,b)=>a.id.localeCompare(b.id)).map(body=>body.serialize()) }; }

  restore(data = {}) {
    if (data.gravity) this.gravity = { ...data.gravity };
    const seen = new Set();
    for (const snap of data.bodies ?? []) {
      let body = this.bodies.get(snap.id);
      if (!body) body = this.createBody({ id:snap.id, voxelSize:snap.voxelSize, sizeX:snap.size?.[0]??4, sizeY:snap.size?.[1]??4, sizeZ:snap.size?.[2]??4 });
      body.x=snap.position?.[0]??body.x; body.y=snap.position?.[1]??body.y; body.z=snap.position?.[2]??body.z;
      body.vx=snap.velocity?.[0]??0; body.vy=snap.velocity?.[1]??0; body.vz=snap.velocity?.[2]??0; body.dynamic=snap.dynamic??body.dynamic; body.gravityScale=snap.gravityScale??body.gravityScale; body.restitution=snap.restitution??body.restitution; body.tag=snap.tag??body.tag;
      if (Array.isArray(snap.data) && snap.data.length === body.data.length) body.data.set(snap.data); seen.add(body.id);
    }
    for (const id of [...this.bodies.keys()]) if (!seen.has(id)) this.bodies.delete(id);
    return this;
  }

  _slab(origin, dir, min, max) {
    if (Math.abs(dir) < 1e-9) return origin >= min && origin <= max ? [-Infinity, Infinity] : [Infinity, -Infinity];
    const a = (min - origin) / dir, b = (max - origin) / dir;
    return a < b ? [a, b] : [b, a];
  }

  _castBody(body, origin, dx, dy, dz, maxDistance) {
    const len = Math.hypot(dx, dy, dz) || 1; dx /= len; dy /= len; dz /= len;
    const b = body.boundsAt();
    const sx = this._slab(origin.x, dx, b.minX, b.maxX), sy = this._slab(origin.y, dy, b.minY, b.maxY), sz = this._slab(origin.z, dz, b.minZ, b.maxZ);
    let tEnter = Math.max(0, sx[0], sy[0], sz[0]);
    const tExit = Math.min(maxDistance, sx[1], sy[1], sz[1]);
    if (!(tEnter <= tExit)) return [];

    const eps = 1e-6, s = body.voxelSize;
    let px = origin.x + dx * (tEnter + eps), py = origin.y + dy * (tEnter + eps), pz = origin.z + dz * (tEnter + eps);
    let ix = Math.floor((px - body.x) / s), iy = Math.floor((py - body.y) / s), iz = Math.floor((pz - body.z) / s);
    ix = Math.max(0, Math.min(body.sizeX - 1, ix)); iy = Math.max(0, Math.min(body.sizeY - 1, iy)); iz = Math.max(0, Math.min(body.sizeZ - 1, iz));
    const stepx = dx < 0 ? -1 : 1, stepy = dy < 0 ? -1 : 1, stepz = dz < 0 ? -1 : 1;
    const ddx = dx === 0 ? Infinity : s / Math.abs(dx), ddy = dy === 0 ? Infinity : s / Math.abs(dy), ddz = dz === 0 ? Infinity : s / Math.abs(dz);
    const nextX = () => body.x + (stepx > 0 ? ix + 1 : ix) * s;
    const nextY = () => body.y + (stepy > 0 ? iy + 1 : iy) * s;
    const nextZ = () => body.z + (stepz > 0 ? iz + 1 : iz) * s;
    let tx = dx === 0 ? Infinity : tEnter + (nextX() - px) / dx;
    let ty = dy === 0 ? Infinity : tEnter + (nextY() - py) / dy;
    let tz = dz === 0 ? Infinity : tEnter + (nextZ() - pz) / dz;
    let t = tEnter, axis = -1, nx = -Math.sign(dx), ny = 0, nz = 0;
    const hits = [];

    for (let step = 0; step < 256 && t <= tExit; step++) {
      const materialId = body.get(ix, iy, iz);
      if (materialId) {
        const material = this.materials.get(materialId);
        hits.push({
          source: 'micro', body, dist: Math.max(0, t), materialId, material, axis,
          x: body.x + ix * s, y: body.y + iy * s, z: body.z + iz * s,
          cellX: ix, cellY: iy, cellZ: iz, nx, ny, nz,
          hx: origin.x + dx * Math.max(0, t), hy: origin.y + dy * Math.max(0, t), hz: origin.z + dz * Math.max(0, t),
        });
        if (material.opacity >= 0.999 || hits.length >= this.maxLayersPerBody) break;
      }
      if (tx < ty && tx < tz) {
        t = tx; tx += ddx; ix += stepx; axis = 0; nx = -stepx; ny = 0; nz = 0;
      } else if (ty < tz) {
        t = ty; ty += ddy; iy += stepy; axis = 1; nx = 0; ny = -stepy; nz = 0;
      } else {
        t = tz; tz += ddz; iz += stepz; axis = 2; nx = 0; ny = 0; nz = -stepz;
      }
      if (!body.inBounds(ix, iy, iz)) break;
    }
    return hits;
  }

  castLayers(origin, dx, dy, dz, maxDistance = 64) {
    const hits = [];
    for (const body of this.bodies.values()) hits.push(...this._castBody(body, origin, dx, dy, dz, maxDistance));
    return hits.sort((a, b) => a.dist - b.dist);
  }

  _collidesWorld(body, x, y, z) {
    const s = body.voxelSize;
    const eps = 1e-5;
    for (let iz = 0; iz < body.sizeZ; iz++) for (let iy = 0; iy < body.sizeY; iy++) for (let ix = 0; ix < body.sizeX; ix++) {
      const bodyMaterial = this.materials.get(body.get(ix, iy, iz));
      if (!bodyMaterial.solid) continue;
      const minX = x + ix * s + eps, maxX = x + (ix + 1) * s - eps;
      const minY = y + iy * s + eps, maxY = y + (iy + 1) * s - eps;
      const minZ = z + iz * s + eps, maxZ = z + (iz + 1) * s - eps;
      for (const wx of [minX, maxX]) for (const wy of [minY, maxY]) for (const wz of [minZ, maxZ]) {
        const worldMaterial = this.materials.get(this.world.get(Math.floor(wx), Math.floor(wy), Math.floor(wz)));
        if (worldMaterial.solid) return true;
      }
    }
    return false;
  }

  update(dt) {
    for (const body of this.bodies.values()) {
      if (!body.dynamic) continue;
      body.vx += this.gravity.x * body.gravityScale * dt;
      body.vy += this.gravity.y * body.gravityScale * dt;
      body.vz += this.gravity.z * body.gravityScale * dt;
      const axes = [
        ['x', 'vx'], ['y', 'vy'], ['z', 'vz'],
      ];
      for (const [posKey, velKey] of axes) {
        const next = body[posKey] + body[velKey] * dt;
        const x = posKey === 'x' ? next : body.x, y = posKey === 'y' ? next : body.y, z = posKey === 'z' ? next : body.z;
        if (this._collidesWorld(body, x, y, z)) body[velKey] *= -body.restitution;
        else body[posKey] = next;
      }
      if (Math.abs(body.vx) < 0.002) body.vx = 0;
      if (Math.abs(body.vy) < 0.002) body.vy = 0;
      if (Math.abs(body.vz) < 0.002) body.vz = 0;
    }
  }
}
