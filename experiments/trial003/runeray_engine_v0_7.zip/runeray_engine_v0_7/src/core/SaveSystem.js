export class SaveSystem {
  constructor(engine, options={}){this.engine=engine;this.prefix=options.prefix??'runeray:';this.memory=new Map();}
  capture(){return this.engine.serializeCoreState();}
  restore(snapshot){return this.engine.restoreCoreState(snapshot);}
  toJson(space=0){return JSON.stringify(this.capture(),null,space);}
  fromJson(text){const data=JSON.parse(text);this.restore(data);return data;}
  saveSlot(name='quick'){const data=this.toJson();this.memory.set(name,data);try{globalThis.localStorage?.setItem?.(`${this.prefix}${name}`,data);}catch{}return data.length;}
  loadSlot(name='quick'){let data=this.memory.get(name)??null;try{data=globalThis.localStorage?.getItem?.(`${this.prefix}${name}`)??data;}catch{}if(!data)return{ok:false,reason:'No save in slot'};this.fromJson(data);return{ok:true};}
}
