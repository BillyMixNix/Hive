export class NavigationSystem {
  constructor(world, materials, options = {}) {
    this.world = world; this.materials = materials;
    this.maxNodes = Math.max(32, options.maxNodes ?? 900);
    this.defaultHeightCells = Math.max(1, options.heightCells ?? 2);
  }
  _solid(x, y, z) { return this.materials.get(this.world.get(x, y, z)).solid; }
  isWalkable(x, y, z, heightCells = this.defaultHeightCells) {
    if (!Number.isInteger(x) || !Number.isInteger(y) || !Number.isInteger(z)) return false;
    if (!this._solid(x, y, z - 1)) return false;
    for (let h = 0; h < heightCells; h++) if (this._solid(x, y, z + h)) return false;
    return true;
  }
  nearestWalkable(x, y, z, radius = 2) {
    const sx = Math.floor(x), sy = Math.floor(y), sz = Math.floor(z);
    for (let r = 0; r <= radius; r++) for (let dz = -1; dz <= 1; dz++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r && r !== 0) continue;
      const nx = sx + dx, ny = sy + dy, nz = sz + dz;
      if (this.isWalkable(nx, ny, nz)) return { x: nx, y: ny, z: nz };
    }
    return null;
  }
  _neighbors(node, allowVertical = true) {
    const out = [];
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const x = node.x + dx, y = node.y + dy;
      const zs = allowVertical ? [node.z, node.z + 1, node.z - 1] : [node.z];
      for (const z of zs) { if (this.isWalkable(x, y, z)) { out.push({ x, y, z }); break; } }
    }
    return out;
  }
  findPath(start, goal, options = {}) {
    const a = this.nearestWalkable(start.x, start.y, start.z, options.snapRadius ?? 2);
    const b = this.nearestWalkable(goal.x, goal.y, goal.z, options.snapRadius ?? 2);
    if (!a || !b) return [];
    const key = n => `${n.x},${n.y},${n.z}`;
    const heuristic = n => Math.abs(n.x - b.x) + Math.abs(n.y - b.y) + Math.abs(n.z - b.z) * 1.25;
    const startKey = key(a), goalKey = key(b), open = [{ ...a, g: 0, f: heuristic(a) }];
    const best = new Map([[startKey, 0]]), came = new Map(); let visited = 0;
    while (open.length && visited++ < (options.maxNodes ?? this.maxNodes)) {
      open.sort((p, q) => p.f - q.f || p.g - q.g || p.z - q.z || p.y - q.y || p.x - q.x);
      const cur = open.shift(), ck = key(cur);
      if (ck === goalKey) {
        const path = [{ x: cur.x + 0.5, y: cur.y + 0.5, z: cur.z + 0.02 }]; let k = ck;
        while (came.has(k)) { const prev = came.get(k); path.push({ x: prev.node.x + 0.5, y: prev.node.y + 0.5, z: prev.node.z + 0.02 }); k = prev.key; }
        path.reverse(); return path;
      }
      for (const n of this._neighbors(cur, options.allowVertical ?? true)) {
        const nk = key(n), step = 1 + Math.abs(n.z - cur.z) * 0.35, g = cur.g + step;
        if (g >= (best.get(nk) ?? Infinity)) continue;
        best.set(nk, g); came.set(nk, { key: ck, node: cur }); open.push({ ...n, g, f: g + heuristic(n) });
      }
    }
    return [];
  }
  lineOfSight(a, b, raycaster, padding = 0.18) {
    const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, dist = Math.hypot(dx, dy, dz);
    if (dist < 1e-6) return true;
    const hit = raycaster.cast(a, dx, dy, dz, dist);
    return !hit || hit.dist >= dist - padding;
  }
}
