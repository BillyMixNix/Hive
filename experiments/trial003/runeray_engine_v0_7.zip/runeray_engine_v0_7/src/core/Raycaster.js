export class Raycaster {
  constructor(world, materials, maxDistance = 64) {
    this.world = world;
    this.materials = materials;
    this.maxDistance = maxDistance;
    this.maxSteps = 256;
    this.maxVisualLayers = 8;
    this.providers = [];
  }

  addProvider(provider) { if (provider && !this.providers.includes(provider)) this.providers.push(provider); return provider; }
  removeProvider(provider) { const i = this.providers.indexOf(provider); if (i >= 0) this.providers.splice(i, 1); }

  _walkWorld(origin, dx, dy, dz, maxDistance, onHit) {
    const length = Math.hypot(dx, dy, dz) || 1;
    dx /= length; dy /= length; dz /= length;

    let mx = Math.floor(origin.x), my = Math.floor(origin.y), mz = Math.floor(origin.z);
    const sx = dx < 0 ? -1 : 1, sy = dy < 0 ? -1 : 1, sz = dz < 0 ? -1 : 1;
    const ddx = dx === 0 ? Infinity : Math.abs(1 / dx);
    const ddy = dy === 0 ? Infinity : Math.abs(1 / dy);
    const ddz = dz === 0 ? Infinity : Math.abs(1 / dz);
    let tx = dx < 0 ? (origin.x - mx) * ddx : (mx + 1 - origin.x) * ddx;
    let ty = dy < 0 ? (origin.y - my) * ddy : (my + 1 - origin.y) * ddy;
    let tz = dz < 0 ? (origin.z - mz) * ddz : (mz + 1 - origin.z) * ddz;

    let dist = 0, axis = 0, nx = 0, ny = 0, nz = 0;

    const initialMaterialId = this.world.get(mx, my, mz);
    if (initialMaterialId !== 0) {
      const initialHit = {
        source: 'world', dist: 0, materialId: initialMaterialId, material: this.materials.get(initialMaterialId), axis: -1,
        x: mx, y: my, z: mz, nx: 0, ny: 0, nz: 0, hx: origin.x, hy: origin.y, hz: origin.z, contained: true,
      };
      if (onHit(initialHit) === false) return;
    }
    for (let step = 0; step < this.maxSteps; step++) {
      if (tx < ty && tx < tz) {
        mx += sx; dist = tx; tx += ddx; axis = 0; nx = -sx; ny = 0; nz = 0;
      } else if (ty < tz) {
        my += sy; dist = ty; ty += ddy; axis = 1; nx = 0; ny = -sy; nz = 0;
      } else {
        mz += sz; dist = tz; tz += ddz; axis = 2; nx = 0; ny = 0; nz = -sz;
      }
      if (dist > maxDistance) return;
      const materialId = this.world.get(mx, my, mz);
      if (materialId === 0) continue;
      const hit = {
        source: 'world', dist, materialId, material: this.materials.get(materialId), axis,
        x: mx, y: my, z: mz, nx, ny, nz,
        hx: origin.x + dx * dist, hy: origin.y + dy * dist, hz: origin.z + dz * dist,
      };
      if (onHit(hit) === false) return;
    }
  }

  _worldLayers(origin, dx, dy, dz, maxDistance, maxLayers) {
    const hits = [];
    this._walkWorld(origin, dx, dy, dz, maxDistance, hit => {
      hits.push(hit);
      if (hit.material.opacity >= 0.999 || hits.length >= maxLayers) return false;
      return true;
    });
    return hits;
  }

  cast(origin, dx, dy, dz, maxDistance = this.maxDistance) {
    return this.castLayers(origin, dx, dy, dz, maxDistance, this.maxVisualLayers)[0] ?? null;
  }

  castLayers(origin, dx, dy, dz, maxDistance = this.maxDistance, maxLayers = this.maxVisualLayers) {
    const hits = this._worldLayers(origin, dx, dy, dz, maxDistance, maxLayers);
    for (const provider of this.providers) {
      const extra = provider.castLayers?.(origin, dx, dy, dz, maxDistance, maxLayers);
      if (extra?.length) hits.push(...extra);
    }
    hits.sort((a, b) => a.dist - b.dist);
    const visible = [];
    for (const hit of hits) {
      visible.push(hit);
      if (hit.material.opacity >= 0.999 || visible.length >= maxLayers) break;
    }
    return visible;
  }
}
