export class SkyEnvironment {
  constructor(options = {}) {
    this.seed = options.seed ?? 1337;
    this.starDensity = options.starDensity ?? 0.07;
    this.bandStrength = options.bandStrength ?? 0.42;
    this.bandNormal = this._normalize(options.bandNormal ?? { x: 0.28, y: -0.18, z: 0.94 });
    const celestials = options.celestials ?? [
      { direction: { x: 0.82, y: -0.30, z: 0.49 }, radius: 0.12, glyphs: ' .oO0@' },
      { direction: { x: 0.92, y: 0.28, z: 0.28 }, radius: 0.055, glyphs: ' .+*#@' },
    ];
    this.celestials = celestials.map(body => ({ ...body, direction: this._normalize(body.direction ?? { x: 1, y: 0, z: 0 }) }));
  }

  _normalize(v) {
    const n = Math.hypot(v.x, v.y, v.z) || 1;
    return { x: v.x / n, y: v.y / n, z: v.z / n };
  }

  _hash(a, b, c = 0) {
    let h = Math.imul((a | 0) ^ this.seed, 374761393) ^ Math.imul((b | 0) + 17, 668265263) ^ Math.imul((c | 0) + 31, 2246822519);
    h ^= h >>> 13; h = Math.imul(h, 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967295;
  }

  sample(dx, dy, dz) {
    const n = Math.hypot(dx, dy, dz) || 1;
    dx /= n; dy /= n; dz /= n;

    for (const body of this.celestials) {
      const dot = dx * body.direction.x + dy * body.direction.y + dz * body.direction.z;
      const angle = Math.acos(Math.max(-1, Math.min(1, dot)));
      if (angle < body.radius) {
        const edge = angle / body.radius;
        const ramp = body.glyphs || ' .oO@';
        const idx = Math.max(0, Math.min(ramp.length - 1, Math.floor((1 - edge) * (ramp.length - 1))));
        return ramp[idx] || ' ';
      }
    }

    const az = Math.atan2(dy, dx);
    const el = Math.asin(Math.max(-1, Math.min(1, dz)));
    const qx = Math.floor((az + Math.PI) * 46);
    const qy = Math.floor((el + Math.PI / 2) * 58);
    const star = this._hash(qx, qy);
    if (star < this.starDensity * 0.12) return '*';
    if (star < this.starDensity * 0.34) return '+';
    if (star < this.starDensity) return '.';

    const bandDistance = Math.abs(dx * this.bandNormal.x + dy * this.bandNormal.y + dz * this.bandNormal.z);
    const band = Math.max(0, 1 - bandDistance / 0.24) * this.bandStrength;
    if (band > 0) {
      const dust = this._hash(qx, qy, 91);
      if (dust < band * 0.12) return ':';
      if (dust < band * 0.34) return ',';
      if (dust < band * 0.62) return '.';
    }
    return ' ';
  }
}
