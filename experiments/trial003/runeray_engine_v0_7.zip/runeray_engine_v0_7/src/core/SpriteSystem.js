export class SpriteSystem {
  constructor() { this.sprites = new Map(); }

  _allocateId() { let n = 1; while (this.sprites.has(`sprite-${n}`)) n++; return `sprite-${n}`; }

  add(spec = {}) {
    const id = spec.id ?? this._allocateId();
    if (typeof id !== 'string' || !id.length) throw new TypeError('sprite id must be a non-empty string');
    if (this.sprites.has(id)) throw new Error(`Sprite already exists: ${id}`);
    const sprite = {
      id, x: spec.x ?? 0, y: spec.y ?? 0, z: spec.z ?? 0,
      width: Math.max(0.05, spec.width ?? 0.8), height: Math.max(0.05, spec.height ?? 1.2),
      art: Array.isArray(spec.art) ? spec.art.slice() : [String(spec.art ?? '@')], visible: spec.visible ?? true,
      vx: spec.vx ?? 0, vy: spec.vy ?? 0, vz: spec.vz ?? 0, update: spec.update ?? null, tag: spec.tag ?? null,
    };
    this.sprites.set(id, sprite); return sprite;
  }

  get(id) { return this.sprites.get(id) ?? null; }
  remove(id) { return this.sprites.delete(typeof id === 'string' ? id : id?.id); }
  clear() { this.sprites.clear(); }
  list() { return [...this.sprites.values()].filter(s => s.visible); }
  serialize() {
    return [...this.sprites.values()].sort((a, b) => a.id.localeCompare(b.id)).map(sprite => ({
      id: sprite.id, x: sprite.x, y: sprite.y, z: sprite.z, width: sprite.width, height: sprite.height,
      art: sprite.art.slice(), visible: sprite.visible, vx: sprite.vx, vy: sprite.vy, vz: sprite.vz, tag: sprite.tag,
    }));
  }
  restore(data = []) {
    const seen = new Set();
    for (const snap of data) {
      let sprite = this.sprites.get(snap.id);
      if (!sprite) sprite = this.add(snap);
      else Object.assign(sprite, snap, { art: (snap.art ?? sprite.art).slice(), update: sprite.update });
      seen.add(snap.id);
    }
    for (const id of [...this.sprites.keys()]) if (!seen.has(id) && !id.startsWith('entity-sprite:')) this.sprites.delete(id);
    return this;
  }
  update(dt, engine) {
    for (const sprite of this.sprites.values()) {
      sprite.x += sprite.vx * dt; sprite.y += sprite.vy * dt; sprite.z += sprite.vz * dt;
      sprite.update?.(dt, sprite, engine);
    }
  }
}
