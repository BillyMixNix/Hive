import { canonicalData } from './CanonicalData.js';
import { MaterialRegistry } from './MaterialRegistry.js';
import { ChunkedVoxelWorld } from './ChunkedVoxelWorld.js';
import { Raycaster } from './Raycaster.js';
import { AsciiRenderer } from './AsciiRenderer.js';
import { FirstPersonController } from './FirstPersonController.js';
import { SkyEnvironment } from './SkyEnvironment.js';
import { SpriteSystem } from './SpriteSystem.js';
import { MicroVoxelSystem } from './MicroVoxelSystem.js';
import { Inventory } from './Inventory.js';
import { MenuState } from './MenuState.js';
import { EntitySystem } from './EntitySystem.js';
import { InteractionSystem } from './InteractionSystem.js';
import { DeterministicRng } from './DeterministicRng.js';
import { EventBus } from './EventBus.js';
import { NavigationSystem } from './NavigationSystem.js';
import { AISystem } from './AISystem.js';
import { EquipmentSystem } from './EquipmentSystem.js';
import { CombatSystem } from './CombatSystem.js';
import { TriggerSystem } from './TriggerSystem.js';
import { DialogueSystem } from './DialogueSystem.js';
import { ProceduralWorldSystem } from './ProceduralWorldSystem.js';
import { SaveSystem } from './SaveSystem.js';

export class RuneRayEngine {
  constructor(canvas, options = {}) {
    this.seed = Number(options.seed ?? options.sky?.seed ?? 1) >>> 0 || 1;
    this.rng = new DeterministicRng(this.seed);
    this.events = new EventBus();
    this.materials = new MaterialRegistry();
    this.world = new ChunkedVoxelWorld(options.chunkSize ?? 16);
    this.camera = { x: 0.5, y: 0.5, z: 1.5, yaw: 0, pitch: 0 };
    this.sky = options.sky instanceof SkyEnvironment ? options.sky : new SkyEnvironment({ ...(options.sky ?? {}), seed: options.sky?.seed ?? this.seed });
    this.raycaster = new Raycaster(this.world, this.materials, options.maxDistance ?? 64);
    this.sprites = new SpriteSystem();
    this.entities = new EntitySystem(this.sprites);
    this.interactions = new InteractionSystem(this.entities, this.raycaster, options.interactions ?? {});
    this.microVoxels = new MicroVoxelSystem(this.world, this.materials, options.microPhysics ?? {});
    this.raycaster.addProvider(this.microVoxels);
    this.renderer = options.headless || !canvas ? null : new AsciiRenderer(canvas, this.raycaster, { ...(options.renderer ?? {}), sky: this.sky });
    this.controller = new FirstPersonController(this.world, this.materials, this.camera);
    this.inventory = new Inventory(options.inventorySlots ?? 12);
    this.menu = new MenuState();
    this.menu.onChange(state => { this.controller.enabled = !state.open && (this.combat?.get('player')?.alive ?? true); if (state.open) this.controller.clearInput(); });

    // Genre-neutral gameplay foundation.
    this.navigation = new NavigationSystem(this.world, this.materials, options.navigation ?? {});
    this.ai = new AISystem(this.entities, this.navigation, this.raycaster, this.events, options.ai ?? {});
    this.equipment = new EquipmentSystem(this.inventory, this.events, options.equipmentSlots ?? undefined);
    this.combat = new CombatSystem(this.entities, this.equipment, this.events);
    this.triggers = new TriggerSystem(this.events);
    this.dialogue = new DialogueSystem(this.events);
    this.procedural = new ProceduralWorldSystem(this.world, this.materials, this.seed, this.events);
    this.save = new SaveSystem(this, options.save ?? {});
    this.events.on('dialogue:start', () => { this.controller.enabled = false; this.controller.clearInput(); });
    this.events.on('dialogue:end', () => { this.controller.enabled = !this.menu.open && (this.combat.get('player')?.alive ?? true); });

    this.systems = [];
    this.stateAdapters = new Map();
    this.registerStateAdapter('ai', this.ai);
    this.registerStateAdapter('equipment', this.equipment);
    this.registerStateAdapter('combat', this.combat);
    this.registerStateAdapter('triggers', this.triggers);
    this.registerStateAdapter('dialogue', this.dialogue);
    this.registerStateAdapter('procedural', this.procedural);
    this.running = false;

    this.fixedStep = options.fixedStep ?? 1 / 60;
    if (!(this.fixedStep > 0) || !Number.isFinite(this.fixedStep)) throw new TypeError('fixedStep must be a positive finite number');
    this.simulationAccumulator = 0; this.simulationTime = 0; this.tick = 0;
    this.last = typeof performance !== 'undefined' ? performance.now() : 0;
    this.renderAccumulator = 0; this.renderInterval = 1 / (options.renderFps ?? 24);
  }

  addSystem(system) { this.systems.push(system); return system; }
  registerStateAdapter(key, adapter) { this.stateAdapters.set(key, adapter); return adapter; }
  random() { return this.rng.next(); }

  update(dt = this.fixedStep) {
    const nextTick = this.tick + 1; this.simulationTime = nextTick * this.fixedStep;
    this.controller.update(dt);
    this.microVoxels.update(dt, this);
    this.ai.update(dt, this);
    this.entities.update(dt, this);
    this.sprites.update(dt, this);
    this.interactions.findTarget(this.camera);
    this.combat.update(dt, this);
    this.triggers.update(dt, this);
    for (const s of this.systems) s.update?.(dt, this);
    this.tick = nextTick;
  }

  advance(elapsedSeconds) {
    if (!Number.isFinite(elapsedSeconds) || elapsedSeconds < 0) throw new TypeError('elapsedSeconds must be a finite non-negative number');
    this.simulationAccumulator += elapsedSeconds; let steps = 0; const eps = this.fixedStep * 1e-9;
    while (this.simulationAccumulator + eps >= this.fixedStep) { this.update(this.fixedStep); this.simulationAccumulator -= this.fixedStep; if (Math.abs(this.simulationAccumulator) < eps) this.simulationAccumulator = 0; steps++; }
    return steps;
  }

  queryAim(maxDistance = this.raycaster.maxDistance) {
    const cp = Math.cos(this.camera.pitch), sp = Math.sin(this.camera.pitch);
    return this.raycaster.cast(this.camera, Math.cos(this.camera.yaw) * cp, Math.sin(this.camera.yaw) * cp, sp, maxDistance);
  }

  interact(action = 'primary') { return this.interactions.interact(this.camera, action, this); }

  serializeCoreState() {
    const extensions = {};
    for (const [key, adapter] of [...this.stateAdapters.entries()].sort(([a],[b]) => a.localeCompare(b))) {
      if (adapter.serialize) extensions[key] = canonicalData(adapter.serialize());
    }
    return canonicalData({
      version: 4,
      seed: this.seed,
      rng: this.rng.serialize(),
      tick: this.tick,
      fixedStep: this.fixedStep,
      simulationTime: this.simulationTime,
      simulationAccumulator: this.simulationAccumulator,
      camera: { ...this.camera },
      controller: this.controller.serialize(),
      materials: this.materials.serialize(),
      world: this.world.serialize(),
      microVoxels: this.microVoxels.serialize(),
      sprites: this.sprites.serialize(),
      entities: this.entities.serialize(),
      inventory: this.inventory.serialize(),
      interactions: { reach: this.interactions.reach, aimCone: this.interactions.aimCone },
      raycaster: { maxDistance: this.raycaster.maxDistance, maxSteps: this.raycaster.maxSteps, maxVisualLayers: this.raycaster.maxVisualLayers },
      menu: { open: this.menu.open, tab: this.menu.tab },
      renderer: this.renderer ? { resolutionPreset: this.renderer.resolutionPreset } : null,
      extensions,
    });
  }

  restoreCoreState(snapshot = {}) {
    if (!snapshot || typeof snapshot !== 'object') throw new TypeError('snapshot must be an object');
    if ((snapshot.version ?? 0) > 4) throw new Error(`Unsupported RuneRay snapshot version ${snapshot.version}`);
    const state = canonicalData(snapshot);
    this.seed = Number(state.seed ?? this.seed) >>> 0 || 1;
    if (state.rng) { this.rng.seed = Number(state.rng.seed ?? this.seed) >>> 0 || 1; this.rng.state = Number(state.rng.state ?? this.rng.seed) >>> 0 || this.rng.seed; }
    this.fixedStep = state.fixedStep ?? this.fixedStep;
    this.tick = state.tick ?? 0;
    this.simulationTime = state.simulationTime ?? this.tick * this.fixedStep;
    this.simulationAccumulator = Number.isFinite(state.simulationAccumulator) ? Math.max(0, state.simulationAccumulator) : 0;

    if (state.materials) this.materials.restore(state.materials);
    if (state.world) this.world.restore(state.world);
    if (state.inventory) this.inventory.restore(state.inventory);
    if (state.microVoxels) this.microVoxels.restore(state.microVoxels);
    if (state.sprites) this.sprites.restore(state.sprites);
    if (state.entities) this.entities.restore(state.entities);
    if (state.camera) Object.assign(this.camera, state.camera);
    if (state.controller) this.controller.restore(state.controller);
    if (state.interactions) {
      if (Number.isFinite(state.interactions.reach)) this.interactions.reach = Math.max(0, state.interactions.reach);
      if (Number.isFinite(state.interactions.aimCone)) this.interactions.aimCone = Math.max(-1, Math.min(1, state.interactions.aimCone));
    }
    if (state.raycaster) {
      if (Number.isFinite(state.raycaster.maxDistance)) this.raycaster.maxDistance = Math.max(0, state.raycaster.maxDistance);
      if (Number.isInteger(state.raycaster.maxSteps) && state.raycaster.maxSteps > 0) this.raycaster.maxSteps = state.raycaster.maxSteps;
      if (Number.isInteger(state.raycaster.maxVisualLayers) && state.raycaster.maxVisualLayers > 0) this.raycaster.maxVisualLayers = state.raycaster.maxVisualLayers;
    }
    if (state.menu) { this.menu.tab = state.menu.tab ?? this.menu.tab; this.menu.setOpen(!!state.menu.open); }
    if (state.renderer?.resolutionPreset && this.renderer) this.renderer.setResolutionPreset(state.renderer.resolutionPreset);
    for (const [key, data] of Object.entries(state.extensions ?? {})) this.stateAdapters.get(key)?.restore?.(data);

    const snapshotEnabled = state.controller?.enabled ?? true;
    this.controller.enabled = !!snapshotEnabled && !this.menu.open && !this.dialogue.active && (this.combat.get('player')?.alive ?? true);
    if (!this.controller.enabled) this.controller.clearInput();
    this.interactions.findTarget(this.camera);
    this.events.emit('save:restored', { snapshot: state, engine: this });
    return true;
  }

  render() { if (!this.renderer) return; this.renderer.render(this.camera, this.sprites.list()); for (const s of this.systems) s.render?.(this); }

  start() {
    if (this.running) return;
    if (typeof requestAnimationFrame === 'undefined' || typeof performance === 'undefined') throw new Error('RuneRayEngine.start() requires browser animation timing APIs');
    this.running = true; this.last = performance.now();
    const frame = now => { if (!this.running) return; const dt = Math.max(0, (now - this.last) / 1000); this.last = now; this.advance(dt); this.renderAccumulator += dt; if (this.renderAccumulator >= this.renderInterval) { this.renderAccumulator %= this.renderInterval; this.render(); } requestAnimationFrame(frame); };
    requestAnimationFrame(frame);
  }
  stop() { this.running = false; }
}
