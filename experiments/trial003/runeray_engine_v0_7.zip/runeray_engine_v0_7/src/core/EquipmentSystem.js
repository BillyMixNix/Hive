export class EquipmentSystem {
  constructor(inventory, events = null, slots = ['mainHand','offHand','body','utility']) { this.inventory = inventory; this.events = events; this.slots = new Map(slots.map(s => [s, null])); }
  equip(itemId, slot = null) {
    const def = this.inventory.def(itemId), target = slot ?? def.equipSlot;
    if (!target || !this.slots.has(target)) return { ok:false, reason:'Item cannot be equipped there' };
    if (!this.inventory.has(itemId,1)) return { ok:false, reason:'Item not in inventory' };
    const previous = this.slots.get(target); if (previous) this.inventory.add(previous,1);
    this.inventory.remove(itemId,1); this.slots.set(target,itemId); this.events?.emit('equipment:changed',{slot:target,itemId,previous}); return {ok:true,slot:target,itemId,previous};
  }
  unequip(slot) { if (!this.slots.has(slot)) return {ok:false,reason:'Unknown slot'}; const itemId=this.slots.get(slot); if(!itemId)return{ok:false,reason:'Slot is empty'}; this.slots.set(slot,null); this.inventory.add(itemId,1); this.events?.emit('equipment:changed',{slot,itemId:null,previous:itemId}); return{ok:true,itemId}; }
  get(slot) { return this.slots.get(slot) ?? null; }
  bonuses() { const out={}; for(const itemId of this.slots.values()){if(!itemId)continue; const stats=this.inventory.def(itemId).stats??{}; for(const [k,v] of Object.entries(stats)) out[k]=(out[k]??0)+(Number(v)||0);} return out; }
  serialize(){return Object.fromEntries([...this.slots.entries()].sort(([a],[b])=>a.localeCompare(b)));}
  restore(data={}){for(const slot of this.slots.keys())this.slots.set(slot,data[slot]??null);}
}
