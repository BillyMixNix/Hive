export class EventBus {
  constructor() { this.listeners = new Map(); }
  on(type, fn) {
    if (typeof fn !== 'function') throw new TypeError('event listener must be a function');
    const set = this.listeners.get(type) ?? new Set(); set.add(fn); this.listeners.set(type, set);
    return () => this.off(type, fn);
  }
  once(type, fn) { let off = null; off = this.on(type, payload => { off?.(); fn(payload); }); return off; }
  off(type, fn) { const set = this.listeners.get(type); if (!set) return false; const removed = set.delete(fn); if (!set.size) this.listeners.delete(type); return removed; }
  emit(type, payload = {}) { for (const fn of [...(this.listeners.get(type) ?? [])]) fn(payload); }
  clear(type = null) { if (type == null) this.listeners.clear(); else this.listeners.delete(type); }
}
