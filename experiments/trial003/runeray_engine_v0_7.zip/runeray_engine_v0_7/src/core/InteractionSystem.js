export class InteractionSystem {
  constructor(entities, raycaster, options = {}) { this.entities = entities; this.raycaster = raycaster; this.reach = options.reach ?? 3.25; this.aimCone = options.aimCone ?? 0.965; this.target = null; }
  actionsFor(entity) { if (!entity?.enabled) return []; return Object.keys(entity.interactions ?? {}).filter(k => typeof entity.interactions[k] === 'function'); }
  findTarget(camera) {
    const cp = Math.cos(camera.pitch), sp = Math.sin(camera.pitch), fx = Math.cos(camera.yaw) * cp, fy = Math.sin(camera.yaw) * cp, fz = sp;
    let best = null, bestScore = -Infinity;
    for (const entity of this.entities.list()) {
      if (!entity.enabled || !this.actionsFor(entity).length) continue;
      const vx = entity.x - camera.x, vy = entity.y - camera.y, vz = entity.z + entity.height * 0.5 - camera.z, dist = Math.hypot(vx, vy, vz);
      if (dist < 0.03 || dist > this.reach + entity.radius) continue;
      const inv = 1 / dist, dx = vx * inv, dy = vy * inv, dz = vz * inv, dot = dx * fx + dy * fy + dz * fz;
      const assist = Math.min(0.08, entity.radius / Math.max(0.5, dist) * 0.45); if (dot < this.aimCone - assist) continue;
      const obstruction = this.raycaster.cast(camera, dx, dy, dz); if (obstruction && obstruction.dist < dist - Math.max(0.08, entity.radius * 0.55)) continue;
      const score = dot * 4 - dist * 0.16 + assist; if (score > bestScore || (score === bestScore && (!best || entity.id.localeCompare(best.entity.id) < 0))) { bestScore = score; best = { entity, dist, dot }; }
    }
    this.target = best; return best;
  }
  interact(camera, action = 'primary', engine = null) {
    const target = this.findTarget(camera); if (!target) return { ok: false, reason: 'Nothing to interact with' };
    const actions = this.actionsFor(target.entity), chosen = target.entity.interactions[action] ? action : actions[0], handler = target.entity.interactions[chosen];
    if (!handler) return { ok: false, reason: 'No available interaction', target: target.entity };
    const result = handler({ entity: target.entity, action: chosen, engine, interaction: this, distance: target.dist });
    if (result === false) return { ok: false, reason: 'Interaction blocked', target: target.entity, action: chosen };
    if (typeof result === 'string') return { ok: true, message: result, target: target.entity, action: chosen };
    return { ok: true, ...(result ?? {}), target: target.entity, action: chosen };
  }
}
