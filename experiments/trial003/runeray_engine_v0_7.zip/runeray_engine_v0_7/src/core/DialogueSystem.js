export class DialogueSystem {
  constructor(events=null){this.events=events;this.trees=new Map();this.active=null;}
  register(id,spec={}){if(this.trees.has(id))throw new Error(`Dialogue already registered: ${id}`);const tree={id,start:spec.start??'start',nodes:{...(spec.nodes??{})}};this.trees.set(id,tree);return tree;}
  start(id,context={}){const tree=this.trees.get(id);if(!tree)return{ok:false,reason:'Unknown dialogue'};this.active={id,nodeId:tree.start,speakerId:context.speakerId??null,context:{...(context.data??{})}};this.events?.emit('dialogue:start',{active:this.active});return{ok:true,current:this.current()};}
  current(){if(!this.active)return null;const tree=this.trees.get(this.active.id),node=tree?.nodes?.[this.active.nodeId];if(!node)return null;const choices=(node.choices??[]).filter(c=>!c.condition||c.condition(this.active.context)).map((c,i)=>({index:i,text:c.text??`Choice ${i+1}`}));return{id:this.active.id,nodeId:this.active.nodeId,speakerId:this.active.speakerId,text:typeof node.text==='function'?node.text(this.active.context):node.text??'',choices,end:node.end??false};}
  choose(index,engine=null){const cur=this.current();if(!cur)return{ok:false,reason:'No active dialogue'};const tree=this.trees.get(this.active.id),node=tree.nodes[this.active.nodeId],choices=(node.choices??[]).filter(c=>!c.condition||c.condition(this.active.context)),choice=choices[index];if(!choice)return{ok:false,reason:'Invalid choice'};choice.action?.({engine,dialogue:this,context:this.active.context});if(choice.next)this.active.nodeId=choice.next;else if(choice.end||node.end)this.close();this.events?.emit('dialogue:choice',{choice,index,active:this.active});return{ok:true,current:this.current()};}
  close(){const prior=this.active;this.active=null;this.events?.emit('dialogue:end',{prior});}
  serialize(){return this.active?{...this.active,context:{...this.active.context}}:null;}
  restore(data){this.active=data?{...data,context:{...(data.context??{})}}:null;}
}
