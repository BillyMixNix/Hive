export class MenuState {
  constructor() { this.open = false; this.tab = 'inventory'; this.listeners = new Set(); }
  setOpen(open) { this.open = !!open; this._emit(); }
  toggle() { this.setOpen(!this.open); }
  setTab(tab) { this.tab = tab; this._emit(); }
  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  _emit() { for (const fn of this.listeners) fn(this); }
}
