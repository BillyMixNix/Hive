export class AsciiRenderer {
  constructor(canvas, raycaster, options = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.raycaster = raycaster;
    this.sky = options.sky ?? null;
    this.fov = options.fov ?? 78;
    this.resolutionPreset = options.resolutionPreset ?? 'high';
    this.maxColsOverride = options.maxCols ?? null;
    this.maxRowsOverride = options.maxRows ?? null;
    this.targetFps = options.targetFps ?? 24;
    this.foreground = options.foreground ?? '#a9f6c8';
    this.background = options.background ?? '#020504';
    this.centerHit = null;
    this.centerSprite = null;
    this.lastFrame = [];
    this.cols = 60; this.rows = 40; this.width = 1; this.height = 1;
    this.fontSize = 10; this.charW = 6; this.lineH = 10.5; this.drawX = 0;
    this.resize();
  }

  _profile() {
    const profiles = {
      low: { mobileFont: 10.0, desktopFont: 12.5, maxCols: 104, maxRows: 76 },
      balanced: { mobileFont: 8.4, desktopFont: 10.5, maxCols: 142, maxRows: 104 },
      high: { mobileFont: 7.0, desktopFont: 8.8, maxCols: 184, maxRows: 132 },
    };
    return profiles[this.resolutionPreset] ?? profiles.high;
  }
  setResolutionPreset(name) { if (!['low','balanced','high'].includes(name)) return false; this.resolutionPreset = name; this.resize(); return true; }
  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 1.75); this.width = innerWidth; this.height = innerHeight;
    this.canvas.width = Math.round(this.width * dpr); this.canvas.height = Math.round(this.height * dpr); this.canvas.style.width = `${this.width}px`; this.canvas.style.height = `${this.height}px`;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0); const profile = this._profile(); this.fontSize = this.width < 500 ? profile.mobileFont : profile.desktopFont;
    this.ctx.font = `700 ${this.fontSize}px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`; this.charW = Math.max(3.1, this.ctx.measureText('@').width); this.lineH = this.fontSize * 1.02;
    const maxCols = this.maxColsOverride ?? profile.maxCols, maxRows = this.maxRowsOverride ?? profile.maxRows;
    this.cols = Math.max(40, Math.min(maxCols, Math.floor(this.width / this.charW))); this.rows = Math.max(30, Math.min(maxRows, Math.floor(this.height / this.lineH))); this.drawX = (this.width - this.cols * this.charW) / 2;
  }

  _skyGlyph(dx, dy, dz) {
    return this.sky?.sample?.(dx, dy, dz) ?? ' ';
  }

  _glyph(hit, camera) {
    const ramp = hit.material.ramp || ' .,:;irsXA253hMHGS#9B&@';
    let light = 1 - hit.dist / this.raycaster.maxDistance;
    if (hit.axis === 1) light *= 0.86;
    if (hit.axis === 2) light *= hit.hz > camera.z ? 0.72 : 0.60;
    light += hit.material.emissive || 0;
    const grain = (Math.sin(hit.hx * 4.7) + Math.sin(hit.hy * 5.3) + Math.sin(hit.hz * 6.1)) * 0.035;
    light = Math.max(0, Math.min(1, light + grain + (hit.material.distanceBias || 0)));
    return ramp[Math.floor(light * (ramp.length - 1))] || ' ';
  }

  _noise01(row, col, hit, layer) {
    let h = Math.imul(row + 17, 374761393) ^ Math.imul(col + 31, 668265263);
    h ^= Math.imul((hit.cellX ?? hit.x ?? 0) + 101, 2246822519) ^ Math.imul((hit.cellY ?? hit.y ?? 0) + 211, 3266489917);
    h ^= Math.imul((hit.cellZ ?? hit.z ?? 0) + 307, 668265263) ^ Math.imul(layer + 1, 374761393);
    h ^= h >>> 13; h = Math.imul(h, 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967295;
  }

  _glyphLayers(hits, row, col, camera, skyGlyph) {
    if (!hits.length) return skyGlyph;
    const last = hits[hits.length - 1];
    const lastIsOpaque = last.material.opacity >= 0.999;
    let glyph = lastIsOpaque ? this._glyph(last, camera) : skyGlyph;
    let start = lastIsOpaque ? hits.length - 2 : hits.length - 1;
    for (let i = start; i >= 0; i--) {
      const hit = hits[i], opacity = Math.max(0, Math.min(1, hit.material.opacity ?? 1));
      if (opacity <= 0) continue;
      if (opacity >= 0.999 || this._noise01(row, col, hit, i) < opacity) glyph = this._glyph(hit, camera);
    }
    return glyph;
  }

  _overlaySprites(frame, opaqueDepth, layersBuffer, camera, sprites, basis) {
    if (!sprites?.length) return;
    const { tanH, tanV, fx, fy, fz, rx, ry, rz, ux, uy, uz } = basis;
    const spriteDepth = new Float64Array(this.rows * this.cols); spriteDepth.fill(Infinity);
    const centerR = Math.floor(this.rows / 2), centerC = Math.floor(this.cols / 2);

    for (const sprite of sprites) {
      if (!sprite?.visible) continue;
      const vx = sprite.x - camera.x, vy = sprite.y - camera.y, vz = sprite.z - camera.z;
      const depth = vx * fx + vy * fy + vz * fz;
      if (depth <= 0.05 || depth > this.raycaster.maxDistance) continue;
      const side = vx * rx + vy * ry + vz * rz;
      const vertical = vx * ux + vy * uy + vz * uz;
      const nx = side / (depth * tanH), ny = vertical / (depth * tanV);
      const targetW = Math.max(1, sprite.width * this.cols / (2 * depth * tanH));
      const targetH = Math.max(1, sprite.height * this.rows / (2 * depth * tanV));
      const centerCFloat = (nx + 1) * this.cols * 0.5 - 0.5;
      const centerRFloat = (1 - ny) * this.rows * 0.5 - 0.5;
      const c0 = Math.max(0, Math.floor(centerCFloat - targetW * 0.5));
      const c1 = Math.min(this.cols - 1, Math.ceil(centerCFloat + targetW * 0.5));
      const r0 = Math.max(0, Math.floor(centerRFloat - targetH * 0.5));
      const r1 = Math.min(this.rows - 1, Math.ceil(centerRFloat + targetH * 0.5));
      if (c0 > c1 || r0 > r1) continue;
      const art = sprite.art.map(line => [...line]);
      const artH = art.length, artW = Math.max(1, ...art.map(line => line.length));

      for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) {
        const u = targetW <= 1 ? 0.5 : (c - (centerCFloat - targetW * 0.5)) / targetW;
        const v = targetH <= 1 ? 0.5 : (r - (centerRFloat - targetH * 0.5)) / targetH;
        const ac = Math.max(0, Math.min(artW - 1, Math.floor(u * artW)));
        const ar = Math.max(0, Math.min(artH - 1, Math.floor(v * artH)));
        const ch = art[ar]?.[ac] ?? ' ';
        if (ch === ' ') continue;
        const idx = r * this.cols + c;
        if (depth >= opaqueDepth[idx] || depth >= spriteDepth[idx]) continue;

        let glyph = ch;
        const layers = layersBuffer[idx] ?? [];
        for (let i = layers.length - 1; i >= 0; i--) {
          const hit = layers[i];
          if (hit.dist >= depth || hit.material.opacity >= 0.999) continue;
          const opacity = Math.max(0, Math.min(1, hit.material.opacity ?? 1));
          if (opacity > 0 && this._noise01(r, c, hit, i) < opacity) glyph = this._glyph(hit, camera);
        }
        frame[r][c] = glyph;
        spriteDepth[idx] = depth;
        if (r === centerR && c === centerC && (!this.centerSprite || depth < this.centerSprite.dist)) this.centerSprite = { sprite, dist: depth };
      }
    }
  }

  render(camera, sprites = []) {
    const tanH = Math.tan(this.fov * Math.PI / 360);
    const tanV = Math.min(1.35, tanH * (this.height / Math.max(1, this.width)));
    const cp = Math.cos(camera.pitch), sp = Math.sin(camera.pitch);
    const fx = Math.cos(camera.yaw) * cp, fy = Math.sin(camera.yaw) * cp, fz = sp;
    const rx = -Math.sin(camera.yaw), ry = Math.cos(camera.yaw), rz = 0;
    const ux = -Math.cos(camera.yaw) * sp, uy = -Math.sin(camera.yaw) * sp, uz = cp;
    const basis = { tanH, tanV, fx, fy, fz, rx, ry, rz, ux, uy, uz };
    const frame = Array.from({ length: this.rows }, () => Array(this.cols).fill(' '));
    const opaqueDepth = new Float64Array(this.rows * this.cols); opaqueDepth.fill(Infinity);
    const layersBuffer = new Array(this.rows * this.cols);
    const centerR = Math.floor(this.rows / 2), centerC = Math.floor(this.cols / 2);
    this.centerHit = null; this.centerSprite = null;

    for (let r = 0; r < this.rows; r++) {
      const ny = 1 - ((r + 0.5) / this.rows) * 2;
      for (let c = 0; c < this.cols; c++) {
        const nx = ((c + 0.5) / this.cols) * 2 - 1;
        const dx = fx + rx * nx * tanH + ux * ny * tanV;
        const dy = fy + ry * nx * tanH + uy * ny * tanV;
        const dz = fz + rz * nx * tanH + uz * ny * tanV;
        const hits = this.raycaster.castLayers(camera, dx, dy, dz);
        const idx = r * this.cols + c; layersBuffer[idx] = hits;
        const opaque = hits.find(hit => hit.material.opacity >= 0.999);
        if (opaque) opaqueDepth[idx] = opaque.dist;
        if (r === centerR && c === centerC) this.centerHit = hits[0] ?? null;
        frame[r][c] = this._glyphLayers(hits, r, c, camera, this._skyGlyph(dx, dy, dz));
      }
    }

    this._overlaySprites(frame, opaqueDepth, layersBuffer, camera, sprites, basis);
    this.lastFrame = frame.map(row => row.join(''));
    const ctx = this.ctx;
    ctx.fillStyle = this.background; ctx.fillRect(0, 0, this.width, this.height);
    ctx.font = `700 ${this.fontSize}px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`;
    ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.shadowBlur = 6; ctx.shadowColor = '#4dff9b35'; ctx.fillStyle = this.foreground;
    for (let r = 0; r < this.rows; r++) ctx.fillText(this.lastFrame[r], this.drawX, r * this.lineH);
    ctx.shadowBlur = 9; ctx.shadowColor = '#d8ffe980'; ctx.fillStyle = '#effff6';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('+', this.width / 2, this.height / 2);
    ctx.shadowBlur = 0;
  }
}
