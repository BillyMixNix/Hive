import { DeterministicRng } from './DeterministicRng.js';
export class ProceduralWorldSystem {
  constructor(world, materials, seed=1, events=null){this.world=world;this.materials=materials;this.seed=Number(seed)>>>0||1;this.events=events;this.generators=new Map();this.generated=new Set();}
  register(id,generator){if(typeof generator!=='function'&&typeof generator?.generateChunk!=='function')throw new TypeError('generator must be a function or object with generateChunk');this.generators.set(id,generator);return generator;}
  _hash(id,cx,cy,cz){let h=this.seed^2166136261;for(const ch of String(id))h=Math.imul(h^ch.charCodeAt(0),16777619);for(const n of[cx,cy,cz]){h=Math.imul(h^(n|0),2246822519);h^=h>>>13;}return h>>>0||1;}
  ensureChunk(id,cx,cy,cz,engine=null){const key=`${id}:${cx},${cy},${cz}`;if(this.generated.has(key))return false;const generator=this.generators.get(id);if(!generator)throw new Error(`Unknown generator: ${id}`);const rng=new DeterministicRng(this._hash(id,cx,cy,cz));const ctx={id,cx,cy,cz,chunkSize:this.world.chunkSize,world:this.world,materials:this.materials,rng,engine,seed:rng.seed};if(typeof generator==='function')generator(ctx);else generator.generateChunk(ctx);this.generated.add(key);this.events?.emit('world:chunkGenerated',{id,cx,cy,cz,key});return true;}
  ensureAround(id,position,radius=1,engine=null){const s=this.world.chunkSize,cx=Math.floor(position.x/s),cy=Math.floor(position.y/s),cz=Math.floor(position.z/s);let count=0;for(let z=cz-radius;z<=cz+radius;z++)for(let y=cy-radius;y<=cy+radius;y++)for(let x=cx-radius;x<=cx+radius;x++)if(this.ensureChunk(id,x,y,z,engine))count++;return count;}
  serialize(){return{seed:this.seed,generated:[...this.generated].sort()};}
  restore(data={}){this.seed=Number(data.seed??this.seed)>>>0||1;this.generated=new Set(data.generated??[]);}
}
