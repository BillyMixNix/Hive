export class AISystem {
  constructor(entities, navigation, raycaster, events, options = {}) {
    this.entities = entities; this.navigation = navigation; this.raycaster = raycaster; this.events = events;
    this.agents = new Map(); this.defaultRepath = options.repathInterval ?? 0.65;
  }
  add(entityOrId, spec = {}) {
    const entity = this.entities.get(entityOrId); if (!entity) throw new Error('AI agent requires an existing entity');
    const agent = {
      entityId: entity.id, mode: spec.mode ?? 'idle', state: spec.state ?? 'idle', speed: Math.max(0, spec.speed ?? 1.25),
      vision: Math.max(0, spec.vision ?? 7), stopDistance: Math.max(0.05, spec.stopDistance ?? 0.75),
      repathInterval: Math.max(0.05, spec.repathInterval ?? this.defaultRepath), repathTimer: 0,
      target: spec.target ?? null, patrol: (spec.patrol ?? []).map(p => ({ ...p })), patrolIndex: spec.patrolIndex ?? 0,
      wanderRadius: Math.max(1, spec.wanderRadius ?? 4), home: spec.home ? { ...spec.home } : { x: entity.x, y: entity.y, z: entity.z },
      path: [], pathIndex: 0, enabled: spec.enabled ?? true, data: { ...(spec.data ?? {}) },
    };
    this.agents.set(entity.id, agent); return agent;
  }
  get(entityOrId) { return this.agents.get(typeof entityOrId === 'string' ? entityOrId : entityOrId?.id) ?? null; }
  remove(entityOrId) { return this.agents.delete(typeof entityOrId === 'string' ? entityOrId : entityOrId?.id); }
  _targetPosition(agent, engine) {
    if (agent.mode === 'chase' || agent.mode === 'flee') {
      if (agent.target === 'player' || agent.target == null) return engine.camera;
      return this.entities.get(agent.target) ?? null;
    }
    if (agent.mode === 'patrol' && agent.patrol.length) return agent.patrol[agent.patrolIndex % agent.patrol.length];
    if (agent.mode === 'wander') {
      if (!agent.data.wanderGoal) {
        const angle = engine.random() * Math.PI * 2, radius = (0.35 + engine.random() * 0.65) * agent.wanderRadius;
        agent.data.wanderGoal = { x: agent.home.x + Math.cos(angle) * radius, y: agent.home.y + Math.sin(angle) * radius, z: agent.home.z };
      }
      return agent.data.wanderGoal;
    }
    return null;
  }
  _repath(agent, entity, target, engine) {
    if (!target) { agent.path = []; return; }
    let goal = target;
    if (agent.mode === 'flee') {
      const dx = entity.x - target.x, dy = entity.y - target.y, len = Math.hypot(dx, dy) || 1;
      goal = { x: entity.x + dx / len * agent.vision, y: entity.y + dy / len * agent.vision, z: entity.z };
    }
    agent.path = this.navigation.findPath(entity, goal, { maxNodes: 700 }); agent.pathIndex = Math.min(1, Math.max(0, agent.path.length - 1));
    agent.repathTimer = agent.repathInterval;
    this.events?.emit('ai:path', { agent, entity, path: agent.path, engine });
  }
  _move(agent, entity, dt) {
    const p = agent.path[agent.pathIndex]; if (!p) return false;
    const dx = p.x - entity.x, dy = p.y - entity.y, dz = p.z - entity.z, dist = Math.hypot(dx, dy, dz);
    if (dist < 0.12) { agent.pathIndex++; return true; }
    const step = Math.min(dist, agent.speed * dt); entity.x += dx / dist * step; entity.y += dy / dist * step; entity.z += dz / dist * step; return true;
  }
  update(dt, engine) {
    for (const agent of this.agents.values()) {
      const entity = this.entities.get(agent.entityId); if (!agent.enabled || !entity?.enabled) continue;
      let target = this._targetPosition(agent, engine);
      if ((agent.mode === 'chase' || agent.mode === 'flee') && target) {
        const dist = Math.hypot(entity.x - target.x, entity.y - target.y, (entity.z + entity.height * .5) - target.z);
        const seen = dist <= agent.vision && this.navigation.lineOfSight({ x: entity.x, y: entity.y, z: entity.z + entity.height * .5 }, target, this.raycaster, entity.radius);
        agent.state = seen ? agent.mode : 'search';
        if (!seen && agent.mode === 'chase' && !agent.path.length) continue;
      } else agent.state = agent.mode;
      agent.repathTimer -= dt;
      if (agent.repathTimer <= 0 || agent.pathIndex >= agent.path.length) this._repath(agent, entity, target, engine);
      const moved = this._move(agent, entity, dt);
      if (!moved && agent.mode === 'patrol' && agent.patrol.length) { agent.patrolIndex = (agent.patrolIndex + 1) % agent.patrol.length; agent.repathTimer = 0; }
      if (!moved && agent.mode === 'wander') { agent.data.wanderGoal = null; agent.repathTimer = 0; }
      if (target && agent.mode === 'patrol' && Math.hypot(entity.x-target.x, entity.y-target.y, entity.z-target.z) <= agent.stopDistance) { agent.patrolIndex = (agent.patrolIndex + 1) % agent.patrol.length; agent.repathTimer = 0; }
    }
  }
  serialize() { return [...this.agents.values()].sort((a,b)=>a.entityId.localeCompare(b.entityId)).map(a => ({ ...a, home:{...a.home}, patrol:a.patrol.map(p=>({...p})), path:a.path.map(p=>({...p})), data:{...a.data} })); }
  restore(data = []) { for (const snap of data) { const a = this.agents.get(snap.entityId); if (!a) continue; Object.assign(a, snap, { home:{...snap.home}, patrol:(snap.patrol??[]).map(p=>({...p})), path:(snap.path??[]).map(p=>({...p})), data:{...(snap.data??{})} }); } }
}
