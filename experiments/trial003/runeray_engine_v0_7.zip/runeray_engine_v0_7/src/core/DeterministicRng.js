export class DeterministicRng {
  constructor(seed = 1) {
    const normalized = Number(seed) >>> 0;
    this.seed = normalized || 1;
    this.state = this.seed;
  }

  nextUint32() {
    let x = this.state >>> 0;
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    this.state = x >>> 0;
    return this.state;
  }

  next() { return this.nextUint32() / 4294967296; }
  serialize() { return { seed: this.seed, state: this.state }; }
}
