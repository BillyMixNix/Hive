export class ChunkedVoxelWorld {
  constructor(chunkSize = 16) {
    if (!Number.isInteger(chunkSize) || chunkSize <= 0) throw new TypeError('chunkSize must be a positive integer');
    this.chunkSize = chunkSize;
    this.chunkVolume = chunkSize ** 3;
    this.chunks = new Map();
    this.nonAirCount = 0;
  }

  _assertCoordinate(value, name) {
    if (!Number.isInteger(value)) throw new TypeError(`${name} must be an integer voxel coordinate`);
  }
  _assertCoordinates(x, y, z) {
    this._assertCoordinate(x, 'x'); this._assertCoordinate(y, 'y'); this._assertCoordinate(z, 'z');
  }
  _assertMaterialId(materialId) {
    if (!Number.isInteger(materialId) || materialId < 0 || materialId > 255) throw new RangeError('materialId must be an integer from 0 to 255');
  }
  _floorDiv(n) { return Math.floor(n / this.chunkSize); }
  _mod(n) { return ((n % this.chunkSize) + this.chunkSize) % this.chunkSize; }
  _key(cx, cy, cz) { return `${cx},${cy},${cz}`; }
  _index(lx, ly, lz) { return lx + ly * this.chunkSize + lz * this.chunkSize * this.chunkSize; }

  _locate(x, y, z) {
    this._assertCoordinates(x, y, z);
    const cx = this._floorDiv(x), cy = this._floorDiv(y), cz = this._floorDiv(z);
    return { cx, cy, cz, lx: this._mod(x), ly: this._mod(y), lz: this._mod(z), key: this._key(cx, cy, cz) };
  }

  get(x, y, z) {
    const p = this._locate(x, y, z);
    const chunk = this.chunks.get(p.key);
    return chunk ? chunk[this._index(p.lx, p.ly, p.lz)] : 0;
  }

  set(x, y, z, materialId) {
    this._assertMaterialId(materialId);
    const p = this._locate(x, y, z);
    let chunk = this.chunks.get(p.key);
    if (!chunk && materialId === 0) return false;
    if (!chunk) { chunk = new Uint8Array(this.chunkVolume); this.chunks.set(p.key, chunk); }
    const i = this._index(p.lx, p.ly, p.lz);
    const previous = chunk[i];
    if (previous === materialId) return false;
    chunk[i] = materialId;
    if (previous === 0 && materialId !== 0) this.nonAirCount++;
    if (previous !== 0 && materialId === 0) this.nonAirCount--;
    if (materialId === 0 && !chunk.some(Boolean)) this.chunks.delete(p.key);
    return true;
  }

  fillBox(x0, y0, z0, x1, y1, z1, materialId) {
    this._assertCoordinates(x0, y0, z0); this._assertCoordinates(x1, y1, z1); this._assertMaterialId(materialId);
    for (let z = z0; z <= z1; z++) for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) this.set(x, y, z, materialId);
  }

  clear() { this.chunks.clear(); this.nonAirCount = 0; }

  restore(data = {}) {
    if (data.chunkSize && data.chunkSize !== this.chunkSize) { this.chunkSize = data.chunkSize; this.chunkVolume = this.chunkSize ** 3; }
    this.clear();
    for (const [key, runs] of data.chunks ?? []) {
      const arr = new Uint8Array(this.chunkVolume); let i = 0;
      for (const [value, count] of runs) for (let n = 0; n < count && i < arr.length; n++) arr[i++] = value;
      if (arr.some(Boolean)) { this.chunks.set(key, arr); for (const v of arr) if (v) this.nonAirCount++; }
    }
    return this;
  }

  serialize() {
    const chunks = [];
    const entries = [...this.chunks.entries()].sort(([a], [b]) => {
      const aa = a.split(',').map(Number), bb = b.split(',').map(Number);
      return aa[0] - bb[0] || aa[1] - bb[1] || aa[2] - bb[2];
    });
    for (const [key, data] of entries) {
      const runs = [];
      let last = data[0], count = 1;
      for (let i = 1; i < data.length; i++) {
        if (data[i] === last && count < 65535) count++;
        else { runs.push([last, count]); last = data[i]; count = 1; }
      }
      runs.push([last, count]); chunks.push([key, runs]);
    }
    return { chunkSize: this.chunkSize, chunks };
  }
}
