export class FirstPersonController {
  constructor(world, materials, camera) {
    this.world = world; this.materials = materials; this.camera = camera;
    this.moveSpeed = 4.2; this.turnSpeed = 1.65; this.lookSpeed = 1.05;
    this.radius = 0.22;
    this.enabled = true;
    this.keys = new Set();
    this.move = { forward: false, back: false, left: false, right: false, up: false, down: false };
    this.look = { left: false, right: false, up: false, down: false };
  }

  clearInput() {
    this.keys.clear();
    for (const k of Object.keys(this.move)) this.move[k] = false;
    for (const k of Object.keys(this.look)) this.look[k] = false;
  }

  solidAt(x, y, z) { return this.materials.get(this.world.get(Math.floor(x), Math.floor(y), Math.floor(z))).solid; }
  canOccupy(x, y, z) {
    const r = this.radius;
    for (const ox of [-r, r]) for (const oy of [-r, r]) for (const oz of [-r, r]) if (this.solidAt(x + ox, y + oy, z + oz)) return false;
    return true;
  }
  tryMove(dx, dy, dz) {
    const c = this.camera;
    if (this.canOccupy(c.x + dx, c.y, c.z)) c.x += dx;
    if (this.canOccupy(c.x, c.y + dy, c.z)) c.y += dy;
    if (this.canOccupy(c.x, c.y, c.z + dz)) c.z += dz;
  }

  serialize() {
    return {
      moveSpeed: this.moveSpeed, turnSpeed: this.turnSpeed, lookSpeed: this.lookSpeed, radius: this.radius, enabled: this.enabled,
      keys: [...this.keys].sort(), move: { ...this.move }, look: { ...this.look },
    };
  }

  restore(data = {}) {
    if (Number.isFinite(data.moveSpeed)) this.moveSpeed = data.moveSpeed;
    if (Number.isFinite(data.turnSpeed)) this.turnSpeed = data.turnSpeed;
    if (Number.isFinite(data.lookSpeed)) this.lookSpeed = data.lookSpeed;
    if (Number.isFinite(data.radius)) this.radius = Math.max(0, data.radius);
    this.enabled = data.enabled ?? this.enabled;
    this.keys = new Set(Array.isArray(data.keys) ? data.keys.map(String) : []);
    this.move = { ...this.move, ...(data.move ?? {}) };
    this.look = { ...this.look, ...(data.look ?? {}) };
    return this;
  }

  update(dt) {
    if (!this.enabled) return;
    let f = (this.move.forward || this.keys.has('w') ? 1 : 0) - (this.move.back || this.keys.has('s') ? 1 : 0);
    let s = (this.move.right || this.keys.has('d') ? 1 : 0) - (this.move.left || this.keys.has('a') ? 1 : 0);
    let u = (this.move.up || this.keys.has(' ') ? 1 : 0) - (this.move.down || this.keys.has('shift') ? 1 : 0);
    if (f || s || u) {
      const length = Math.hypot(f, s, u) || 1; f /= length; s /= length; u /= length;
      const fx = Math.cos(this.camera.yaw), fy = Math.sin(this.camera.yaw), rx = -fy, ry = fx;
      this.tryMove((fx * f + rx * s) * this.moveSpeed * dt, (fy * f + ry * s) * this.moveSpeed * dt, u * this.moveSpeed * dt);
    }
    const turn = (this.look.right || this.keys.has('arrowright') ? 1 : 0) - (this.look.left || this.keys.has('arrowleft') ? 1 : 0);
    const look = (this.look.up || this.keys.has('arrowup') ? 1 : 0) - (this.look.down || this.keys.has('arrowdown') ? 1 : 0);
    this.camera.yaw += turn * this.turnSpeed * dt;
    this.camera.pitch = Math.max(-1.35, Math.min(1.35, this.camera.pitch + look * this.lookSpeed * dt));
  }
}
