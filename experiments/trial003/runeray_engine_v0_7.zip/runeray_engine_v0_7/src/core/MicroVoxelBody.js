export class MicroVoxelBody {
  constructor(spec = {}) {
    if (typeof spec.id !== 'string' || !spec.id.length) throw new TypeError('MicroVoxelBody requires a non-empty deterministic id');
    this.id = spec.id;
    this.voxelSize = Math.max(0.05, Number(spec.voxelSize ?? 0.25));
    this.sizeX = this._size(spec.sizeX ?? 4, 'sizeX'); this.sizeY = this._size(spec.sizeY ?? 4, 'sizeY'); this.sizeZ = this._size(spec.sizeZ ?? 4, 'sizeZ');
    this.data = new Uint8Array(this.sizeX * this.sizeY * this.sizeZ);
    this.x = spec.x ?? 0; this.y = spec.y ?? 0; this.z = spec.z ?? 0;
    this.vx = spec.vx ?? 0; this.vy = spec.vy ?? 0; this.vz = spec.vz ?? 0;
    this.dynamic = spec.dynamic ?? true; this.gravityScale = spec.gravityScale ?? 0;
    this.restitution = Math.max(0, Math.min(1, spec.restitution ?? 0.2)); this.tag = spec.tag ?? null;
  }
  _size(value, name) { if (!Number.isInteger(value) || value < 1) throw new TypeError(`${name} must be a positive integer`); return value; }
  _index(x, y, z) { return x + y * this.sizeX + z * this.sizeX * this.sizeY; }
  inBounds(x, y, z) { return Number.isInteger(x) && Number.isInteger(y) && Number.isInteger(z) && x >= 0 && y >= 0 && z >= 0 && x < this.sizeX && y < this.sizeY && z < this.sizeZ; }
  get(x, y, z) { return this.inBounds(x, y, z) ? this.data[this._index(x, y, z)] : 0; }
  set(x, y, z, materialId) {
    if (!this.inBounds(x, y, z)) return false;
    if (!Number.isInteger(materialId) || materialId < 0 || materialId > 255) throw new RangeError('materialId must be an integer from 0 to 255');
    const i = this._index(x, y, z); if (this.data[i] === materialId) return false; this.data[i] = materialId; return true;
  }
  fillBox(x0, y0, z0, x1, y1, z1, materialId) { for (let z=z0;z<=z1;z++) for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++) this.set(x,y,z,materialId); }
  boundsAt(x=this.x,y=this.y,z=this.z) { return { minX:x,minY:y,minZ:z,maxX:x+this.sizeX*this.voxelSize,maxY:y+this.sizeY*this.voxelSize,maxZ:z+this.sizeZ*this.voxelSize }; }
  serialize() { return { id:this.id, voxelSize:this.voxelSize, size:[this.sizeX,this.sizeY,this.sizeZ], position:[this.x,this.y,this.z], velocity:[this.vx,this.vy,this.vz], dynamic:this.dynamic, gravityScale:this.gravityScale, restitution:this.restitution, tag:this.tag, data:Array.from(this.data) }; }
}
