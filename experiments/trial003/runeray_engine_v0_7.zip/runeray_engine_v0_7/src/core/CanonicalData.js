export function canonicalData(value, seen = new Set()) {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new TypeError('snapshot data numbers must be finite');
    return value;
  }
  if (Array.isArray(value)) {
    if (seen.has(value)) throw new TypeError('snapshot data must not contain cycles');
    seen.add(value);
    const out = value.map(item => canonicalData(item, seen));
    seen.delete(value);
    return out;
  }
  if (typeof value === 'object') {
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) throw new TypeError('snapshot data must use plain objects/arrays/primitives');
    if (seen.has(value)) throw new TypeError('snapshot data must not contain cycles');
    seen.add(value);
    const out = {};
    for (const key of Object.keys(value).sort()) out[key] = canonicalData(value[key], seen);
    seen.delete(value);
    return out;
  }
  throw new TypeError(`snapshot data cannot contain ${typeof value}`);
}
