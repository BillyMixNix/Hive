import { canonicalData } from './CanonicalData.js';
export class EntitySystem {
  constructor(spriteSystem = null) { this.spriteSystem = spriteSystem; this.entities = new Map(); }
  _allocateId() { let n = 1; while (this.entities.has(`entity-${n}`)) n++; return `entity-${n}`; }
  add(spec = {}) {
    const id = spec.id ?? this._allocateId();
    if (typeof id !== 'string' || !id.length) throw new TypeError('entity id must be a non-empty string');
    if (this.entities.has(id)) throw new Error(`Entity already exists: ${id}`);
    const entity = { id, type: spec.type ?? 'entity', name: spec.name ?? id, x: spec.x ?? 0, y: spec.y ?? 0, z: spec.z ?? 0,
      radius: Math.max(0.02, spec.radius ?? 0.35), height: Math.max(0.02, spec.height ?? 1), visible: spec.visible ?? true,
      enabled: spec.enabled ?? true, state: { ...(spec.state ?? {}) }, tags: new Set(spec.tags ?? []), interactions: { ...(spec.interactions ?? {}) },
      update: spec.update ?? null, spriteId: null };
    if (spec.sprite && this.spriteSystem) {
      const sprite = this.spriteSystem.add({ id: spec.sprite.id ?? `entity-sprite:${id}`, x: entity.x, y: entity.y,
        z: spec.sprite.z ?? (entity.z + entity.height * 0.5), width: spec.sprite.width ?? Math.max(0.3, entity.radius * 2),
        height: spec.sprite.height ?? entity.height, art: spec.sprite.art ?? ['@'], visible: entity.visible, tag: spec.sprite.tag ?? 'entity' });
      entity.spriteId = sprite.id;
    }
    this.entities.set(id, entity); return entity;
  }
  get(id) { return this.entities.get(typeof id === 'string' ? id : id?.id) ?? null; }
  remove(id) { const e = this.get(id); if (!e) return false; if (e.spriteId && this.spriteSystem) this.spriteSystem.remove(e.spriteId); return this.entities.delete(e.id); }
  clear() { if (this.spriteSystem) for (const e of this.entities.values()) if (e.spriteId) this.spriteSystem.remove(e.spriteId); this.entities.clear(); }
  list() { return [...this.entities.values()]; }
  findByTag(tag) { return this.list().filter(e => e.tags.has(tag)); }
  restore(data = []) {
    const seen = new Set();
    for (const snap of data) {
      let e = this.entities.get(snap.id);
      if (!e) e = this.add({ ...snap, tags: snap.tags ?? [], state: snap.state ?? {} });
      const interactions = e.interactions, update = e.update, spriteId = e.spriteId;
      Object.assign(e, snap, { state:{...(snap.state??{})}, tags:new Set(snap.tags??[]), interactions, update, spriteId: snap.spriteId ?? spriteId });
      seen.add(e.id);
    }
    for (const e of this.entities.values()) if (!seen.has(e.id)) { e.enabled = false; e.visible = false; }
    return this;
  }
  serialize() {
    return [...this.entities.values()].sort((a,b)=>a.id.localeCompare(b.id)).map(e => ({
      id:e.id, type:e.type, name:e.name, x:e.x, y:e.y, z:e.z, radius:e.radius, height:e.height,
      visible:e.visible, enabled:e.enabled, state:canonicalData(e.state), tags:[...e.tags].sort(), spriteId:e.spriteId,
    }));
  }
  update(dt, engine) { for (const e of this.entities.values()) { if (e.enabled) e.update?.(dt, e, engine); if (!e.spriteId || !this.spriteSystem) continue;
      const s = this.spriteSystem.get(e.spriteId); if (!s) continue; s.x = e.x; s.y = e.y; s.z = e.z + e.height * 0.5; s.visible = e.visible && e.enabled; } }
}
