import { canonicalData } from './CanonicalData.js';
export class Inventory {
  constructor(slotCount = 12) {
    this.slotCount = Math.max(1, slotCount | 0);
    this.slots = Array.from({ length: this.slotCount }, () => null);
    this.itemDefs = new Map();
  }

  define(id, spec = {}) {
    const def = { id, name: spec.name ?? id, glyph: spec.glyph ?? '?', maxStack: Math.max(1, spec.maxStack ?? 99), data: spec.data ?? null, equipSlot: spec.equipSlot ?? null, stats: { ...(spec.stats ?? {}) }, damage: spec.damage ?? null, range: spec.range ?? null, cooldown: spec.cooldown ?? null };
    this.itemDefs.set(id, def); return def;
  }
  def(id) { return this.itemDefs.get(id) ?? { id, name: id, glyph: '?', maxStack: 99 }; }
  count(id) { return this.slots.reduce((n, s) => n + (s?.id === id ? s.count : 0), 0); }
  add(id, count = 1) {
    let remain = Math.max(0, count | 0), def = this.def(id);
    for (const slot of this.slots) if (slot?.id === id && slot.count < def.maxStack && remain) {
      const add = Math.min(remain, def.maxStack - slot.count); slot.count += add; remain -= add;
    }
    for (let i = 0; i < this.slots.length && remain; i++) if (!this.slots[i]) {
      const add = Math.min(remain, def.maxStack); this.slots[i] = { id, count: add }; remain -= add;
    }
    return count - remain;
  }
  remove(id, count = 1) {
    let need = Math.max(0, count | 0), removed = 0;
    for (let i = this.slots.length - 1; i >= 0 && need; i--) {
      const slot = this.slots[i]; if (!slot || slot.id !== id) continue;
      const take = Math.min(need, slot.count); slot.count -= take; need -= take; removed += take;
      if (slot.count <= 0) this.slots[i] = null;
    }
    return removed;
  }
  has(id, count = 1) { return this.count(id) >= count; }
  serialize() {
    const definitions = [...this.itemDefs.values()].sort((a, b) => String(a.id).localeCompare(String(b.id))).map(def => canonicalData(def));
    return { slotCount: this.slotCount, definitions, slots: this.slots.map(s => s ? canonicalData(s) : null) };
  }
  restore(data = {}) {
    const count = Math.max(1, data.slotCount ?? this.slotCount);
    if (Array.isArray(data.definitions)) {
      this.itemDefs.clear();
      for (const raw of data.definitions) {
        const def = canonicalData(raw);
        if (def?.id == null) throw new TypeError('saved item definition requires an id');
        this.itemDefs.set(def.id, def);
      }
    }
    this.slotCount = count; this.slots = Array.from({ length: count }, (_, i) => data.slots?.[i] ? canonicalData(data.slots[i]) : null);
    return this;
  }
}

