# RuneRay v0.7 QA

## Automated

`npm test` covers:

- voxel/raycast/transparency/micro-voxel behavior
- entities/interactions and construction inventory conservation
- fixed-step seeded determinism and headless mode
- AI/navigation, equipment, triggers, dialogue and procedural generation
- canonical data ordering plus invalid/cyclic snapshot rejection
- deterministic ID reuse and interaction tie-breaking
- expanded snapshot fields and exact v0.7 round-trip restore
- backward restore of v0.6 schema-v3 snapshots

## Browser smoke test

Verify boot, High resolution, movement/look, interaction, attack, menu/dialogue input gating, quick save/load and no console errors on a mobile viewport.

## Environment note

The release bundle and source pass Node syntax/build checks and the full headless runtime test suite. A Chromium screenshot smoke test was attempted in the packaging container, but the container Chromium process hung before producing a frame, so no new v0.7 screenshot is claimed. v0.7 does not change the v0.6 UI layout beyond release labels.
