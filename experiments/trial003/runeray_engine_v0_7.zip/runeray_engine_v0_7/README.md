# RuneRay Engine v0.7 — Hive Merge

RuneRay is a tiny first-person 3D voxel raycaster whose framebuffer is made of ASCII glyphs. v0.7 merges Hive's v0.5.1 determinism/data-contract improvements into the v0.6 genre-neutral gameplay foundation.

## Foundation

- sparse voxel world, transparency, sprites and optional fine voxels
- high/balanced/low ASCII framebuffer resolution
- deterministic fixed-step simulation, seeded RNG and headless mode
- generic entities/interactions, AI/navigation, inventory/equipment and combat
- event bus, triggers, branching dialogue and deterministic procedural chunks
- snapshot adapters plus JSON/in-memory/local quick save/load

## Hive merge improvements

- canonical plain-data snapshot validation with stable object key ordering
- lowest-available deterministic IDs for sprites, entities and micro bodies
- deterministic interaction tie-breaking by entity ID
- snapshots now include material definitions, inventory definitions, controller state/tuning, interaction tuning, raycaster settings and fractional simulation accumulator
- v0.7 restores those fields as well as recording them
- snapshot schema bumped to v4 while remaining compatible with v0.6 schema v3

## Run

Open `dist/runeray_engine_systems_lab.html` directly in a modern browser. Mobile controls are built in.

## Develop

```bash
npm test
npm run build
```

Reference copies of the pre-merge v0.6 build and Hive's v0.5.1 branch are preserved under `reference/`.
