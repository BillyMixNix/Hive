# RuneRay v0.7 Architecture

## Core rule
Simulation owns truth; rendering only resolves that truth into ASCII perception. Gameplay systems never depend on the previous rendered frame.

## Layers

1. **Data contract** — `CanonicalData` rejects cycles, functions/classes and non-finite numbers from snapshots and produces stable object-key ordering.
2. **Simulation** — fixed-step time, seeded RNG, controller, entities, AI, combat, triggers and gameplay systems.
3. **World** — sparse chunked large voxels plus optional fine voxel bodies and deterministic procedural generators.
4. **Perception** — DDA raycaster, transparent layers, sprites, sky and configurable ASCII framebuffer density.
5. **UI** — DOM inventory/menu/dialogue surfaces; UI state gates camera input.
6. **Persistence** — schema-v4 canonical snapshots plus extension adapters; v3 snapshots remain readable.

## Deterministic identity
Auto-generated sprite/entity/micro-body IDs always choose the lowest currently unused numeric ID. This avoids hidden allocation counters that diverge after delete/restore cycles. Game-authored persistent objects should still use explicit stable IDs.

## Snapshot boundary
Snapshots contain data only, never behavior/functions. Game code re-registers behaviors, generators, interactions and dialogue logic at boot; restore reapplies mutable state to stable IDs.
