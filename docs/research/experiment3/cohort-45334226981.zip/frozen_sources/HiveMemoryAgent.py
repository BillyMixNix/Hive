
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    import torch.nn.functional as F
except ImportError:
    torch = None
    nn = None
    optim = None
    F = None
import json
import os
from datetime import datetime

class HiveMemoryAgent:
    def __init__(self, device, shared_dim=256, memory_size=2000):
        self.device = device
        self.shared_dim = shared_dim
        self.memory_size = memory_size
        self.statuses = ["drafted"] * memory_size
        self.vectors = (
            torch.zeros(memory_size, shared_dim).to(self.device)
            if torch is not None
            else [None] * memory_size
        )
        self.tags = [""] * memory_size
        self.notes = [""] * memory_size
        self.metadata = [None] * memory_size
        self.timestamps = [None] * memory_size
        self.ptr = 0

        self.memory_file = "hive_memory.json"

        self.load_memory()


    def create_searchable_symbolic_memory_entry(self, symbolic_vector, tag="general", note="", status="drafted", metadata=None):
        index = self.ptr % self.memory_size

        self.vectors[index] = symbolic_vector.detach() if hasattr(symbolic_vector, "detach") else symbolic_vector
        self.tags[index] = tag
        self.notes[index] = note
        self.tags[index] = tag  # Ensure the tag is set correctly
        self.statuses[index] = status
        self.metadata[index] = metadata
        self.timestamps[index] = datetime.utcnow()

        self.ptr += 1
        self.save_memory()
    def search_notes_by_keyword(self, keyword):
        matching_notes = []
        for note in self.notes[:self.ptr]:
            if keyword.lower() in note.lower():
                matching_notes.append(note)
        return matching_notes

        # Store the note
    def retrieve_recent(self, n=10):
        return self.get_recent(n)

    def store(self, fused_vector, tag="general", note="", status="drafted", metadata=None):
        index = self.ptr % self.memory_size

        self.vectors[index] = fused_vector.detach() if hasattr(fused_vector, "detach") else fused_vector
        self.tags[index] = tag
        self.notes[index] = note
        self.statuses[index] = status
        self.metadata[index] = metadata
        self.timestamps[index] = datetime.utcnow()

        self.ptr += 1

        self.save_memory()

    def retrieve(self, query_vector, top_k=5, tag_filter=None):
        if torch is None or F is None:
            return []

        valid_indices = [
            i for i in range(min(self.ptr, self.memory_size))
            if (tag_filter is None or self.tags[i] == tag_filter)
        ]
        if not valid_indices:
           return torch.zeros(top_k, self.shared_dim).to(self.device)

        memory_subset = self.vectors[valid_indices]
        scores = F.cosine_similarity(query_vector.unsqueeze(0), memory_subset, dim=1)
        topk_indices = torch.topk(scores, k=min(top_k, len(scores))).indices
        selected = [valid_indices[i] for i in topk_indices]
        return self.vectors[selected]

    def get_recent_notes(self, n=10):
        end = self.ptr
        start = max(0, end - n)

        entries = []
        for i in range(start, end):
            entries.append({
                "id": i + 1,
                "tag": self.tags[i],
                "note": self.notes[i],
                "status": self.statuses[i],
                "metadata": self.metadata[i],
                "timestamp": str(self.timestamps[i])
            })

        return entries

    def summarize(self, window=100):
        end = self.ptr
        start = max(0, end - window)
        valid = self.vectors[start:end]
        if torch is None:
            return []
        return valid.mean(dim=0)

    def get_recent(self, n=10):
        end = self.ptr
        start = max(0, end - n)
        return self.vectors[start:end]
    def fuse(self, retrieved_list):
        """
        Fuse a list of retrieved memory vectors per input vector.
        If nothing was retrieved for a vector, it returns the original input vector.

        Args:
            retrieved_list (List[List[Tensor]]): List of top-k memory vectors per input

        Returns:
            Tensor: Fused memory representations [batch_size, shared_dim]
        """
        if torch is None:
            return retrieved_list

        fused_vectors = []
        for retrieved in retrieved_list:
            if isinstance(retrieved, torch.Tensor):
                avg_vector = retrieved  # Already a tensor (mean or direct return)
            elif isinstance(retrieved, list) and len(retrieved) > 0:
                avg_vector = torch.mean(torch.stack(retrieved), dim=0)
            else:
                avg_vector = torch.zeros(self.shared_dim).to(self.device)  # fallback if memory is empty

            fused_vectors.append(avg_vector)

        return torch.stack(fused_vectors)
    
    def save_memory(self):
        data = []

        for i in range(min(self.ptr, self.memory_size)):
            data.append({
                "id": i + 1,
                "tag": self.tags[i],
                "note": self.notes[i],
                "status": self.statuses[i],
                "metadata": self.metadata[i],
                "timestamp": str(self.timestamps[i])
            })

        with open(self.memory_file, "w") as f:
            json.dump(data, f, indent=2)
    
    def load_memory(self):
        if not os.path.exists(self.memory_file):
            return

        with open(self.memory_file, "r") as f:
            data = json.load(f)

        for i, entry in enumerate(data):
            if i >= self.memory_size:
                break

            self.tags[i] = entry["tag"]
            self.notes[i] = entry["note"]
            self.statuses[i] = entry.get("status", "drafted")
            self.metadata[i] = entry.get("metadata", None)
            self.timestamps[i] = entry["timestamp"]
            self.ptr += 1
    
    def get_task_by_id(self, task_id):
        index = task_id - 1

        if index < 0 or index >= self.ptr:
            return None

        return {
            "id": index + 1,
            "tag": self.tags[index],
            "note": self.notes[index],
            "status": self.statuses[index],
            "metadata": self.metadata[index],
            "timestamp": str(self.timestamps[index])
        }
    def update_task_status(self, task_id, new_status):
        index = task_id - 1

        if index < 0 or index >= self.ptr:
            return False

        self.statuses[index] = new_status
        self.save_memory()
        return True

    def update_task_metadata(self, task_id, new_metadata):
        index = task_id - 1

        if index < 0 or index >= self.ptr:
            return False

        self.metadata[index] = new_metadata
        self.save_memory()
        return True
    def get_current_task(self):
        for i in range(min(self.ptr, self.memory_size)):
            if self.statuses[i] == "active":
                return {
                    "id": i + 1,
                    "tag": self.tags[i],
                    "note": self.notes[i],
                    "status": self.statuses[i],
                    "timestamp": str(self.timestamps[i])
                }
        return None
    def reject_patch(self, patch_id, reflector_verdict=None):
        """
        Mark a patch as rejected and store the rejection reason in the task metadata for future reference.
        
        Args:
            patch_id (int): ID of the patch task.
            reflector_verdict (dict, optional): JSON returned by Reflector with the verdict and reason.
        """
        success = self.update_task_status(patch_id, "rejected")
        if not success:
            return False
        patch_entry = self.get_task_by_id(patch_id)
        if patch_entry:
            reason = reflector_verdict.get("reflection") if reflector_verdict else patch_entry.get("metadata", {}).get("reason", "Unknown")
            patch_entry["metadata"]["rejection_reason"] = reason
            self.save_memory()
        return True
    def get_rejected_patches_for_task(self, task_id, target_file=None):
        """
        Retrieve all rejected patches for a given task, optionally filtering by target file.
        
        Returns:
            List[str]: List of rejection reasons.
        """
        rejected = []
        for entry in self.get_recent_notes(200):
            if entry["tag"] == "patch" and entry["status"] == "rejected":
                meta = entry.get("metadata", {})
                if meta.get("task_id") == task_id or (target_file and meta.get("target_file") == target_file):
                    rejected.append(meta.get("rejection_reason", "Unknown reason"))
        return rejected
            
